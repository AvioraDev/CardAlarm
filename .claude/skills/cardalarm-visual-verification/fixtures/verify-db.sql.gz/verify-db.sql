--
-- PostgreSQL database dump
--

\restrict GLefNrDEFNj6MPLnsnTjBxMtB4oajsUR8e8FiGjEW22akaplMoElVVX9n9b2HCy

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql
    AS $$ select '{}'::jsonb $$;


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql
    AS $$ select null::uuid $$;


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
begin
  new.updated_at = now();
  return new;
end;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    id uuid NOT NULL,
    email text
);


--
-- Name: admin_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_audit_log (
    id bigint NOT NULL,
    admin_user_id uuid,
    action text NOT NULL,
    target_type text,
    target_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: admin_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_audit_log_id_seq OWNED BY public.admin_audit_log.id;


--
-- Name: alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alerts (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    watchlist_id bigint NOT NULL,
    watchlist_match_id bigint,
    store_product_id bigint NOT NULL,
    product_card_match_id bigint,
    event_type text DEFAULT 'new_watchlist_match'::text NOT NULL,
    channel text DEFAULT 'email'::text NOT NULL,
    status text NOT NULL,
    dedupe_key text NOT NULL,
    recipient_email text,
    subject text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    provider text,
    provider_message_id text,
    attempts integer DEFAULT 0 NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    error_message text,
    sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT alerts_attempts_check CHECK ((attempts >= 0)),
    CONSTRAINT alerts_channel_check CHECK ((channel = 'email'::text)),
    CONSTRAINT alerts_event_type_check CHECK ((event_type = 'new_watchlist_match'::text)),
    CONSTRAINT alerts_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'sent'::text, 'failed'::text, 'suppressed'::text])))
);


--
-- Name: alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.alerts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.alerts_id_seq OWNED BY public.alerts.id;


--
-- Name: card_catalogue_cards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.card_catalogue_cards (
    id bigint NOT NULL,
    set_id bigint,
    player_id bigint,
    team_id bigint,
    card_number text,
    subset text,
    is_rookie boolean DEFAULT false NOT NULL,
    is_insert boolean DEFAULT false NOT NULL,
    is_autograph boolean DEFAULT false NOT NULL,
    is_relic boolean DEFAULT false NOT NULL,
    verification_status text DEFAULT 'seeded'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: card_catalogue_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.card_catalogue_cards_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: card_catalogue_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.card_catalogue_cards_id_seq OWNED BY public.card_catalogue_cards.id;


--
-- Name: card_catalogue_sets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.card_catalogue_sets (
    id bigint NOT NULL,
    brand text,
    product_line text NOT NULL,
    season text,
    sport text DEFAULT 'basketball'::text NOT NULL,
    league text DEFAULT 'NBA'::text,
    release_year integer,
    source text,
    verification_status text DEFAULT 'seeded'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: card_catalogue_sets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.card_catalogue_sets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: card_catalogue_sets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.card_catalogue_sets_id_seq OWNED BY public.card_catalogue_sets.id;


--
-- Name: card_catalogue_variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.card_catalogue_variants (
    id bigint NOT NULL,
    card_id bigint NOT NULL,
    parallel_name text,
    normalized_parallel_name text,
    serial_limit integer,
    colour text,
    is_one_of_one boolean DEFAULT false NOT NULL,
    verification_status text DEFAULT 'seeded'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: card_catalogue_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.card_catalogue_variants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: card_catalogue_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.card_catalogue_variants_id_seq OWNED BY public.card_catalogue_variants.id;


--
-- Name: listings_feed; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listings_feed (
    id bigint NOT NULL,
    external_id text NOT NULL,
    source text NOT NULL,
    title text,
    price numeric(12,2),
    url text,
    image_url text,
    match_type text,
    is_dismissed boolean DEFAULT false NOT NULL,
    is_oos boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    year text,
    set_name text,
    card_number text,
    player_name text,
    variant text,
    is_serial boolean DEFAULT false NOT NULL,
    serial_number text,
    is_auto boolean DEFAULT false NOT NULL,
    is_rookie boolean DEFAULT false NOT NULL,
    category text,
    serial_current text,
    serial_limit text,
    match_confidence numeric(5,4),
    match_status text,
    match_reasons jsonb,
    unmatched_fields jsonb,
    matcher_version text
);


--
-- Name: listings_feed_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.listings_feed_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: listings_feed_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.listings_feed_id_seq OWNED BY public.listings_feed.id;


--
-- Name: match_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.match_feedback (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    store_product_id bigint,
    product_card_match_id bigint,
    feedback_type text NOT NULL,
    feedback_notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: match_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.match_feedback_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: match_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.match_feedback_id_seq OWNED BY public.match_feedback.id;


--
-- Name: player_aliases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.player_aliases (
    id bigint NOT NULL,
    player_id bigint NOT NULL,
    alias text NOT NULL,
    normalized_alias text NOT NULL,
    source text,
    confidence numeric(4,3) DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: player_aliases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.player_aliases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: player_aliases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.player_aliases_id_seq OWNED BY public.player_aliases.id;


--
-- Name: players; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.players (
    id bigint NOT NULL,
    full_name text NOT NULL,
    normalized_name text NOT NULL,
    sport text DEFAULT 'basketball'::text NOT NULL,
    league text DEFAULT 'NBA'::text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: players_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.players_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: players_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.players_id_seq OWNED BY public.players.id;


--
-- Name: product_availability_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_availability_events (
    id bigint NOT NULL,
    store_product_id bigint NOT NULL,
    store_id bigint,
    source text NOT NULL,
    external_id text NOT NULL,
    event_type text NOT NULL,
    detection_source text DEFAULT 'scanner'::text NOT NULL,
    scan_token text NOT NULL,
    previous_availability boolean,
    current_availability boolean,
    previous_price numeric(12,2),
    current_price numeric(12,2),
    previous_product_fingerprint text,
    current_product_fingerprint text,
    dedupe_key text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT product_availability_events_event_type_check CHECK ((event_type = ANY (ARRAY['first_seen'::text, 'restocked'::text, 'sold_out'::text, 'price_changed'::text, 'product_updated'::text])))
);


--
-- Name: product_availability_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_availability_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_availability_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_availability_events_id_seq OWNED BY public.product_availability_events.id;


--
-- Name: product_card_matches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_card_matches (
    id bigint NOT NULL,
    store_product_id bigint,
    source text,
    external_id text,
    checklist_id bigint,
    catalogue_card_id bigint,
    catalogue_variant_id bigint,
    matched_player_id bigint,
    matched_player_name text,
    confidence numeric(5,4) NOT NULL,
    status text NOT NULL,
    matched_fields jsonb,
    match_reasons jsonb,
    unmatched_fields jsonb,
    matcher_version text,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_card_matches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_card_matches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_card_matches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_card_matches_id_seq OWNED BY public.product_card_matches.id;


--
-- Name: product_classifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_classifications (
    id bigint NOT NULL,
    store_product_id bigint NOT NULL,
    classifier_version text NOT NULL,
    classifier_type text NOT NULL,
    status text DEFAULT 'ok'::text NOT NULL,
    year text,
    category text,
    brand text,
    product_line text,
    set_name text,
    card_number text,
    player_name text,
    team_name text,
    variant_name text,
    parallel_name text,
    insert_name text,
    is_rookie boolean DEFAULT false NOT NULL,
    is_auto boolean DEFAULT false NOT NULL,
    is_serial boolean DEFAULT false NOT NULL,
    serial_number text,
    serial_current text,
    serial_limit text,
    confidence numeric,
    raw_signals jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_classifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_classifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_classifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_classifications_id_seq OWNED BY public.product_classifications.id;


--
-- Name: product_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_snapshots (
    id bigint NOT NULL,
    store_product_id bigint,
    scan_run_id bigint,
    source text NOT NULL,
    external_id text NOT NULL,
    title text,
    description text,
    price numeric(12,2),
    currency text DEFAULT 'NZD'::text,
    availability boolean,
    image_url text,
    raw_payload jsonb,
    content_hash text NOT NULL,
    observed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_snapshots_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_snapshots_id_seq OWNED BY public.product_snapshots.id;


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    display_name text,
    role text DEFAULT 'user'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT profiles_role_check CHECK ((role = ANY (ARRAY['user'::text, 'admin'::text])))
);


--
-- Name: profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.profiles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.profiles_id_seq OWNED BY public.profiles.id;


--
-- Name: reference_checklists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reference_checklists (
    id bigint NOT NULL,
    year integer,
    set_name text,
    card_number text,
    player_name text
);


--
-- Name: reference_checklists_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reference_checklists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reference_checklists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reference_checklists_id_seq OWNED BY public.reference_checklists.id;


--
-- Name: scan_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scan_jobs (
    id bigint NOT NULL,
    scan_run_id bigint,
    mode text NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    requested_by uuid,
    requested_by_kind text DEFAULT 'admin'::text NOT NULL,
    priority integer DEFAULT 100 NOT NULL,
    locked_by text,
    locked_at timestamp with time zone,
    heartbeat_at timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 3 NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    cancel_requested_at timestamp with time zone,
    cancel_requested_by uuid,
    processed integer DEFAULT 0 NOT NULL,
    matched integer DEFAULT 0 NOT NULL,
    failed_stores integer DEFAULT 0 NOT NULL,
    completed_stores integer DEFAULT 0 NOT NULL,
    error text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT scan_jobs_attempts_check CHECK ((attempts >= 0)),
    CONSTRAINT scan_jobs_max_attempts_check CHECK ((max_attempts > 0)),
    CONSTRAINT scan_jobs_mode_check CHECK ((mode = ANY (ARRAY['watchlist'::text, 'full'::text, 'shallow'::text]))),
    CONSTRAINT scan_jobs_requested_by_kind_check CHECK ((requested_by_kind = ANY (ARRAY['admin'::text, 'schedule'::text, 'system'::text]))),
    CONSTRAINT scan_jobs_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'running'::text, 'completed'::text, 'failed'::text, 'cancelled'::text, 'timed_out'::text])))
);


--
-- Name: scan_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.scan_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: scan_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.scan_jobs_id_seq OWNED BY public.scan_jobs.id;


--
-- Name: scan_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scan_runs (
    id bigint NOT NULL,
    mode text NOT NULL,
    status text DEFAULT 'running'::text NOT NULL,
    processed integer DEFAULT 0 NOT NULL,
    matched integer DEFAULT 0 NOT NULL,
    error text,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


--
-- Name: scan_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.scan_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: scan_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.scan_runs_id_seq OWNED BY public.scan_runs.id;


--
-- Name: source_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.source_products (
    source text NOT NULL,
    external_id text NOT NULL,
    handle text,
    title text,
    price numeric(12,2),
    available boolean DEFAULT false NOT NULL,
    url text,
    image_url text,
    content_hash text NOT NULL,
    last_matched_hash text,
    last_matched_context_hash text,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_scan_token text,
    description text,
    normalized_title text,
    raw_latest_payload jsonb,
    last_checked_at timestamp with time zone
);


--
-- Name: store_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.store_products (
    id bigint NOT NULL,
    store_id bigint,
    source text NOT NULL,
    external_product_id text NOT NULL,
    handle text,
    product_url text,
    canonical_url text,
    title text,
    normalized_title text,
    description text,
    normalized_description text,
    current_price numeric(12,2),
    currency text DEFAULT 'NZD'::text,
    current_availability boolean DEFAULT false NOT NULL,
    image_url text,
    product_fingerprint text NOT NULL,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_checked_at timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL,
    raw_latest_payload jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: store_products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.store_products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: store_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.store_products_id_seq OWNED BY public.store_products.id;


--
-- Name: store_scan_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.store_scan_jobs (
    id bigint NOT NULL,
    scan_job_id bigint NOT NULL,
    store_scan_run_id bigint,
    store_id bigint,
    store_slug text NOT NULL,
    store_name text NOT NULL,
    base_url text NOT NULL,
    scan_mode text NOT NULL,
    scan_strategy text NOT NULL,
    early_stop_enabled boolean DEFAULT true NOT NULL,
    early_stop_unchanged_pages integer DEFAULT 2 NOT NULL,
    page_concurrency integer DEFAULT 1 NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    locked_by text,
    locked_at timestamp with time zone,
    heartbeat_at timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 3 NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    cancel_requested_at timestamp with time zone,
    cancel_requested_by uuid,
    products_seen integer DEFAULT 0 NOT NULL,
    products_processed integer DEFAULT 0 NOT NULL,
    products_matched integer DEFAULT 0 NOT NULL,
    products_marked_unavailable integer DEFAULT 0 NOT NULL,
    pages_fetched integer DEFAULT 0 NOT NULL,
    last_page_fetched integer,
    stop_reason text,
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT store_scan_jobs_attempts_check CHECK ((attempts >= 0)),
    CONSTRAINT store_scan_jobs_early_stop_unchanged_pages_check CHECK (((early_stop_unchanged_pages >= 1) AND (early_stop_unchanged_pages <= 50))),
    CONSTRAINT store_scan_jobs_max_attempts_check CHECK ((max_attempts > 0)),
    CONSTRAINT store_scan_jobs_page_concurrency_check CHECK (((page_concurrency >= 1) AND (page_concurrency <= 5))),
    CONSTRAINT store_scan_jobs_scan_mode_check CHECK ((scan_mode = ANY (ARRAY['watchlist'::text, 'full'::text, 'shallow'::text]))),
    CONSTRAINT store_scan_jobs_scan_strategy_check CHECK ((scan_strategy = ANY (ARRAY['shallow'::text, 'incremental'::text, 'full'::text]))),
    CONSTRAINT store_scan_jobs_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'running'::text, 'completed'::text, 'failed'::text, 'cancelled'::text, 'timed_out'::text])))
);


--
-- Name: store_scan_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.store_scan_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: store_scan_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.store_scan_jobs_id_seq OWNED BY public.store_scan_jobs.id;


--
-- Name: store_scan_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.store_scan_runs (
    id bigint NOT NULL,
    store_id bigint,
    store_slug text NOT NULL,
    status text NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    products_seen integer DEFAULT 0 NOT NULL,
    products_created integer DEFAULT 0 NOT NULL,
    products_updated integer DEFAULT 0 NOT NULL,
    products_marked_unavailable integer DEFAULT 0 NOT NULL,
    error_message text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    products_processed integer DEFAULT 0 NOT NULL,
    products_matched integer DEFAULT 0 NOT NULL,
    CONSTRAINT store_scan_runs_status_check CHECK ((status = ANY (ARRAY['running'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
);


--
-- Name: store_scan_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.store_scan_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: store_scan_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.store_scan_runs_id_seq OWNED BY public.store_scan_runs.id;


--
-- Name: stores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stores (
    id bigint NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    base_url text NOT NULL,
    source_type text DEFAULT 'shopify'::text NOT NULL,
    country_code text DEFAULT 'NZ'::text,
    currency text DEFAULT 'NZD'::text,
    is_active boolean DEFAULT true NOT NULL,
    scan_frequency_minutes integer DEFAULT 15 NOT NULL,
    last_successful_scan_at timestamp with time zone,
    last_failed_scan_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    scan_strategy text DEFAULT 'incremental'::text NOT NULL,
    early_stop_enabled boolean DEFAULT true NOT NULL,
    early_stop_unchanged_pages integer DEFAULT 2 NOT NULL,
    CONSTRAINT stores_early_stop_unchanged_pages_check CHECK (((early_stop_unchanged_pages >= 1) AND (early_stop_unchanged_pages <= 50))),
    CONSTRAINT stores_scan_strategy_check CHECK ((scan_strategy = ANY (ARRAY['incremental'::text, 'full'::text])))
);


--
-- Name: stores_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stores_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stores_id_seq OWNED BY public.stores.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teams (
    id bigint NOT NULL,
    name text NOT NULL,
    abbreviation text,
    league text DEFAULT 'NBA'::text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.teams_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.teams_id_seq OWNED BY public.teams.id;


--
-- Name: watchlist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watchlist (
    id bigint NOT NULL,
    player_name text NOT NULL,
    variants text DEFAULT ''::text NOT NULL,
    target_numbers text,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: watchlist_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.watchlist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: watchlist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.watchlist_id_seq OWNED BY public.watchlist.id;


--
-- Name: watchlist_matches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watchlist_matches (
    id bigint NOT NULL,
    watchlist_id bigint NOT NULL,
    watchlist_rule_id bigint,
    store_product_id bigint,
    source text,
    external_id text,
    product_card_match_id bigint,
    confidence numeric(5,4) NOT NULL,
    status text NOT NULL,
    first_matched_at timestamp with time zone DEFAULT now() NOT NULL,
    last_matched_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: watchlist_matches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.watchlist_matches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: watchlist_matches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.watchlist_matches_id_seq OWNED BY public.watchlist_matches.id;


--
-- Name: watchlist_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watchlist_rules (
    id bigint NOT NULL,
    watchlist_id bigint NOT NULL,
    player_id bigint,
    team_id bigint,
    brand text,
    product_line text,
    season text,
    set_id bigint,
    card_number text,
    parallel text,
    rookie_only boolean DEFAULT false NOT NULL,
    autograph_only boolean DEFAULT false NOT NULL,
    relic_only boolean DEFAULT false NOT NULL,
    serial_numbered_only boolean DEFAULT false NOT NULL,
    graded_only boolean DEFAULT false NOT NULL,
    raw_only boolean DEFAULT false NOT NULL,
    min_price numeric(12,2),
    max_price numeric(12,2),
    currency text DEFAULT 'NZD'::text,
    include_terms text,
    exclude_terms text,
    minimum_match_confidence numeric(4,3) DEFAULT 0.75 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    intent_type text DEFAULT 'custom'::text NOT NULL,
    catalogue_card_id bigint,
    catalogue_variant_id bigint,
    CONSTRAINT watchlist_rules_intent_type_check CHECK ((intent_type = ANY (ARRAY['custom'::text, 'player'::text, 'team'::text, 'set'::text, 'card'::text, 'variant'::text])))
);


--
-- Name: COLUMN watchlist_rules.intent_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.watchlist_rules.intent_type IS 'Stage 1 catalogue-backed watchlist intent marker. Matching remains unchanged until later stages.';


--
-- Name: COLUMN watchlist_rules.catalogue_card_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.watchlist_rules.catalogue_card_id IS 'Optional catalogue card selected by the user. Stage 1 stores this without changing matching logic.';


--
-- Name: COLUMN watchlist_rules.catalogue_variant_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.watchlist_rules.catalogue_variant_id IS 'Optional catalogue variant selected by the user. Stage 1 stores this without changing matching logic.';


--
-- Name: watchlist_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.watchlist_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: watchlist_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.watchlist_rules_id_seq OWNED BY public.watchlist_rules.id;


--
-- Name: watchlists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watchlists (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notification_enabled boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: watchlists_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.watchlists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: watchlists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.watchlists_id_seq OWNED BY public.watchlists.id;


--
-- Name: admin_audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log ALTER COLUMN id SET DEFAULT nextval('public.admin_audit_log_id_seq'::regclass);


--
-- Name: alerts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts ALTER COLUMN id SET DEFAULT nextval('public.alerts_id_seq'::regclass);


--
-- Name: card_catalogue_cards id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_catalogue_cards ALTER COLUMN id SET DEFAULT nextval('public.card_catalogue_cards_id_seq'::regclass);


--
-- Name: card_catalogue_sets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_catalogue_sets ALTER COLUMN id SET DEFAULT nextval('public.card_catalogue_sets_id_seq'::regclass);


--
-- Name: card_catalogue_variants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_catalogue_variants ALTER COLUMN id SET DEFAULT nextval('public.card_catalogue_variants_id_seq'::regclass);


--
-- Name: listings_feed id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listings_feed ALTER COLUMN id SET DEFAULT nextval('public.listings_feed_id_seq'::regclass);


--
-- Name: match_feedback id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_feedback ALTER COLUMN id SET DEFAULT nextval('public.match_feedback_id_seq'::regclass);


--
-- Name: player_aliases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_aliases ALTER COLUMN id SET DEFAULT nextval('public.player_aliases_id_seq'::regclass);


--
-- Name: players id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players ALTER COLUMN id SET DEFAULT nextval('public.players_id_seq'::regclass);


--
-- Name: product_availability_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability_events ALTER COLUMN id SET DEFAULT nextval('public.product_availability_events_id_seq'::regclass);


--
-- Name: product_card_matches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_card_matches ALTER COLUMN id SET DEFAULT nextval('public.product_card_matches_id_seq'::regclass);


--
-- Name: product_classifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_classifications ALTER COLUMN id SET DEFAULT nextval('public.product_classifications_id_seq'::regclass);


--
-- Name: product_snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_snapshots ALTER COLUMN id SET DEFAULT nextval('public.product_snapshots_id_seq'::regclass);


--
-- Name: profiles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles ALTER COLUMN id SET DEFAULT nextval('public.profiles_id_seq'::regclass);


--
-- Name: reference_checklists id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reference_checklists ALTER COLUMN id SET DEFAULT nextval('public.reference_checklists_id_seq'::regclass);


--
-- Name: scan_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_jobs ALTER COLUMN id SET DEFAULT nextval('public.scan_jobs_id_seq'::regclass);


--
-- Name: scan_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_runs ALTER COLUMN id SET DEFAULT nextval('public.scan_runs_id_seq'::regclass);


--
-- Name: store_products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_products ALTER COLUMN id SET DEFAULT nextval('public.store_products_id_seq'::regclass);


--
-- Name: store_scan_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_scan_jobs ALTER COLUMN id SET DEFAULT nextval('public.store_scan_jobs_id_seq'::regclass);


--
-- Name: store_scan_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_scan_runs ALTER COLUMN id SET DEFAULT nextval('public.store_scan_runs_id_seq'::regclass);


--
-- Name: stores id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stores ALTER COLUMN id SET DEFAULT nextval('public.stores_id_seq'::regclass);


--
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams ALTER COLUMN id SET DEFAULT nextval('public.teams_id_seq'::regclass);


--
-- Name: watchlist id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlist ALTER COLUMN id SET DEFAULT nextval('public.watchlist_id_seq'::regclass);


--
-- Name: watchlist_matches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlist_matches ALTER COLUMN id SET DEFAULT nextval('public.watchlist_matches_id_seq'::regclass);


--
-- Name: watchlist_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlist_rules ALTER COLUMN id SET DEFAULT nextval('public.watchlist_rules_id_seq'::regclass);


--
-- Name: watchlists id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlists ALTER COLUMN id SET DEFAULT nextval('public.watchlists_id_seq'::regclass);


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (id, email) FROM stdin;
11111111-1111-1111-1111-111111111111	a@x
22222222-2222-2222-2222-222222222222	b@x
\.


--
-- Data for Name: admin_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_audit_log (id, admin_user_id, action, target_type, target_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alerts (id, user_id, watchlist_id, watchlist_match_id, store_product_id, product_card_match_id, event_type, channel, status, dedupe_key, recipient_email, subject, payload, provider, provider_message_id, attempts, next_attempt_at, error_message, sent_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card_catalogue_cards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.card_catalogue_cards (id, set_id, player_id, team_id, card_number, subset, is_rookie, is_insert, is_autograph, is_relic, verification_status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card_catalogue_sets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.card_catalogue_sets (id, brand, product_line, season, sport, league, release_year, source, verification_status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card_catalogue_variants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.card_catalogue_variants (id, card_id, parallel_name, normalized_parallel_name, serial_limit, colour, is_one_of_one, verification_status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: listings_feed; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listings_feed (id, external_id, source, title, price, url, image_url, match_type, is_dismissed, is_oos, created_at, year, set_name, card_number, player_name, variant, is_serial, serial_number, is_auto, is_rookie, category, serial_current, serial_limit, match_confidence, match_status, match_reasons, unmatched_fields, matcher_version) FROM stdin;
\.


--
-- Data for Name: match_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.match_feedback (id, user_id, store_product_id, product_card_match_id, feedback_type, feedback_notes, created_at) FROM stdin;
1	11111111-1111-1111-1111-111111111111	1	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
2	11111111-1111-1111-1111-111111111111	18	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
3	11111111-1111-1111-1111-111111111111	35	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
4	11111111-1111-1111-1111-111111111111	52	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
5	11111111-1111-1111-1111-111111111111	69	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
6	11111111-1111-1111-1111-111111111111	86	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
7	11111111-1111-1111-1111-111111111111	103	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
8	11111111-1111-1111-1111-111111111111	120	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
9	11111111-1111-1111-1111-111111111111	137	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
10	11111111-1111-1111-1111-111111111111	154	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
11	11111111-1111-1111-1111-111111111111	171	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
12	11111111-1111-1111-1111-111111111111	188	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
13	11111111-1111-1111-1111-111111111111	205	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
14	11111111-1111-1111-1111-111111111111	222	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
15	11111111-1111-1111-1111-111111111111	239	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
16	11111111-1111-1111-1111-111111111111	256	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
17	11111111-1111-1111-1111-111111111111	273	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
18	11111111-1111-1111-1111-111111111111	290	\N	dismiss	\N	2026-10-10 08:37:40.880987+00
19	11111111-1111-1111-1111-111111111111	2	\N	not_match	\N	2026-10-10 08:37:40.882396+00
20	11111111-1111-1111-1111-111111111111	21	\N	not_match	\N	2026-10-10 08:37:40.882396+00
21	11111111-1111-1111-1111-111111111111	40	\N	not_match	\N	2026-10-10 08:37:40.882396+00
22	11111111-1111-1111-1111-111111111111	59	\N	not_match	\N	2026-10-10 08:37:40.882396+00
23	11111111-1111-1111-1111-111111111111	78	\N	not_match	\N	2026-10-10 08:37:40.882396+00
24	11111111-1111-1111-1111-111111111111	97	\N	not_match	\N	2026-10-10 08:37:40.882396+00
25	11111111-1111-1111-1111-111111111111	116	\N	not_match	\N	2026-10-10 08:37:40.882396+00
26	11111111-1111-1111-1111-111111111111	135	\N	not_match	\N	2026-10-10 08:37:40.882396+00
27	11111111-1111-1111-1111-111111111111	154	\N	not_match	\N	2026-10-10 08:37:40.882396+00
28	11111111-1111-1111-1111-111111111111	173	\N	not_match	\N	2026-10-10 08:37:40.882396+00
29	11111111-1111-1111-1111-111111111111	192	\N	not_match	\N	2026-10-10 08:37:40.882396+00
30	11111111-1111-1111-1111-111111111111	211	\N	not_match	\N	2026-10-10 08:37:40.882396+00
31	11111111-1111-1111-1111-111111111111	230	\N	not_match	\N	2026-10-10 08:37:40.882396+00
32	11111111-1111-1111-1111-111111111111	249	\N	not_match	\N	2026-10-10 08:37:40.882396+00
33	11111111-1111-1111-1111-111111111111	268	\N	not_match	\N	2026-10-10 08:37:40.882396+00
34	11111111-1111-1111-1111-111111111111	287	\N	not_match	\N	2026-10-10 08:37:40.882396+00
35	11111111-1111-1111-1111-111111111111	3	\N	save	\N	2026-10-09 08:37:40.883375+00
36	11111111-1111-1111-1111-111111111111	7	\N	save	\N	2026-10-09 08:37:40.883375+00
37	11111111-1111-1111-1111-111111111111	11	\N	save	\N	2026-10-09 08:37:40.883375+00
38	11111111-1111-1111-1111-111111111111	15	\N	save	\N	2026-10-09 08:37:40.883375+00
39	11111111-1111-1111-1111-111111111111	19	\N	save	\N	2026-10-09 08:37:40.883375+00
40	11111111-1111-1111-1111-111111111111	23	\N	save	\N	2026-10-09 08:37:40.883375+00
41	11111111-1111-1111-1111-111111111111	27	\N	save	\N	2026-10-09 08:37:40.883375+00
42	11111111-1111-1111-1111-111111111111	31	\N	save	\N	2026-10-09 08:37:40.883375+00
43	11111111-1111-1111-1111-111111111111	35	\N	save	\N	2026-10-09 08:37:40.883375+00
44	11111111-1111-1111-1111-111111111111	39	\N	save	\N	2026-10-09 08:37:40.883375+00
45	11111111-1111-1111-1111-111111111111	43	\N	save	\N	2026-10-09 08:37:40.883375+00
46	11111111-1111-1111-1111-111111111111	47	\N	save	\N	2026-10-09 08:37:40.883375+00
47	11111111-1111-1111-1111-111111111111	51	\N	save	\N	2026-10-09 08:37:40.883375+00
48	11111111-1111-1111-1111-111111111111	55	\N	save	\N	2026-10-09 08:37:40.883375+00
49	11111111-1111-1111-1111-111111111111	59	\N	save	\N	2026-10-09 08:37:40.883375+00
50	11111111-1111-1111-1111-111111111111	63	\N	save	\N	2026-10-09 08:37:40.883375+00
51	11111111-1111-1111-1111-111111111111	67	\N	save	\N	2026-10-09 08:37:40.883375+00
52	11111111-1111-1111-1111-111111111111	71	\N	save	\N	2026-10-09 08:37:40.883375+00
53	11111111-1111-1111-1111-111111111111	75	\N	save	\N	2026-10-09 08:37:40.883375+00
54	11111111-1111-1111-1111-111111111111	79	\N	save	\N	2026-10-09 08:37:40.883375+00
55	11111111-1111-1111-1111-111111111111	83	\N	save	\N	2026-10-09 08:37:40.883375+00
56	11111111-1111-1111-1111-111111111111	87	\N	save	\N	2026-10-09 08:37:40.883375+00
57	11111111-1111-1111-1111-111111111111	91	\N	save	\N	2026-10-09 08:37:40.883375+00
58	11111111-1111-1111-1111-111111111111	95	\N	save	\N	2026-10-09 08:37:40.883375+00
59	11111111-1111-1111-1111-111111111111	99	\N	save	\N	2026-10-09 08:37:40.883375+00
60	11111111-1111-1111-1111-111111111111	103	\N	save	\N	2026-10-09 08:37:40.883375+00
61	11111111-1111-1111-1111-111111111111	107	\N	save	\N	2026-10-09 08:37:40.883375+00
62	11111111-1111-1111-1111-111111111111	111	\N	save	\N	2026-10-09 08:37:40.883375+00
63	11111111-1111-1111-1111-111111111111	115	\N	save	\N	2026-10-09 08:37:40.883375+00
64	11111111-1111-1111-1111-111111111111	119	\N	save	\N	2026-10-09 08:37:40.883375+00
65	11111111-1111-1111-1111-111111111111	123	\N	save	\N	2026-10-09 08:37:40.883375+00
66	11111111-1111-1111-1111-111111111111	127	\N	save	\N	2026-10-09 08:37:40.883375+00
67	11111111-1111-1111-1111-111111111111	131	\N	save	\N	2026-10-09 08:37:40.883375+00
68	11111111-1111-1111-1111-111111111111	135	\N	save	\N	2026-10-09 08:37:40.883375+00
69	11111111-1111-1111-1111-111111111111	139	\N	save	\N	2026-10-09 08:37:40.883375+00
70	11111111-1111-1111-1111-111111111111	143	\N	save	\N	2026-10-09 08:37:40.883375+00
71	11111111-1111-1111-1111-111111111111	147	\N	save	\N	2026-10-09 08:37:40.883375+00
72	11111111-1111-1111-1111-111111111111	151	\N	save	\N	2026-10-09 08:37:40.883375+00
73	11111111-1111-1111-1111-111111111111	155	\N	save	\N	2026-10-09 08:37:40.883375+00
74	11111111-1111-1111-1111-111111111111	159	\N	save	\N	2026-10-09 08:37:40.883375+00
75	11111111-1111-1111-1111-111111111111	163	\N	save	\N	2026-10-09 08:37:40.883375+00
76	11111111-1111-1111-1111-111111111111	167	\N	save	\N	2026-10-09 08:37:40.883375+00
77	11111111-1111-1111-1111-111111111111	171	\N	save	\N	2026-10-09 08:37:40.883375+00
78	11111111-1111-1111-1111-111111111111	175	\N	save	\N	2026-10-09 08:37:40.883375+00
79	11111111-1111-1111-1111-111111111111	179	\N	save	\N	2026-10-09 08:37:40.883375+00
80	11111111-1111-1111-1111-111111111111	183	\N	save	\N	2026-10-09 08:37:40.883375+00
81	11111111-1111-1111-1111-111111111111	187	\N	save	\N	2026-10-09 08:37:40.883375+00
82	11111111-1111-1111-1111-111111111111	191	\N	save	\N	2026-10-09 08:37:40.883375+00
83	11111111-1111-1111-1111-111111111111	195	\N	save	\N	2026-10-09 08:37:40.883375+00
84	11111111-1111-1111-1111-111111111111	199	\N	save	\N	2026-10-09 08:37:40.883375+00
85	11111111-1111-1111-1111-111111111111	203	\N	save	\N	2026-10-09 08:37:40.883375+00
86	11111111-1111-1111-1111-111111111111	207	\N	save	\N	2026-10-09 08:37:40.883375+00
87	11111111-1111-1111-1111-111111111111	211	\N	save	\N	2026-10-09 08:37:40.883375+00
88	11111111-1111-1111-1111-111111111111	215	\N	save	\N	2026-10-09 08:37:40.883375+00
89	11111111-1111-1111-1111-111111111111	219	\N	save	\N	2026-10-09 08:37:40.883375+00
90	11111111-1111-1111-1111-111111111111	223	\N	save	\N	2026-10-09 08:37:40.883375+00
91	11111111-1111-1111-1111-111111111111	227	\N	save	\N	2026-10-09 08:37:40.883375+00
92	11111111-1111-1111-1111-111111111111	231	\N	save	\N	2026-10-09 08:37:40.883375+00
93	11111111-1111-1111-1111-111111111111	235	\N	save	\N	2026-10-09 08:37:40.883375+00
94	11111111-1111-1111-1111-111111111111	239	\N	save	\N	2026-10-09 08:37:40.883375+00
95	11111111-1111-1111-1111-111111111111	243	\N	save	\N	2026-10-09 08:37:40.883375+00
96	11111111-1111-1111-1111-111111111111	247	\N	save	\N	2026-10-09 08:37:40.883375+00
97	11111111-1111-1111-1111-111111111111	251	\N	save	\N	2026-10-09 08:37:40.883375+00
98	11111111-1111-1111-1111-111111111111	255	\N	save	\N	2026-10-09 08:37:40.883375+00
99	11111111-1111-1111-1111-111111111111	259	\N	save	\N	2026-10-09 08:37:40.883375+00
100	11111111-1111-1111-1111-111111111111	263	\N	save	\N	2026-10-09 08:37:40.883375+00
101	11111111-1111-1111-1111-111111111111	267	\N	save	\N	2026-10-09 08:37:40.883375+00
102	11111111-1111-1111-1111-111111111111	271	\N	save	\N	2026-10-09 08:37:40.883375+00
103	11111111-1111-1111-1111-111111111111	275	\N	save	\N	2026-10-09 08:37:40.883375+00
104	11111111-1111-1111-1111-111111111111	279	\N	save	\N	2026-10-09 08:37:40.883375+00
105	11111111-1111-1111-1111-111111111111	283	\N	save	\N	2026-10-09 08:37:40.883375+00
106	11111111-1111-1111-1111-111111111111	287	\N	save	\N	2026-10-09 08:37:40.883375+00
107	11111111-1111-1111-1111-111111111111	291	\N	save	\N	2026-10-09 08:37:40.883375+00
108	11111111-1111-1111-1111-111111111111	295	\N	save	\N	2026-10-09 08:37:40.883375+00
109	11111111-1111-1111-1111-111111111111	299	\N	save	\N	2026-10-09 08:37:40.883375+00
110	11111111-1111-1111-1111-111111111111	3	\N	unsave	\N	2026-10-10 08:37:40.885303+00
111	11111111-1111-1111-1111-111111111111	15	\N	unsave	\N	2026-10-10 08:37:40.885303+00
112	11111111-1111-1111-1111-111111111111	27	\N	unsave	\N	2026-10-10 08:37:40.885303+00
113	11111111-1111-1111-1111-111111111111	39	\N	unsave	\N	2026-10-10 08:37:40.885303+00
114	11111111-1111-1111-1111-111111111111	51	\N	unsave	\N	2026-10-10 08:37:40.885303+00
115	11111111-1111-1111-1111-111111111111	63	\N	unsave	\N	2026-10-10 08:37:40.885303+00
116	11111111-1111-1111-1111-111111111111	75	\N	unsave	\N	2026-10-10 08:37:40.885303+00
117	11111111-1111-1111-1111-111111111111	87	\N	unsave	\N	2026-10-10 08:37:40.885303+00
118	11111111-1111-1111-1111-111111111111	99	\N	unsave	\N	2026-10-10 08:37:40.885303+00
119	11111111-1111-1111-1111-111111111111	111	\N	unsave	\N	2026-10-10 08:37:40.885303+00
120	11111111-1111-1111-1111-111111111111	123	\N	unsave	\N	2026-10-10 08:37:40.885303+00
121	11111111-1111-1111-1111-111111111111	135	\N	unsave	\N	2026-10-10 08:37:40.885303+00
122	11111111-1111-1111-1111-111111111111	147	\N	unsave	\N	2026-10-10 08:37:40.885303+00
123	11111111-1111-1111-1111-111111111111	159	\N	unsave	\N	2026-10-10 08:37:40.885303+00
124	11111111-1111-1111-1111-111111111111	171	\N	unsave	\N	2026-10-10 08:37:40.885303+00
125	11111111-1111-1111-1111-111111111111	183	\N	unsave	\N	2026-10-10 08:37:40.885303+00
126	11111111-1111-1111-1111-111111111111	195	\N	unsave	\N	2026-10-10 08:37:40.885303+00
127	11111111-1111-1111-1111-111111111111	207	\N	unsave	\N	2026-10-10 08:37:40.885303+00
128	11111111-1111-1111-1111-111111111111	219	\N	unsave	\N	2026-10-10 08:37:40.885303+00
129	11111111-1111-1111-1111-111111111111	231	\N	unsave	\N	2026-10-10 08:37:40.885303+00
130	11111111-1111-1111-1111-111111111111	243	\N	unsave	\N	2026-10-10 08:37:40.885303+00
131	11111111-1111-1111-1111-111111111111	255	\N	unsave	\N	2026-10-10 08:37:40.885303+00
132	11111111-1111-1111-1111-111111111111	267	\N	unsave	\N	2026-10-10 08:37:40.885303+00
133	11111111-1111-1111-1111-111111111111	279	\N	unsave	\N	2026-10-10 08:37:40.885303+00
134	11111111-1111-1111-1111-111111111111	291	\N	unsave	\N	2026-10-10 08:37:40.885303+00
135	22222222-2222-2222-2222-222222222222	1	\N	save	\N	2026-10-10 08:37:40.886379+00
136	22222222-2222-2222-2222-222222222222	2	\N	save	\N	2026-10-10 08:37:40.886379+00
137	22222222-2222-2222-2222-222222222222	3	\N	save	\N	2026-10-10 08:37:40.886379+00
138	22222222-2222-2222-2222-222222222222	4	\N	save	\N	2026-10-10 08:37:40.886379+00
139	22222222-2222-2222-2222-222222222222	5	\N	save	\N	2026-10-10 08:37:40.886379+00
140	22222222-2222-2222-2222-222222222222	6	\N	save	\N	2026-10-10 08:37:40.886379+00
141	22222222-2222-2222-2222-222222222222	7	\N	save	\N	2026-10-10 08:37:40.886379+00
142	22222222-2222-2222-2222-222222222222	8	\N	save	\N	2026-10-10 08:37:40.886379+00
143	22222222-2222-2222-2222-222222222222	9	\N	save	\N	2026-10-10 08:37:40.886379+00
144	22222222-2222-2222-2222-222222222222	10	\N	save	\N	2026-10-10 08:37:40.886379+00
145	22222222-2222-2222-2222-222222222222	11	\N	save	\N	2026-10-10 08:37:40.886379+00
146	22222222-2222-2222-2222-222222222222	12	\N	save	\N	2026-10-10 08:37:40.886379+00
147	22222222-2222-2222-2222-222222222222	13	\N	save	\N	2026-10-10 08:37:40.886379+00
148	22222222-2222-2222-2222-222222222222	14	\N	save	\N	2026-10-10 08:37:40.886379+00
149	22222222-2222-2222-2222-222222222222	15	\N	save	\N	2026-10-10 08:37:40.886379+00
150	22222222-2222-2222-2222-222222222222	16	\N	save	\N	2026-10-10 08:37:40.886379+00
151	22222222-2222-2222-2222-222222222222	17	\N	save	\N	2026-10-10 08:37:40.886379+00
152	22222222-2222-2222-2222-222222222222	18	\N	save	\N	2026-10-10 08:37:40.886379+00
153	22222222-2222-2222-2222-222222222222	19	\N	save	\N	2026-10-10 08:37:40.886379+00
154	22222222-2222-2222-2222-222222222222	20	\N	save	\N	2026-10-10 08:37:40.886379+00
155	22222222-2222-2222-2222-222222222222	21	\N	save	\N	2026-10-10 08:37:40.886379+00
156	22222222-2222-2222-2222-222222222222	22	\N	save	\N	2026-10-10 08:37:40.886379+00
157	22222222-2222-2222-2222-222222222222	23	\N	save	\N	2026-10-10 08:37:40.886379+00
158	22222222-2222-2222-2222-222222222222	24	\N	save	\N	2026-10-10 08:37:40.886379+00
159	22222222-2222-2222-2222-222222222222	25	\N	save	\N	2026-10-10 08:37:40.886379+00
160	22222222-2222-2222-2222-222222222222	26	\N	save	\N	2026-10-10 08:37:40.886379+00
161	22222222-2222-2222-2222-222222222222	27	\N	save	\N	2026-10-10 08:37:40.886379+00
162	22222222-2222-2222-2222-222222222222	28	\N	save	\N	2026-10-10 08:37:40.886379+00
163	22222222-2222-2222-2222-222222222222	29	\N	save	\N	2026-10-10 08:37:40.886379+00
164	22222222-2222-2222-2222-222222222222	30	\N	save	\N	2026-10-10 08:37:40.886379+00
165	22222222-2222-2222-2222-222222222222	31	\N	save	\N	2026-10-10 08:37:40.886379+00
166	22222222-2222-2222-2222-222222222222	32	\N	save	\N	2026-10-10 08:37:40.886379+00
167	22222222-2222-2222-2222-222222222222	33	\N	save	\N	2026-10-10 08:37:40.886379+00
168	22222222-2222-2222-2222-222222222222	34	\N	save	\N	2026-10-10 08:37:40.886379+00
169	22222222-2222-2222-2222-222222222222	35	\N	save	\N	2026-10-10 08:37:40.886379+00
170	22222222-2222-2222-2222-222222222222	36	\N	save	\N	2026-10-10 08:37:40.886379+00
171	22222222-2222-2222-2222-222222222222	37	\N	save	\N	2026-10-10 08:37:40.886379+00
172	22222222-2222-2222-2222-222222222222	38	\N	save	\N	2026-10-10 08:37:40.886379+00
173	22222222-2222-2222-2222-222222222222	39	\N	save	\N	2026-10-10 08:37:40.886379+00
174	22222222-2222-2222-2222-222222222222	40	\N	save	\N	2026-10-10 08:37:40.886379+00
175	22222222-2222-2222-2222-222222222222	41	\N	save	\N	2026-10-10 08:37:40.886379+00
176	22222222-2222-2222-2222-222222222222	42	\N	save	\N	2026-10-10 08:37:40.886379+00
177	22222222-2222-2222-2222-222222222222	43	\N	save	\N	2026-10-10 08:37:40.886379+00
178	22222222-2222-2222-2222-222222222222	44	\N	save	\N	2026-10-10 08:37:40.886379+00
179	22222222-2222-2222-2222-222222222222	45	\N	save	\N	2026-10-10 08:37:40.886379+00
180	22222222-2222-2222-2222-222222222222	46	\N	save	\N	2026-10-10 08:37:40.886379+00
181	22222222-2222-2222-2222-222222222222	47	\N	save	\N	2026-10-10 08:37:40.886379+00
182	22222222-2222-2222-2222-222222222222	48	\N	save	\N	2026-10-10 08:37:40.886379+00
183	22222222-2222-2222-2222-222222222222	49	\N	save	\N	2026-10-10 08:37:40.886379+00
184	22222222-2222-2222-2222-222222222222	50	\N	save	\N	2026-10-10 08:37:40.886379+00
185	22222222-2222-2222-2222-222222222222	51	\N	save	\N	2026-10-10 08:37:40.886379+00
186	22222222-2222-2222-2222-222222222222	52	\N	save	\N	2026-10-10 08:37:40.886379+00
187	22222222-2222-2222-2222-222222222222	53	\N	save	\N	2026-10-10 08:37:40.886379+00
188	22222222-2222-2222-2222-222222222222	54	\N	save	\N	2026-10-10 08:37:40.886379+00
189	22222222-2222-2222-2222-222222222222	55	\N	save	\N	2026-10-10 08:37:40.886379+00
190	22222222-2222-2222-2222-222222222222	56	\N	save	\N	2026-10-10 08:37:40.886379+00
191	22222222-2222-2222-2222-222222222222	57	\N	save	\N	2026-10-10 08:37:40.886379+00
192	22222222-2222-2222-2222-222222222222	58	\N	save	\N	2026-10-10 08:37:40.886379+00
193	22222222-2222-2222-2222-222222222222	59	\N	save	\N	2026-10-10 08:37:40.886379+00
194	22222222-2222-2222-2222-222222222222	60	\N	save	\N	2026-10-10 08:37:40.886379+00
195	22222222-2222-2222-2222-222222222222	61	\N	save	\N	2026-10-10 08:37:40.886379+00
196	22222222-2222-2222-2222-222222222222	62	\N	save	\N	2026-10-10 08:37:40.886379+00
197	22222222-2222-2222-2222-222222222222	63	\N	save	\N	2026-10-10 08:37:40.886379+00
198	22222222-2222-2222-2222-222222222222	64	\N	save	\N	2026-10-10 08:37:40.886379+00
199	22222222-2222-2222-2222-222222222222	65	\N	save	\N	2026-10-10 08:37:40.886379+00
200	22222222-2222-2222-2222-222222222222	66	\N	save	\N	2026-10-10 08:37:40.886379+00
201	22222222-2222-2222-2222-222222222222	67	\N	save	\N	2026-10-10 08:37:40.886379+00
202	22222222-2222-2222-2222-222222222222	68	\N	save	\N	2026-10-10 08:37:40.886379+00
203	22222222-2222-2222-2222-222222222222	69	\N	save	\N	2026-10-10 08:37:40.886379+00
204	22222222-2222-2222-2222-222222222222	70	\N	save	\N	2026-10-10 08:37:40.886379+00
205	22222222-2222-2222-2222-222222222222	71	\N	save	\N	2026-10-10 08:37:40.886379+00
206	22222222-2222-2222-2222-222222222222	72	\N	save	\N	2026-10-10 08:37:40.886379+00
207	22222222-2222-2222-2222-222222222222	73	\N	save	\N	2026-10-10 08:37:40.886379+00
208	22222222-2222-2222-2222-222222222222	74	\N	save	\N	2026-10-10 08:37:40.886379+00
209	22222222-2222-2222-2222-222222222222	75	\N	save	\N	2026-10-10 08:37:40.886379+00
210	22222222-2222-2222-2222-222222222222	76	\N	save	\N	2026-10-10 08:37:40.886379+00
211	22222222-2222-2222-2222-222222222222	77	\N	save	\N	2026-10-10 08:37:40.886379+00
212	22222222-2222-2222-2222-222222222222	78	\N	save	\N	2026-10-10 08:37:40.886379+00
213	22222222-2222-2222-2222-222222222222	79	\N	save	\N	2026-10-10 08:37:40.886379+00
214	22222222-2222-2222-2222-222222222222	80	\N	save	\N	2026-10-10 08:37:40.886379+00
215	22222222-2222-2222-2222-222222222222	81	\N	save	\N	2026-10-10 08:37:40.886379+00
216	22222222-2222-2222-2222-222222222222	82	\N	save	\N	2026-10-10 08:37:40.886379+00
217	22222222-2222-2222-2222-222222222222	83	\N	save	\N	2026-10-10 08:37:40.886379+00
218	22222222-2222-2222-2222-222222222222	84	\N	save	\N	2026-10-10 08:37:40.886379+00
219	22222222-2222-2222-2222-222222222222	85	\N	save	\N	2026-10-10 08:37:40.886379+00
220	22222222-2222-2222-2222-222222222222	86	\N	save	\N	2026-10-10 08:37:40.886379+00
221	22222222-2222-2222-2222-222222222222	87	\N	save	\N	2026-10-10 08:37:40.886379+00
222	22222222-2222-2222-2222-222222222222	88	\N	save	\N	2026-10-10 08:37:40.886379+00
223	22222222-2222-2222-2222-222222222222	89	\N	save	\N	2026-10-10 08:37:40.886379+00
224	22222222-2222-2222-2222-222222222222	90	\N	save	\N	2026-10-10 08:37:40.886379+00
225	22222222-2222-2222-2222-222222222222	91	\N	save	\N	2026-10-10 08:37:40.886379+00
226	22222222-2222-2222-2222-222222222222	92	\N	save	\N	2026-10-10 08:37:40.886379+00
227	22222222-2222-2222-2222-222222222222	93	\N	save	\N	2026-10-10 08:37:40.886379+00
228	22222222-2222-2222-2222-222222222222	94	\N	save	\N	2026-10-10 08:37:40.886379+00
229	22222222-2222-2222-2222-222222222222	95	\N	save	\N	2026-10-10 08:37:40.886379+00
230	22222222-2222-2222-2222-222222222222	96	\N	save	\N	2026-10-10 08:37:40.886379+00
231	22222222-2222-2222-2222-222222222222	97	\N	save	\N	2026-10-10 08:37:40.886379+00
232	22222222-2222-2222-2222-222222222222	98	\N	save	\N	2026-10-10 08:37:40.886379+00
233	22222222-2222-2222-2222-222222222222	99	\N	save	\N	2026-10-10 08:37:40.886379+00
234	22222222-2222-2222-2222-222222222222	100	\N	save	\N	2026-10-10 08:37:40.886379+00
235	22222222-2222-2222-2222-222222222222	101	\N	save	\N	2026-10-10 08:37:40.886379+00
236	22222222-2222-2222-2222-222222222222	102	\N	save	\N	2026-10-10 08:37:40.886379+00
237	22222222-2222-2222-2222-222222222222	103	\N	save	\N	2026-10-10 08:37:40.886379+00
238	22222222-2222-2222-2222-222222222222	104	\N	save	\N	2026-10-10 08:37:40.886379+00
239	22222222-2222-2222-2222-222222222222	105	\N	save	\N	2026-10-10 08:37:40.886379+00
240	22222222-2222-2222-2222-222222222222	106	\N	save	\N	2026-10-10 08:37:40.886379+00
241	22222222-2222-2222-2222-222222222222	107	\N	save	\N	2026-10-10 08:37:40.886379+00
242	22222222-2222-2222-2222-222222222222	108	\N	save	\N	2026-10-10 08:37:40.886379+00
243	22222222-2222-2222-2222-222222222222	109	\N	save	\N	2026-10-10 08:37:40.886379+00
244	22222222-2222-2222-2222-222222222222	110	\N	save	\N	2026-10-10 08:37:40.886379+00
245	22222222-2222-2222-2222-222222222222	111	\N	save	\N	2026-10-10 08:37:40.886379+00
246	22222222-2222-2222-2222-222222222222	112	\N	save	\N	2026-10-10 08:37:40.886379+00
247	22222222-2222-2222-2222-222222222222	113	\N	save	\N	2026-10-10 08:37:40.886379+00
248	22222222-2222-2222-2222-222222222222	114	\N	save	\N	2026-10-10 08:37:40.886379+00
249	22222222-2222-2222-2222-222222222222	115	\N	save	\N	2026-10-10 08:37:40.886379+00
250	22222222-2222-2222-2222-222222222222	116	\N	save	\N	2026-10-10 08:37:40.886379+00
251	22222222-2222-2222-2222-222222222222	117	\N	save	\N	2026-10-10 08:37:40.886379+00
252	22222222-2222-2222-2222-222222222222	118	\N	save	\N	2026-10-10 08:37:40.886379+00
253	22222222-2222-2222-2222-222222222222	119	\N	save	\N	2026-10-10 08:37:40.886379+00
254	22222222-2222-2222-2222-222222222222	120	\N	save	\N	2026-10-10 08:37:40.886379+00
255	22222222-2222-2222-2222-222222222222	121	\N	save	\N	2026-10-10 08:37:40.886379+00
256	22222222-2222-2222-2222-222222222222	122	\N	save	\N	2026-10-10 08:37:40.886379+00
257	22222222-2222-2222-2222-222222222222	123	\N	save	\N	2026-10-10 08:37:40.886379+00
258	22222222-2222-2222-2222-222222222222	124	\N	save	\N	2026-10-10 08:37:40.886379+00
259	22222222-2222-2222-2222-222222222222	125	\N	save	\N	2026-10-10 08:37:40.886379+00
260	22222222-2222-2222-2222-222222222222	126	\N	save	\N	2026-10-10 08:37:40.886379+00
261	22222222-2222-2222-2222-222222222222	127	\N	save	\N	2026-10-10 08:37:40.886379+00
262	22222222-2222-2222-2222-222222222222	128	\N	save	\N	2026-10-10 08:37:40.886379+00
263	22222222-2222-2222-2222-222222222222	129	\N	save	\N	2026-10-10 08:37:40.886379+00
264	22222222-2222-2222-2222-222222222222	130	\N	save	\N	2026-10-10 08:37:40.886379+00
265	22222222-2222-2222-2222-222222222222	131	\N	save	\N	2026-10-10 08:37:40.886379+00
266	22222222-2222-2222-2222-222222222222	132	\N	save	\N	2026-10-10 08:37:40.886379+00
267	22222222-2222-2222-2222-222222222222	133	\N	save	\N	2026-10-10 08:37:40.886379+00
268	22222222-2222-2222-2222-222222222222	134	\N	save	\N	2026-10-10 08:37:40.886379+00
269	22222222-2222-2222-2222-222222222222	135	\N	save	\N	2026-10-10 08:37:40.886379+00
270	22222222-2222-2222-2222-222222222222	136	\N	save	\N	2026-10-10 08:37:40.886379+00
271	22222222-2222-2222-2222-222222222222	137	\N	save	\N	2026-10-10 08:37:40.886379+00
272	22222222-2222-2222-2222-222222222222	138	\N	save	\N	2026-10-10 08:37:40.886379+00
273	22222222-2222-2222-2222-222222222222	139	\N	save	\N	2026-10-10 08:37:40.886379+00
274	22222222-2222-2222-2222-222222222222	140	\N	save	\N	2026-10-10 08:37:40.886379+00
275	22222222-2222-2222-2222-222222222222	141	\N	save	\N	2026-10-10 08:37:40.886379+00
276	22222222-2222-2222-2222-222222222222	142	\N	save	\N	2026-10-10 08:37:40.886379+00
277	22222222-2222-2222-2222-222222222222	143	\N	save	\N	2026-10-10 08:37:40.886379+00
278	22222222-2222-2222-2222-222222222222	144	\N	save	\N	2026-10-10 08:37:40.886379+00
279	22222222-2222-2222-2222-222222222222	145	\N	save	\N	2026-10-10 08:37:40.886379+00
280	22222222-2222-2222-2222-222222222222	146	\N	save	\N	2026-10-10 08:37:40.886379+00
281	22222222-2222-2222-2222-222222222222	147	\N	save	\N	2026-10-10 08:37:40.886379+00
282	22222222-2222-2222-2222-222222222222	148	\N	save	\N	2026-10-10 08:37:40.886379+00
283	22222222-2222-2222-2222-222222222222	149	\N	save	\N	2026-10-10 08:37:40.886379+00
284	22222222-2222-2222-2222-222222222222	150	\N	save	\N	2026-10-10 08:37:40.886379+00
285	22222222-2222-2222-2222-222222222222	151	\N	save	\N	2026-10-10 08:37:40.886379+00
286	22222222-2222-2222-2222-222222222222	152	\N	save	\N	2026-10-10 08:37:40.886379+00
287	22222222-2222-2222-2222-222222222222	153	\N	save	\N	2026-10-10 08:37:40.886379+00
288	22222222-2222-2222-2222-222222222222	154	\N	save	\N	2026-10-10 08:37:40.886379+00
289	22222222-2222-2222-2222-222222222222	155	\N	save	\N	2026-10-10 08:37:40.886379+00
290	22222222-2222-2222-2222-222222222222	156	\N	save	\N	2026-10-10 08:37:40.886379+00
291	22222222-2222-2222-2222-222222222222	157	\N	save	\N	2026-10-10 08:37:40.886379+00
292	22222222-2222-2222-2222-222222222222	158	\N	save	\N	2026-10-10 08:37:40.886379+00
293	22222222-2222-2222-2222-222222222222	159	\N	save	\N	2026-10-10 08:37:40.886379+00
294	22222222-2222-2222-2222-222222222222	160	\N	save	\N	2026-10-10 08:37:40.886379+00
295	22222222-2222-2222-2222-222222222222	161	\N	save	\N	2026-10-10 08:37:40.886379+00
296	22222222-2222-2222-2222-222222222222	162	\N	save	\N	2026-10-10 08:37:40.886379+00
297	22222222-2222-2222-2222-222222222222	163	\N	save	\N	2026-10-10 08:37:40.886379+00
298	22222222-2222-2222-2222-222222222222	164	\N	save	\N	2026-10-10 08:37:40.886379+00
299	22222222-2222-2222-2222-222222222222	165	\N	save	\N	2026-10-10 08:37:40.886379+00
300	22222222-2222-2222-2222-222222222222	166	\N	save	\N	2026-10-10 08:37:40.886379+00
301	22222222-2222-2222-2222-222222222222	167	\N	save	\N	2026-10-10 08:37:40.886379+00
302	22222222-2222-2222-2222-222222222222	168	\N	save	\N	2026-10-10 08:37:40.886379+00
303	22222222-2222-2222-2222-222222222222	169	\N	save	\N	2026-10-10 08:37:40.886379+00
304	22222222-2222-2222-2222-222222222222	170	\N	save	\N	2026-10-10 08:37:40.886379+00
305	22222222-2222-2222-2222-222222222222	171	\N	save	\N	2026-10-10 08:37:40.886379+00
306	22222222-2222-2222-2222-222222222222	172	\N	save	\N	2026-10-10 08:37:40.886379+00
307	22222222-2222-2222-2222-222222222222	173	\N	save	\N	2026-10-10 08:37:40.886379+00
308	22222222-2222-2222-2222-222222222222	174	\N	save	\N	2026-10-10 08:37:40.886379+00
309	22222222-2222-2222-2222-222222222222	175	\N	save	\N	2026-10-10 08:37:40.886379+00
310	22222222-2222-2222-2222-222222222222	176	\N	save	\N	2026-10-10 08:37:40.886379+00
311	22222222-2222-2222-2222-222222222222	177	\N	save	\N	2026-10-10 08:37:40.886379+00
312	22222222-2222-2222-2222-222222222222	178	\N	save	\N	2026-10-10 08:37:40.886379+00
313	22222222-2222-2222-2222-222222222222	179	\N	save	\N	2026-10-10 08:37:40.886379+00
314	22222222-2222-2222-2222-222222222222	180	\N	save	\N	2026-10-10 08:37:40.886379+00
315	22222222-2222-2222-2222-222222222222	181	\N	save	\N	2026-10-10 08:37:40.886379+00
316	22222222-2222-2222-2222-222222222222	182	\N	save	\N	2026-10-10 08:37:40.886379+00
317	22222222-2222-2222-2222-222222222222	183	\N	save	\N	2026-10-10 08:37:40.886379+00
318	22222222-2222-2222-2222-222222222222	184	\N	save	\N	2026-10-10 08:37:40.886379+00
319	22222222-2222-2222-2222-222222222222	185	\N	save	\N	2026-10-10 08:37:40.886379+00
320	22222222-2222-2222-2222-222222222222	186	\N	save	\N	2026-10-10 08:37:40.886379+00
321	22222222-2222-2222-2222-222222222222	187	\N	save	\N	2026-10-10 08:37:40.886379+00
322	22222222-2222-2222-2222-222222222222	188	\N	save	\N	2026-10-10 08:37:40.886379+00
323	22222222-2222-2222-2222-222222222222	189	\N	save	\N	2026-10-10 08:37:40.886379+00
324	22222222-2222-2222-2222-222222222222	190	\N	save	\N	2026-10-10 08:37:40.886379+00
325	22222222-2222-2222-2222-222222222222	191	\N	save	\N	2026-10-10 08:37:40.886379+00
326	22222222-2222-2222-2222-222222222222	192	\N	save	\N	2026-10-10 08:37:40.886379+00
327	22222222-2222-2222-2222-222222222222	193	\N	save	\N	2026-10-10 08:37:40.886379+00
328	22222222-2222-2222-2222-222222222222	194	\N	save	\N	2026-10-10 08:37:40.886379+00
329	22222222-2222-2222-2222-222222222222	195	\N	save	\N	2026-10-10 08:37:40.886379+00
330	22222222-2222-2222-2222-222222222222	196	\N	save	\N	2026-10-10 08:37:40.886379+00
331	22222222-2222-2222-2222-222222222222	197	\N	save	\N	2026-10-10 08:37:40.886379+00
332	22222222-2222-2222-2222-222222222222	198	\N	save	\N	2026-10-10 08:37:40.886379+00
333	22222222-2222-2222-2222-222222222222	199	\N	save	\N	2026-10-10 08:37:40.886379+00
334	22222222-2222-2222-2222-222222222222	200	\N	save	\N	2026-10-10 08:37:40.886379+00
335	22222222-2222-2222-2222-222222222222	201	\N	save	\N	2026-10-10 08:37:40.886379+00
336	22222222-2222-2222-2222-222222222222	202	\N	save	\N	2026-10-10 08:37:40.886379+00
337	22222222-2222-2222-2222-222222222222	203	\N	save	\N	2026-10-10 08:37:40.886379+00
338	22222222-2222-2222-2222-222222222222	204	\N	save	\N	2026-10-10 08:37:40.886379+00
339	22222222-2222-2222-2222-222222222222	205	\N	save	\N	2026-10-10 08:37:40.886379+00
340	22222222-2222-2222-2222-222222222222	206	\N	save	\N	2026-10-10 08:37:40.886379+00
341	22222222-2222-2222-2222-222222222222	207	\N	save	\N	2026-10-10 08:37:40.886379+00
342	22222222-2222-2222-2222-222222222222	208	\N	save	\N	2026-10-10 08:37:40.886379+00
343	22222222-2222-2222-2222-222222222222	209	\N	save	\N	2026-10-10 08:37:40.886379+00
344	22222222-2222-2222-2222-222222222222	210	\N	save	\N	2026-10-10 08:37:40.886379+00
345	22222222-2222-2222-2222-222222222222	211	\N	save	\N	2026-10-10 08:37:40.886379+00
346	22222222-2222-2222-2222-222222222222	212	\N	save	\N	2026-10-10 08:37:40.886379+00
347	22222222-2222-2222-2222-222222222222	213	\N	save	\N	2026-10-10 08:37:40.886379+00
348	22222222-2222-2222-2222-222222222222	214	\N	save	\N	2026-10-10 08:37:40.886379+00
349	22222222-2222-2222-2222-222222222222	215	\N	save	\N	2026-10-10 08:37:40.886379+00
350	22222222-2222-2222-2222-222222222222	216	\N	save	\N	2026-10-10 08:37:40.886379+00
351	22222222-2222-2222-2222-222222222222	217	\N	save	\N	2026-10-10 08:37:40.886379+00
352	22222222-2222-2222-2222-222222222222	218	\N	save	\N	2026-10-10 08:37:40.886379+00
353	22222222-2222-2222-2222-222222222222	219	\N	save	\N	2026-10-10 08:37:40.886379+00
354	22222222-2222-2222-2222-222222222222	220	\N	save	\N	2026-10-10 08:37:40.886379+00
355	22222222-2222-2222-2222-222222222222	221	\N	save	\N	2026-10-10 08:37:40.886379+00
356	22222222-2222-2222-2222-222222222222	222	\N	save	\N	2026-10-10 08:37:40.886379+00
357	22222222-2222-2222-2222-222222222222	223	\N	save	\N	2026-10-10 08:37:40.886379+00
358	22222222-2222-2222-2222-222222222222	224	\N	save	\N	2026-10-10 08:37:40.886379+00
359	22222222-2222-2222-2222-222222222222	225	\N	save	\N	2026-10-10 08:37:40.886379+00
360	22222222-2222-2222-2222-222222222222	226	\N	save	\N	2026-10-10 08:37:40.886379+00
361	22222222-2222-2222-2222-222222222222	227	\N	save	\N	2026-10-10 08:37:40.886379+00
362	22222222-2222-2222-2222-222222222222	228	\N	save	\N	2026-10-10 08:37:40.886379+00
363	22222222-2222-2222-2222-222222222222	229	\N	save	\N	2026-10-10 08:37:40.886379+00
364	22222222-2222-2222-2222-222222222222	230	\N	save	\N	2026-10-10 08:37:40.886379+00
365	22222222-2222-2222-2222-222222222222	231	\N	save	\N	2026-10-10 08:37:40.886379+00
366	22222222-2222-2222-2222-222222222222	232	\N	save	\N	2026-10-10 08:37:40.886379+00
367	22222222-2222-2222-2222-222222222222	233	\N	save	\N	2026-10-10 08:37:40.886379+00
368	22222222-2222-2222-2222-222222222222	234	\N	save	\N	2026-10-10 08:37:40.886379+00
369	22222222-2222-2222-2222-222222222222	235	\N	save	\N	2026-10-10 08:37:40.886379+00
370	22222222-2222-2222-2222-222222222222	236	\N	save	\N	2026-10-10 08:37:40.886379+00
371	22222222-2222-2222-2222-222222222222	237	\N	save	\N	2026-10-10 08:37:40.886379+00
372	22222222-2222-2222-2222-222222222222	238	\N	save	\N	2026-10-10 08:37:40.886379+00
373	22222222-2222-2222-2222-222222222222	239	\N	save	\N	2026-10-10 08:37:40.886379+00
374	22222222-2222-2222-2222-222222222222	240	\N	save	\N	2026-10-10 08:37:40.886379+00
375	22222222-2222-2222-2222-222222222222	241	\N	save	\N	2026-10-10 08:37:40.886379+00
376	22222222-2222-2222-2222-222222222222	242	\N	save	\N	2026-10-10 08:37:40.886379+00
377	22222222-2222-2222-2222-222222222222	243	\N	save	\N	2026-10-10 08:37:40.886379+00
378	22222222-2222-2222-2222-222222222222	244	\N	save	\N	2026-10-10 08:37:40.886379+00
379	22222222-2222-2222-2222-222222222222	245	\N	save	\N	2026-10-10 08:37:40.886379+00
380	22222222-2222-2222-2222-222222222222	246	\N	save	\N	2026-10-10 08:37:40.886379+00
381	22222222-2222-2222-2222-222222222222	247	\N	save	\N	2026-10-10 08:37:40.886379+00
382	22222222-2222-2222-2222-222222222222	248	\N	save	\N	2026-10-10 08:37:40.886379+00
383	22222222-2222-2222-2222-222222222222	249	\N	save	\N	2026-10-10 08:37:40.886379+00
384	22222222-2222-2222-2222-222222222222	250	\N	save	\N	2026-10-10 08:37:40.886379+00
385	22222222-2222-2222-2222-222222222222	251	\N	save	\N	2026-10-10 08:37:40.886379+00
386	22222222-2222-2222-2222-222222222222	252	\N	save	\N	2026-10-10 08:37:40.886379+00
387	22222222-2222-2222-2222-222222222222	253	\N	save	\N	2026-10-10 08:37:40.886379+00
388	22222222-2222-2222-2222-222222222222	254	\N	save	\N	2026-10-10 08:37:40.886379+00
389	22222222-2222-2222-2222-222222222222	255	\N	save	\N	2026-10-10 08:37:40.886379+00
390	22222222-2222-2222-2222-222222222222	256	\N	save	\N	2026-10-10 08:37:40.886379+00
391	22222222-2222-2222-2222-222222222222	257	\N	save	\N	2026-10-10 08:37:40.886379+00
392	22222222-2222-2222-2222-222222222222	258	\N	save	\N	2026-10-10 08:37:40.886379+00
393	22222222-2222-2222-2222-222222222222	259	\N	save	\N	2026-10-10 08:37:40.886379+00
394	22222222-2222-2222-2222-222222222222	260	\N	save	\N	2026-10-10 08:37:40.886379+00
395	22222222-2222-2222-2222-222222222222	261	\N	save	\N	2026-10-10 08:37:40.886379+00
396	22222222-2222-2222-2222-222222222222	262	\N	save	\N	2026-10-10 08:37:40.886379+00
397	22222222-2222-2222-2222-222222222222	263	\N	save	\N	2026-10-10 08:37:40.886379+00
398	22222222-2222-2222-2222-222222222222	264	\N	save	\N	2026-10-10 08:37:40.886379+00
399	22222222-2222-2222-2222-222222222222	265	\N	save	\N	2026-10-10 08:37:40.886379+00
400	22222222-2222-2222-2222-222222222222	266	\N	save	\N	2026-10-10 08:37:40.886379+00
401	22222222-2222-2222-2222-222222222222	267	\N	save	\N	2026-10-10 08:37:40.886379+00
402	22222222-2222-2222-2222-222222222222	268	\N	save	\N	2026-10-10 08:37:40.886379+00
403	22222222-2222-2222-2222-222222222222	269	\N	save	\N	2026-10-10 08:37:40.886379+00
404	22222222-2222-2222-2222-222222222222	270	\N	save	\N	2026-10-10 08:37:40.886379+00
405	22222222-2222-2222-2222-222222222222	271	\N	save	\N	2026-10-10 08:37:40.886379+00
406	22222222-2222-2222-2222-222222222222	272	\N	save	\N	2026-10-10 08:37:40.886379+00
407	22222222-2222-2222-2222-222222222222	273	\N	save	\N	2026-10-10 08:37:40.886379+00
408	22222222-2222-2222-2222-222222222222	274	\N	save	\N	2026-10-10 08:37:40.886379+00
409	22222222-2222-2222-2222-222222222222	275	\N	save	\N	2026-10-10 08:37:40.886379+00
410	22222222-2222-2222-2222-222222222222	276	\N	save	\N	2026-10-10 08:37:40.886379+00
411	22222222-2222-2222-2222-222222222222	277	\N	save	\N	2026-10-10 08:37:40.886379+00
412	22222222-2222-2222-2222-222222222222	278	\N	save	\N	2026-10-10 08:37:40.886379+00
413	22222222-2222-2222-2222-222222222222	279	\N	save	\N	2026-10-10 08:37:40.886379+00
414	22222222-2222-2222-2222-222222222222	280	\N	save	\N	2026-10-10 08:37:40.886379+00
415	22222222-2222-2222-2222-222222222222	281	\N	save	\N	2026-10-10 08:37:40.886379+00
416	22222222-2222-2222-2222-222222222222	282	\N	save	\N	2026-10-10 08:37:40.886379+00
417	22222222-2222-2222-2222-222222222222	283	\N	save	\N	2026-10-10 08:37:40.886379+00
418	22222222-2222-2222-2222-222222222222	284	\N	save	\N	2026-10-10 08:37:40.886379+00
419	22222222-2222-2222-2222-222222222222	285	\N	save	\N	2026-10-10 08:37:40.886379+00
420	22222222-2222-2222-2222-222222222222	286	\N	save	\N	2026-10-10 08:37:40.886379+00
421	22222222-2222-2222-2222-222222222222	287	\N	save	\N	2026-10-10 08:37:40.886379+00
422	22222222-2222-2222-2222-222222222222	288	\N	save	\N	2026-10-10 08:37:40.886379+00
423	22222222-2222-2222-2222-222222222222	289	\N	save	\N	2026-10-10 08:37:40.886379+00
424	22222222-2222-2222-2222-222222222222	290	\N	save	\N	2026-10-10 08:37:40.886379+00
425	22222222-2222-2222-2222-222222222222	291	\N	save	\N	2026-10-10 08:37:40.886379+00
426	22222222-2222-2222-2222-222222222222	292	\N	save	\N	2026-10-10 08:37:40.886379+00
427	22222222-2222-2222-2222-222222222222	293	\N	save	\N	2026-10-10 08:37:40.886379+00
428	22222222-2222-2222-2222-222222222222	294	\N	save	\N	2026-10-10 08:37:40.886379+00
429	22222222-2222-2222-2222-222222222222	295	\N	save	\N	2026-10-10 08:37:40.886379+00
430	22222222-2222-2222-2222-222222222222	296	\N	save	\N	2026-10-10 08:37:40.886379+00
431	22222222-2222-2222-2222-222222222222	297	\N	save	\N	2026-10-10 08:37:40.886379+00
432	22222222-2222-2222-2222-222222222222	298	\N	save	\N	2026-10-10 08:37:40.886379+00
433	22222222-2222-2222-2222-222222222222	299	\N	save	\N	2026-10-10 08:37:40.886379+00
434	22222222-2222-2222-2222-222222222222	300	\N	save	\N	2026-10-10 08:37:40.886379+00
\.


--
-- Data for Name: player_aliases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.player_aliases (id, player_id, alias, normalized_alias, source, confidence, created_at) FROM stdin;
\.


--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.players (id, full_name, normalized_name, sport, league, active, created_at) FROM stdin;
1	Victor Wembanyama	victor wembanyama	basketball	NBA	t	2026-10-10 08:37:40.844166+00
\.


--
-- Data for Name: product_availability_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_availability_events (id, store_product_id, store_id, source, external_id, event_type, detection_source, scan_token, previous_availability, current_availability, previous_price, current_price, previous_product_fingerprint, current_product_fingerprint, dedupe_key, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: product_card_matches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_card_matches (id, store_product_id, source, external_id, checklist_id, catalogue_card_id, catalogue_variant_id, matched_player_id, matched_player_name, confidence, status, matched_fields, match_reasons, unmatched_fields, matcher_version, reviewed_by, reviewed_at, created_at, updated_at) FROM stdin;
251	251	\N	\N	\N	\N	\N	\N	\N	0.9500	confirmed	\N	\N	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 08:37:40.856038+00
253	253	\N	\N	\N	\N	\N	\N	\N	0.9500	confirmed	\N	\N	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 08:37:40.856038+00
257	257	\N	\N	\N	\N	\N	\N	\N	0.9500	confirmed	\N	\N	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 08:37:40.856038+00
259	259	\N	\N	\N	\N	\N	\N	\N	0.9500	confirmed	\N	\N	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 08:37:40.856038+00
263	263	\N	\N	\N	\N	\N	\N	\N	0.9500	confirmed	\N	\N	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 08:37:40.856038+00
265	265	\N	\N	\N	\N	\N	\N	\N	0.9500	confirmed	\N	\N	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 08:37:40.856038+00
269	269	\N	\N	\N	\N	\N	\N	\N	0.9500	confirmed	\N	\N	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 08:37:40.856038+00
271	271	\N	\N	\N	\N	\N	\N	\N	0.9500	confirmed	\N	\N	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 08:37:40.856038+00
275	275	\N	\N	\N	\N	\N	\N	\N	0.9500	confirmed	\N	\N	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 08:37:40.856038+00
277	277	\N	\N	\N	\N	\N	\N	\N	0.9500	confirmed	\N	\N	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 08:37:40.856038+00
254	254	\N	\N	\N	\N	\N	\N	Victor Wembanyama	0.8000	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
278	278	\N	\N	\N	\N	\N	\N	Victor Wembanyama	0.8000	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
217	217	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
97	97	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
292	292	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
157	157	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
37	37	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
193	193	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.8300	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
73	73	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.8300	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
256	256	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.8300	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
133	133	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.8300	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
13	13	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.8300	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
169	169	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
49	49	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
229	229	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
109	109	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
280	280	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.8300	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
145	145	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.8300	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
25	25	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.8300	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
205	205	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.8300	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
85	85	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.8300	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
241	241	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.8300	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
121	121	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.8300	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
1	1	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.8300	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
181	181	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.8300	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
61	61	\N	\N	\N	\N	\N	\N	Anthony Edwards	0.8300	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
218	218	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.6800	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
98	98	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.6800	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
293	293	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.6800	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
158	158	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.6800	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
38	38	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.6800	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
194	194	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
74	74	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
134	134	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
14	14	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
170	170	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
50	50	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
230	230	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
110	110	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
281	281	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
146	146	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
26	26	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
206	206	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
86	86	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
242	242	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
122	122	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
2	2	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
182	182	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
62	62	\N	\N	\N	\N	\N	\N	Shai Gilgeous-Alexander	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
260	260	\N	\N	\N	\N	\N	\N	Luka Doncic	0.8900	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
196	196	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
76	76	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
262	262	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
136	136	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
16	16	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
172	172	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
52	52	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
232	232	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
112	112	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
283	283	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.6200	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
148	148	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.6200	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
28	28	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.6200	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
208	208	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.6200	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
88	88	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.6200	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
244	244	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
124	124	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
4	4	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
184	184	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
64	64	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
220	220	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
100	100	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
295	295	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
160	160	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
40	40	\N	\N	\N	\N	\N	\N	Jayson Tatum	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
197	197	\N	\N	\N	\N	\N	\N	Stephen Curry	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
77	77	\N	\N	\N	\N	\N	\N	Stephen Curry	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
137	137	\N	\N	\N	\N	\N	\N	Stephen Curry	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
17	17	\N	\N	\N	\N	\N	\N	Stephen Curry	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
173	173	\N	\N	\N	\N	\N	\N	Stephen Curry	0.9500	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
53	53	\N	\N	\N	\N	\N	\N	Stephen Curry	0.9500	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
233	233	\N	\N	\N	\N	\N	\N	Stephen Curry	0.9500	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
113	113	\N	\N	\N	\N	\N	\N	Stephen Curry	0.9500	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
284	284	\N	\N	\N	\N	\N	\N	Stephen Curry	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
149	149	\N	\N	\N	\N	\N	\N	Stephen Curry	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
29	29	\N	\N	\N	\N	\N	\N	Stephen Curry	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
209	209	\N	\N	\N	\N	\N	\N	Stephen Curry	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
89	89	\N	\N	\N	\N	\N	\N	Stephen Curry	0.6500	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
245	245	\N	\N	\N	\N	\N	\N	Stephen Curry	0.9500	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
125	125	\N	\N	\N	\N	\N	\N	Stephen Curry	0.9500	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
5	5	\N	\N	\N	\N	\N	\N	Stephen Curry	0.9500	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
185	185	\N	\N	\N	\N	\N	\N	Stephen Curry	0.9500	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
65	65	\N	\N	\N	\N	\N	\N	Stephen Curry	0.9500	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
221	221	\N	\N	\N	\N	\N	\N	Stephen Curry	0.9500	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
101	101	\N	\N	\N	\N	\N	\N	Stephen Curry	0.9500	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
296	296	\N	\N	\N	\N	\N	\N	Stephen Curry	0.9500	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
161	161	\N	\N	\N	\N	\N	\N	Stephen Curry	0.9500	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
41	41	\N	\N	\N	\N	\N	\N	Stephen Curry	0.9500	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
266	266	\N	\N	\N	\N	\N	\N	Nikola Jokic	0.6800	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
199	199	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
79	79	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
268	268	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
139	139	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
19	19	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
175	175	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.8300	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
55	55	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.8300	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
235	235	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.8300	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
115	115	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.8300	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
286	286	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.8300	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
151	151	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.8300	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
31	31	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.8300	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
211	211	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.8300	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
91	91	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.8300	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
247	247	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
127	127	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
7	7	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
187	187	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
67	67	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
223	223	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.8300	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
103	103	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.8300	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
298	298	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.8300	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
163	163	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.8300	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
43	43	\N	\N	\N	\N	\N	\N	Chet Holmgren	0.8300	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
176	176	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
56	56	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
236	236	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
116	116	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
287	287	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
152	152	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
32	32	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
212	212	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
92	92	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
248	248	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.6200	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
128	128	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.6200	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
8	8	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.6200	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
188	188	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.6200	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
68	68	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.6200	possible	["player"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
224	224	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
104	104	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
299	299	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
164	164	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
44	44	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
200	200	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
80	80	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
140	140	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
20	20	\N	\N	\N	\N	\N	\N	Paolo Banchero	0.8600	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
272	272	\N	\N	\N	\N	\N	\N	Cooper Flagg	0.8900	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
178	178	\N	\N	\N	\N	\N	\N	Jalen Williams	0.6800	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
58	58	\N	\N	\N	\N	\N	\N	Jalen Williams	0.6800	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
238	238	\N	\N	\N	\N	\N	\N	Jalen Williams	0.6800	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
118	118	\N	\N	\N	\N	\N	\N	Jalen Williams	0.6800	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
289	289	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
154	154	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
34	34	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
214	214	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
94	94	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
250	250	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
130	130	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
10	10	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
190	190	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
70	70	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
226	226	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
106	106	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
166	166	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
46	46	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
202	202	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
82	82	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
274	274	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
142	142	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
22	22	\N	\N	\N	\N	\N	\N	Jalen Williams	0.9200	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
179	179	\N	\N	\N	\N	\N	\N	LeBron James	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
59	59	\N	\N	\N	\N	\N	\N	LeBron James	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
239	239	\N	\N	\N	\N	\N	\N	LeBron James	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
119	119	\N	\N	\N	\N	\N	\N	LeBron James	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
290	290	\N	\N	\N	\N	\N	\N	LeBron James	0.9500	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
155	155	\N	\N	\N	\N	\N	\N	LeBron James	0.9500	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
35	35	\N	\N	\N	\N	\N	\N	LeBron James	0.9500	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
215	215	\N	\N	\N	\N	\N	\N	LeBron James	0.9500	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
95	95	\N	\N	\N	\N	\N	\N	LeBron James	0.9500	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
131	131	\N	\N	\N	\N	\N	\N	LeBron James	0.9500	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
11	11	\N	\N	\N	\N	\N	\N	LeBron James	0.9500	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
191	191	\N	\N	\N	\N	\N	\N	LeBron James	0.9500	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
71	71	\N	\N	\N	\N	\N	\N	LeBron James	0.9500	confirmed	["player", "serial"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
227	227	\N	\N	\N	\N	\N	\N	LeBron James	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
107	107	\N	\N	\N	\N	\N	\N	LeBron James	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
167	167	\N	\N	\N	\N	\N	\N	LeBron James	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
47	47	\N	\N	\N	\N	\N	\N	LeBron James	0.7100	possible	["player", "serial"]	["Watchlist player name found in title", "No card number extracted"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
203	203	\N	\N	\N	\N	\N	\N	LeBron James	0.9500	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
83	83	\N	\N	\N	\N	\N	\N	LeBron James	0.9500	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
143	143	\N	\N	\N	\N	\N	\N	LeBron James	0.9500	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
23	23	\N	\N	\N	\N	\N	\N	LeBron James	0.9500	confirmed	["player"]	["Watchlist player name found in title", "Set and card number match the checklist"]	\N	\N	\N	\N	2026-10-10 08:37:40.856038+00	2026-10-10 09:51:00.697236+00
\.


--
-- Data for Name: product_classifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_classifications (id, store_product_id, classifier_version, classifier_type, status, year, category, brand, product_line, set_name, card_number, player_name, team_name, variant_name, parallel_name, insert_name, is_rookie, is_auto, is_serial, serial_number, serial_current, serial_limit, confidence, raw_signals, created_at, updated_at) FROM stdin;
251	251	deterministic-title-v1	deterministic	ok	2023	\N	\N	\N	\N	\N	Victor Wembanyama	\N	\N	\N	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
253	253	deterministic-title-v1	deterministic	ok	2023	\N	\N	\N	\N	\N	Victor Wembanyama	\N	\N	\N	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
255	255	deterministic-title-v1	deterministic	ok	2023	\N	\N	\N	\N	\N	Victor Wembanyama	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
257	257	deterministic-title-v1	deterministic	ok	2023	\N	\N	\N	\N	\N	Victor Wembanyama	\N	\N	\N	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
259	259	deterministic-title-v1	deterministic	ok	2023	\N	\N	\N	\N	\N	Victor Wembanyama	\N	\N	\N	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
261	261	deterministic-title-v1	deterministic	ok	2023	\N	\N	\N	\N	\N	Victor Wembanyama	\N	\N	\N	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
263	263	deterministic-title-v1	deterministic	ok	2023	\N	\N	\N	\N	\N	Victor Wembanyama	\N	\N	\N	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
265	265	deterministic-title-v1	deterministic	ok	2023	\N	\N	\N	\N	\N	Victor Wembanyama	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
267	267	deterministic-title-v1	deterministic	ok	2023	\N	\N	\N	\N	\N	Victor Wembanyama	\N	\N	\N	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
269	269	deterministic-title-v1	deterministic	ok	2023	\N	\N	\N	\N	\N	Victor Wembanyama	\N	\N	\N	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
271	271	deterministic-title-v1	deterministic	ok	2023	\N	\N	\N	\N	\N	Victor Wembanyama	\N	\N	\N	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
273	273	deterministic-title-v1	deterministic	ok	2023	\N	\N	\N	\N	\N	Victor Wembanyama	\N	\N	\N	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
275	275	deterministic-title-v1	deterministic	ok	2023	\N	\N	\N	\N	\N	Victor Wembanyama	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
277	277	deterministic-title-v1	deterministic	ok	2023	\N	\N	\N	\N	\N	Victor Wembanyama	\N	\N	\N	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
279	279	deterministic-title-v1	deterministic	ok	2023	\N	\N	\N	\N	\N	Victor Wembanyama	\N	\N	\N	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
291	291	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	42	Victor Wembanyama	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
292	292	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	49	Anthony Edwards	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
293	293	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	56	Shai Gilgeous-Alexander	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
294	294	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	63	Luka Doncic	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
295	295	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	70	Jayson Tatum	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
296	296	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	77	Stephen Curry	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
297	297	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	84	Nikola Jokic	\N	Silver Prizm	Silver Prizm	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
298	298	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	91	Chet Holmgren	\N	Silver Prizm	Silver Prizm	\N	t	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
299	299	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	98	Paolo Banchero	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
300	300	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	105	Cooper Flagg	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
216	216	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	192	Victor Wembanyama	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
96	96	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	112	Victor Wembanyama	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
156	156	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	152	Victor Wembanyama	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
36	36	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	72	Victor Wembanyama	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
192	192	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	24	Victor Wembanyama	\N	Purple	Purple	\N	f	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
72	72	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	134	Victor Wembanyama	\N	Purple	Purple	\N	f	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
254	254	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	64	Victor Wembanyama	\N	Purple	Purple	\N	f	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
132	132	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	174	Victor Wembanyama	\N	Purple	Purple	\N	f	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
12	12	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	94	Victor Wembanyama	\N	Purple	Purple	\N	f	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
168	168	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	46	Victor Wembanyama	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
48	48	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	156	Victor Wembanyama	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
228	228	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	86	Victor Wembanyama	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
108	108	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	196	Victor Wembanyama	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
278	278	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	148	Victor Wembanyama	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
144	144	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	68	Victor Wembanyama	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
24	24	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	178	Victor Wembanyama	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
204	204	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	108	Victor Wembanyama	\N	Blue	Blue	\N	f	t	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
84	84	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	28	Victor Wembanyama	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
240	240	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	170	Victor Wembanyama	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
120	120	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	90	Victor Wembanyama	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
180	180	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	130	Victor Wembanyama	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
60	60	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	50	Victor Wembanyama	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
217	217	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	199	Anthony Edwards	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
97	97	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	119	Anthony Edwards	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
157	157	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	159	Anthony Edwards	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
37	37	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	79	Anthony Edwards	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
193	193	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	31	Anthony Edwards	\N	Purple	Purple	\N	t	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
73	73	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	141	Anthony Edwards	\N	Purple	Purple	\N	t	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
256	256	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	71	Anthony Edwards	\N	Purple	Purple	\N	t	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
133	133	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	181	Anthony Edwards	\N	Purple	Purple	\N	t	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
13	13	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	101	Anthony Edwards	\N	Purple	Purple	\N	t	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
169	169	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	53	Anthony Edwards	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
49	49	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	163	Anthony Edwards	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
229	229	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	93	Anthony Edwards	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
109	109	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	13	Anthony Edwards	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
280	280	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	155	Anthony Edwards	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
145	145	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	75	Anthony Edwards	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
25	25	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	185	Anthony Edwards	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
205	205	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	115	Anthony Edwards	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
85	85	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	35	Anthony Edwards	\N	Blue	Blue	\N	f	t	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
241	241	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	177	Anthony Edwards	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
121	121	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	97	Anthony Edwards	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
1	1	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	17	Anthony Edwards	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
181	181	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	137	Anthony Edwards	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
61	61	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	57	Anthony Edwards	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
218	218	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	16	Shai Gilgeous-Alexander	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
98	98	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	126	Shai Gilgeous-Alexander	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
158	158	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	166	Shai Gilgeous-Alexander	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
38	38	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	86	Shai Gilgeous-Alexander	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
194	194	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	38	Shai Gilgeous-Alexander	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
74	74	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	148	Shai Gilgeous-Alexander	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
258	258	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	78	Shai Gilgeous-Alexander	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
134	134	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	188	Shai Gilgeous-Alexander	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
14	14	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	108	Shai Gilgeous-Alexander	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
170	170	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	60	Shai Gilgeous-Alexander	\N	Gold	Gold	\N	f	t	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
50	50	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	170	Shai Gilgeous-Alexander	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
230	230	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	100	Shai Gilgeous-Alexander	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
110	110	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	20	Shai Gilgeous-Alexander	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
281	281	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	162	Shai Gilgeous-Alexander	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
146	146	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	82	Shai Gilgeous-Alexander	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
26	26	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	192	Shai Gilgeous-Alexander	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
206	206	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	122	Shai Gilgeous-Alexander	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
86	86	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	42	Shai Gilgeous-Alexander	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
242	242	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	184	Shai Gilgeous-Alexander	\N	Silver Prizm	Silver Prizm	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
122	122	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	104	Shai Gilgeous-Alexander	\N	Silver Prizm	Silver Prizm	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
2	2	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Prizm	Panini Prizm	24	Shai Gilgeous-Alexander	\N	Silver Prizm	Silver Prizm	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
182	182	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	144	Shai Gilgeous-Alexander	\N	Silver Prizm	Silver Prizm	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
62	62	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Mosaic	Panini Mosaic	64	Shai Gilgeous-Alexander	\N	Silver Prizm	Silver Prizm	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
219	219	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	23	Luka Doncic	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
99	99	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	133	Luka Doncic	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
159	159	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	173	Luka Doncic	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
39	39	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	93	Luka Doncic	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
195	195	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	45	Luka Doncic	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
75	75	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	155	Luka Doncic	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
260	260	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	85	Luka Doncic	\N	Base	Base	\N	f	t	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
135	135	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	195	Luka Doncic	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
15	15	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	115	Luka Doncic	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
171	171	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	67	Luka Doncic	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
51	51	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	177	Luka Doncic	\N	Gold	Gold	\N	f	t	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
231	231	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	107	Luka Doncic	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
111	111	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	27	Luka Doncic	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
282	282	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	169	Luka Doncic	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
147	147	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	89	Luka Doncic	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
27	27	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	199	Luka Doncic	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
207	207	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	129	Luka Doncic	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
87	87	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	49	Luka Doncic	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
243	243	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	191	Luka Doncic	\N	Silver Prizm	Silver Prizm	\N	t	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
123	123	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	111	Luka Doncic	\N	Silver Prizm	Silver Prizm	\N	t	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
3	3	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	31	Luka Doncic	\N	Silver Prizm	Silver Prizm	\N	t	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
183	183	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	151	Luka Doncic	\N	Silver Prizm	Silver Prizm	\N	t	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
63	63	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	71	Luka Doncic	\N	Silver Prizm	Silver Prizm	\N	t	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
196	196	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	52	Jayson Tatum	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
76	76	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	162	Jayson Tatum	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
262	262	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	92	Jayson Tatum	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
136	136	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	12	Jayson Tatum	\N	Holo	Holo	\N	f	t	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
16	16	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	122	Jayson Tatum	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
172	172	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	74	Jayson Tatum	\N	Purple	Purple	\N	f	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
52	52	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	184	Jayson Tatum	\N	Purple	Purple	\N	f	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
232	232	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	114	Jayson Tatum	\N	Purple	Purple	\N	f	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
112	112	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	34	Jayson Tatum	\N	Purple	Purple	\N	f	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
283	283	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	176	Jayson Tatum	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
148	148	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	96	Jayson Tatum	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
28	28	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	16	Jayson Tatum	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
208	208	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	136	Jayson Tatum	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
88	88	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	56	Jayson Tatum	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
244	244	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	198	Jayson Tatum	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
124	124	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	118	Jayson Tatum	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
4	4	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	38	Jayson Tatum	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
184	184	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	158	Jayson Tatum	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
64	64	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	78	Jayson Tatum	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
220	220	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	30	Jayson Tatum	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
100	100	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	140	Jayson Tatum	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
160	160	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	180	Jayson Tatum	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
40	40	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	100	Jayson Tatum	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
197	197	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	59	Stephen Curry	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
77	77	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	169	Stephen Curry	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
264	264	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	99	Stephen Curry	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
137	137	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	19	Stephen Curry	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
17	17	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	129	Stephen Curry	\N	Holo	Holo	\N	f	t	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
173	173	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	81	Stephen Curry	\N	Purple	Purple	\N	t	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
53	53	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	191	Stephen Curry	\N	Purple	Purple	\N	t	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
233	233	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	121	Stephen Curry	\N	Purple	Purple	\N	t	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
113	113	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	41	Stephen Curry	\N	Purple	Purple	\N	t	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
284	284	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	183	Stephen Curry	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
149	149	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	103	Stephen Curry	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
29	29	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	23	Stephen Curry	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
209	209	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	143	Stephen Curry	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
89	89	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	63	Stephen Curry	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
245	245	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	15	Stephen Curry	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
125	125	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	125	Stephen Curry	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
5	5	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	45	Stephen Curry	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
185	185	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	165	Stephen Curry	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
65	65	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	85	Stephen Curry	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
221	221	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	37	Stephen Curry	\N	Base	Base	\N	f	t	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
101	101	deterministic-title-v1	deterministic	ok	2023-24	NBA	Panini	Select	Panini Select	147	Stephen Curry	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
161	161	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	187	Stephen Curry	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
41	41	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Revolution	Panini Revolution	107	Stephen Curry	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
198	198	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	66	Nikola Jokic	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
78	78	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	176	Nikola Jokic	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
266	266	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	106	Nikola Jokic	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
138	138	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	26	Nikola Jokic	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
18	18	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	136	Nikola Jokic	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
174	174	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	88	Nikola Jokic	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
54	54	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	198	Nikola Jokic	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
234	234	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	128	Nikola Jokic	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
114	114	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	48	Nikola Jokic	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
285	285	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	190	Nikola Jokic	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
150	150	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	110	Nikola Jokic	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
30	30	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	30	Nikola Jokic	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
210	210	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	150	Nikola Jokic	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
90	90	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	70	Nikola Jokic	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
246	246	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	22	Nikola Jokic	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
126	126	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	132	Nikola Jokic	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
6	6	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	52	Nikola Jokic	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
186	186	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	172	Nikola Jokic	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
66	66	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	92	Nikola Jokic	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
222	222	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	44	Nikola Jokic	\N	Silver Prizm	Silver Prizm	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
102	102	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	154	Nikola Jokic	\N	Silver Prizm	Silver Prizm	\N	f	t	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
162	162	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	194	Nikola Jokic	\N	Silver Prizm	Silver Prizm	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
42	42	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	114	Nikola Jokic	\N	Silver Prizm	Silver Prizm	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
199	199	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	73	Chet Holmgren	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
79	79	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	183	Chet Holmgren	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
268	268	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	113	Chet Holmgren	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
139	139	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	33	Chet Holmgren	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
19	19	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	143	Chet Holmgren	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
175	175	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	95	Chet Holmgren	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
55	55	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	15	Chet Holmgren	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
235	235	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	135	Chet Holmgren	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
115	115	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	55	Chet Holmgren	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
286	286	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	197	Chet Holmgren	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
151	151	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	117	Chet Holmgren	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
31	31	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	37	Chet Holmgren	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
211	211	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	157	Chet Holmgren	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
91	91	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	77	Chet Holmgren	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
247	247	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	29	Chet Holmgren	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
127	127	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	139	Chet Holmgren	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
7	7	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	59	Chet Holmgren	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
187	187	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	179	Chet Holmgren	\N	Green	Green	\N	f	t	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
67	67	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	99	Chet Holmgren	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
223	223	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	51	Chet Holmgren	\N	Silver Prizm	Silver Prizm	\N	t	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
103	103	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	161	Chet Holmgren	\N	Silver Prizm	Silver Prizm	\N	t	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
163	163	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	11	Chet Holmgren	\N	Silver Prizm	Silver Prizm	\N	t	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
43	43	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	121	Chet Holmgren	\N	Silver Prizm	Silver Prizm	\N	t	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
176	176	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	102	Paolo Banchero	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
56	56	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	22	Paolo Banchero	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
236	236	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	142	Paolo Banchero	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
116	116	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	62	Paolo Banchero	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
287	287	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	14	Paolo Banchero	\N	Purple	Purple	\N	f	t	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
152	152	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	124	Paolo Banchero	\N	Purple	Purple	\N	f	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
32	32	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	44	Paolo Banchero	\N	Purple	Purple	\N	f	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
212	212	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	164	Paolo Banchero	\N	Purple	Purple	\N	f	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
92	92	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	84	Paolo Banchero	\N	Purple	Purple	\N	f	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
248	248	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	36	Paolo Banchero	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
128	128	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	146	Paolo Banchero	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
8	8	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	66	Paolo Banchero	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
188	188	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	186	Paolo Banchero	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
68	68	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	106	Paolo Banchero	\N	Red Wave	Red Wave	\N	f	t	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
224	224	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	58	Paolo Banchero	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
104	104	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	168	Paolo Banchero	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
164	164	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	18	Paolo Banchero	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
44	44	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	128	Paolo Banchero	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
200	200	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	80	Paolo Banchero	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
80	80	deterministic-title-v1	deterministic	ok	2024-25	NBA	Topps	Chrome	Topps Chrome	190	Paolo Banchero	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
270	270	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	120	Paolo Banchero	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
140	140	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	40	Paolo Banchero	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
20	20	deterministic-title-v1	deterministic	ok	2025-26	NBA	Topps	Chrome Sapphire	Topps Chrome Sapphire	150	Paolo Banchero	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
177	177	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	109	Cooper Flagg	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
57	57	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	29	Cooper Flagg	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
237	237	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	149	Cooper Flagg	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
117	117	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	69	Cooper Flagg	\N	Holo	Holo	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
288	288	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	21	Cooper Flagg	\N	Purple	Purple	\N	t	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
153	153	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	131	Cooper Flagg	\N	Purple	Purple	\N	t	t	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
33	33	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	51	Cooper Flagg	\N	Purple	Purple	\N	t	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
213	213	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	171	Cooper Flagg	\N	Purple	Purple	\N	t	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
93	93	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	91	Cooper Flagg	\N	Purple	Purple	\N	t	f	t	75	\N	75	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
249	249	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	43	Cooper Flagg	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
129	129	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	153	Cooper Flagg	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
9	9	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	73	Cooper Flagg	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
189	189	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	193	Cooper Flagg	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
69	69	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	113	Cooper Flagg	\N	Red Wave	Red Wave	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
225	225	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	65	Cooper Flagg	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
105	105	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	175	Cooper Flagg	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
165	165	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	25	Cooper Flagg	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
45	45	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	135	Cooper Flagg	\N	Blue	Blue	\N	f	f	t	199	\N	199	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
201	201	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	87	Cooper Flagg	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
81	81	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	197	Cooper Flagg	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
272	272	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	127	Cooper Flagg	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
141	141	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	47	Cooper Flagg	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
21	21	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	157	Cooper Flagg	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
178	178	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	116	Jalen Williams	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
58	58	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	36	Jalen Williams	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
238	238	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	156	Jalen Williams	\N	Orange	Orange	\N	f	t	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
118	118	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	76	Jalen Williams	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
289	289	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	28	Jalen Williams	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
154	154	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	138	Jalen Williams	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
34	34	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	58	Jalen Williams	\N	Base	Base	\N	f	t	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
214	214	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	178	Jalen Williams	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
94	94	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	98	Jalen Williams	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
250	250	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	50	Jalen Williams	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
130	130	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	160	Jalen Williams	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
10	10	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	80	Jalen Williams	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
190	190	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	10	Jalen Williams	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
70	70	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	120	Jalen Williams	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
226	226	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	72	Jalen Williams	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
106	106	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	182	Jalen Williams	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
166	166	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	32	Jalen Williams	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
46	46	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	142	Jalen Williams	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
202	202	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	94	Jalen Williams	\N	Silver Prizm	Silver Prizm	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
82	82	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	14	Jalen Williams	\N	Silver Prizm	Silver Prizm	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
274	274	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	134	Jalen Williams	\N	Silver Prizm	Silver Prizm	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
142	142	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	54	Jalen Williams	\N	Silver Prizm	Silver Prizm	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
22	22	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	164	Jalen Williams	\N	Silver Prizm	Silver Prizm	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
179	179	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	123	LeBron James	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
59	59	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	43	LeBron James	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
239	239	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	163	LeBron James	\N	Orange	Orange	\N	f	f	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
119	119	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	83	LeBron James	\N	Orange	Orange	\N	f	t	t	25	\N	25	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
290	290	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	35	LeBron James	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
155	155	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	145	LeBron James	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
35	35	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	65	LeBron James	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
215	215	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	185	LeBron James	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
95	95	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	105	LeBron James	\N	Base	Base	\N	f	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
252	252	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	57	LeBron James	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
131	131	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	167	LeBron James	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
11	11	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	87	LeBron James	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
191	191	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	17	LeBron James	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
71	71	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	127	LeBron James	\N	Gold	Gold	\N	f	f	t	10	\N	10	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
227	227	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	79	LeBron James	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
107	107	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	189	LeBron James	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
167	167	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	39	LeBron James	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
47	47	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	149	LeBron James	\N	Green	Green	\N	f	f	t	99	\N	99	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
203	203	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	101	LeBron James	\N	Silver Prizm	Silver Prizm	\N	t	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
83	83	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Donruss Optic	Panini Donruss Optic	21	LeBron James	\N	Silver Prizm	Silver Prizm	\N	t	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
276	276	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	141	LeBron James	\N	Silver Prizm	Silver Prizm	\N	t	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
143	143	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	61	LeBron James	\N	Silver Prizm	Silver Prizm	\N	t	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
23	23	deterministic-title-v1	deterministic	ok	2024-25	NBA	Panini	Origins	Panini Origins	171	LeBron James	\N	Silver Prizm	Silver Prizm	\N	t	f	f	\N	\N	\N	\N	\N	2026-10-10 08:37:40.860507+00	2026-10-10 08:37:40.860507+00
\.


--
-- Data for Name: product_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_snapshots (id, store_product_id, scan_run_id, source, external_id, title, description, price, currency, availability, image_url, raw_payload, content_hash, observed_at) FROM stdin;
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id, user_id, display_name, role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reference_checklists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reference_checklists (id, year, set_name, card_number, player_name) FROM stdin;
\.


--
-- Data for Name: scan_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scan_jobs (id, scan_run_id, mode, status, requested_by, requested_by_kind, priority, locked_by, locked_at, heartbeat_at, attempts, max_attempts, next_attempt_at, started_at, completed_at, cancel_requested_at, cancel_requested_by, processed, matched, failed_stores, completed_stores, error, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: scan_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scan_runs (id, mode, status, processed, matched, error, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: source_products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.source_products (source, external_id, handle, title, price, available, url, image_url, content_hash, last_matched_hash, last_matched_context_hash, first_seen_at, last_seen_at, last_seen_scan_token, description, normalized_title, raw_latest_payload, last_checked_at) FROM stdin;
\.


--
-- Data for Name: store_products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.store_products (id, store_id, source, external_product_id, handle, product_url, canonical_url, title, normalized_title, description, normalized_description, current_price, currency, current_availability, image_url, product_fingerprint, first_seen_at, last_seen_at, last_checked_at, is_active, raw_latest_payload, created_at, updated_at) FROM stdin;
251	2	src2	ext251	\N	\N	\N	Card 251	\N	\N	\N	2.00	NZD	t	\N	fp251	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:26:40.849906+00	t	\N	2026-10-02 01:00:00+00	2026-10-10 08:37:40.849906+00
253	2	src1	ext253	\N	\N	\N	Card 253	\N	\N	\N	4.00	NZD	f	\N	fp253	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:24:40.849906+00	t	\N	2026-10-02 01:00:00+00	2026-10-10 08:37:40.849906+00
255	2	src0	ext255	\N	\N	\N	Card 255 12/99	\N	\N	\N	6.00	NZD	t	\N	fp255	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:22:40.849906+00	t	\N	2026-10-02 01:00:00+00	2026-10-10 08:37:40.849906+00
257	2	src2	ext257	\N	\N	\N	Card 257	\N	\N	\N	8.00	NZD	t	\N	fp257	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:20:40.849906+00	t	\N	2026-10-02 01:00:00+00	2026-10-10 08:37:40.849906+00
259	\N	src1	ext259	\N	\N	\N	Card 259	\N	\N	\N	10.00	NZD	t	\N	fp259	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:18:40.849906+00	t	\N	2026-10-02 01:00:00+00	2026-10-10 08:37:40.849906+00
261	2	src0	ext261	\N	\N	\N	Card 261	\N	\N	\N	12.00	NZD	t	\N	fp261	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:16:40.849906+00	f	\N	2026-10-02 02:00:00+00	2026-10-10 08:37:40.849906+00
263	2	src2	ext263	\N	\N	\N	Card 263	\N	\N	\N	14.00	NZD	t	\N	fp263	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:14:40.849906+00	t	\N	2026-10-02 02:00:00+00	2026-10-10 08:37:40.849906+00
265	2	src1	ext265	\N	\N	\N	Card 265 12/99	\N	\N	\N	16.00	NZD	t	\N	fp265	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:12:40.849906+00	t	\N	2026-10-02 02:00:00+00	2026-10-10 08:37:40.849906+00
267	2	src0	ext267	\N	\N	\N	Card 267	\N	\N	\N	18.00	NZD	t	\N	fp267	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:10:40.849906+00	t	\N	2026-10-02 02:00:00+00	2026-10-10 08:37:40.849906+00
269	2	src2	ext269	\N	\N	\N	Card 269	\N	\N	\N	20.00	NZD	t	\N	fp269	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:08:40.849906+00	t	\N	2026-10-02 02:00:00+00	2026-10-10 08:37:40.849906+00
271	2	src1	ext271	\N	\N	\N	Card 271	\N	\N	\N	22.00	NZD	t	\N	fp271	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:06:40.849906+00	t	\N	2026-10-02 03:00:00+00	2026-10-10 08:37:40.849906+00
273	\N	src0	ext273	\N	\N	\N	Card 273	\N	\N	\N	24.00	NZD	t	\N	fp273	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:04:40.849906+00	t	\N	2026-10-02 03:00:00+00	2026-10-10 08:37:40.849906+00
275	2	src2	ext275	\N	\N	\N	Card 275 12/99	\N	\N	\N	26.00	NZD	t	\N	fp275	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:02:40.849906+00	t	\N	2026-10-02 03:00:00+00	2026-10-10 08:37:40.849906+00
277	2	src1	ext277	\N	\N	\N	Card 277	\N	\N	\N	28.00	NZD	t	\N	fp277	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:00:40.849906+00	t	\N	2026-10-02 03:00:00+00	2026-10-10 08:37:40.849906+00
279	2	src0	ext279	\N	\N	\N	Card 279	\N	\N	\N	30.00	NZD	t	\N	fp279	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 03:58:40.849906+00	t	\N	2026-10-02 03:00:00+00	2026-10-10 08:37:40.849906+00
292	2	src1	ext292	\N	\N	\N	2023-24 Panini Mosaic Anthony Edwards Holo #49	\N	\N	\N	7.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-277.jpg	fp292	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 02:51:00.697236+00	t	\N	2026-10-02 05:00:00+00	2026-10-10 09:51:00.697236+00
293	3	src2	ext293	\N	\N	\N	2023-24 Panini Mosaic Shai Gilgeous-Alexander Orange #56 /25	\N	\N	\N	60.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-278.jpg	fp293	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 01:51:00.697236+00	t	\N	2026-10-02 05:00:00+00	2026-10-10 09:51:00.697236+00
294	4	src0	ext294	\N	\N	\N	2024-25 Panini Revolution Luka Doncic Orange #63 /25	\N	\N	\N	73.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-279.jpg	fp294	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 00:51:00.697236+00	t	\N	2026-10-02 05:00:00+00	2026-10-10 09:51:00.697236+00
295	1	src1	ext295	\N	\N	\N	2024-25 Panini Revolution Jayson Tatum Base #70	\N	\N	\N	46.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-280.jpg	fp295	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 23:51:00.697236+00	t	\N	2026-10-02 05:00:00+00	2026-10-10 09:51:00.697236+00
296	2	src2	ext296	\N	\N	\N	2024-25 Panini Revolution Stephen Curry Base #77	\N	\N	\N	59.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-281.jpg	fp296	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 22:51:00.697236+00	t	\N	2026-10-02 05:00:00+00	2026-10-10 09:51:00.697236+00
297	3	src0	ext297	\N	\N	\N	2025-26 Topps Chrome Sapphire Nikola Jokic Silver Prizm #84	\N	\N	\N	72.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-282.jpg	fp297	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 21:51:00.697236+00	t	\N	2026-10-02 05:00:00+00	2026-10-10 09:51:00.697236+00
298	4	src1	ext298	\N	\N	\N	2025-26 Topps Chrome Sapphire Chet Holmgren Silver Prizm #91 RC	\N	\N	\N	85.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-283.jpg	fp298	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 20:51:00.697236+00	t	\N	2026-10-02 05:00:00+00	2026-10-10 09:51:00.697236+00
299	1	src2	ext299	\N	\N	\N	2025-26 Topps Chrome Sapphire Paolo Banchero Blue #98 /199	\N	\N	\N	138.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-284.jpg	fp299	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 19:51:00.697236+00	t	\N	2026-10-02 05:00:00+00	2026-10-10 09:51:00.697236+00
300	2	src0	ext300	\N	\N	\N	2024-25 Panini Origins Cooper Flagg Blue #105 /199	\N	\N	\N	151.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-285.jpg	fp300	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 18:51:00.697236+00	t	\N	2026-10-02 06:00:00+00	2026-10-10 09:51:00.697236+00
216	1	src0	ext216	\N	\N	\N	2023-24 Panini Prizm Victor Wembanyama Holo #192	\N	\N	\N	174.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-216.jpg	fp216	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 03:51:00.697236+00	t	\N	2026-10-01 21:00:00+00	2026-10-10 09:51:00.697236+00
96	1	src0	ext96	\N	\N	\N	2023-24 Panini Prizm Victor Wembanyama Holo #112	\N	\N	\N	54.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-96.jpg	fp96	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 03:51:00.697236+00	t	\N	2026-10-01 09:00:00+00	2026-10-10 09:51:00.697236+00
291	1	src0	ext291	\N	\N	\N	2023-24 Panini Mosaic Victor Wembanyama Holo #42	\N	\N	\N	234.00	NZD	f	https://cdn.shopify.com/s/files/seed/card-276.jpg	fp291	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 03:51:00.697236+00	f	\N	2026-10-02 05:00:00+00	2026-10-10 09:51:00.697236+00
156	1	src0	ext156	\N	\N	\N	2023-24 Panini Mosaic Victor Wembanyama Holo #152	\N	\N	\N	114.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-156.jpg	fp156	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 03:51:00.697236+00	t	\N	2026-10-01 15:00:00+00	2026-10-10 09:51:00.697236+00
36	1	src0	ext36	\N	\N	\N	2023-24 Panini Mosaic Victor Wembanyama Holo #72	\N	\N	\N	234.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-36.jpg	fp36	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 03:51:00.697236+00	t	\N	2026-10-01 03:00:00+00	2026-10-10 09:51:00.697236+00
192	1	src0	ext192	\N	\N	\N	2023-24 Panini Prizm Victor Wembanyama Purple #24 /75	\N	\N	\N	142.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-192.jpg	fp192	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 21:51:00.697236+00	t	\N	2026-10-01 19:00:00+00	2026-10-10 09:51:00.697236+00
72	1	src0	ext72	\N	\N	\N	2023-24 Panini Prizm Victor Wembanyama Purple #134 /75	\N	\N	\N	262.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-72.jpg	fp72	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 21:51:00.697236+00	t	\N	2026-10-01 07:00:00+00	2026-10-10 09:51:00.697236+00
254	1	src2	ext254	\N	\N	\N	2023-24 Panini Mosaic Victor Wembanyama Purple #64 /75	\N	\N	\N	202.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-252.jpg	fp254	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 21:51:00.697236+00	t	\N	2026-10-02 01:00:00+00	2026-10-10 09:51:00.697236+00
132	1	src0	ext132	\N	\N	\N	2023-24 Panini Mosaic Victor Wembanyama Purple #174 /75	\N	\N	\N	82.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-132.jpg	fp132	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 21:51:00.697236+00	t	\N	2026-10-01 13:00:00+00	2026-10-10 09:51:00.697236+00
12	1	src0	ext12	\N	\N	\N	2023-24 Panini Mosaic Victor Wembanyama Purple #94 /75	\N	\N	\N	202.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-12.jpg	fp12	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 21:51:00.697236+00	t	\N	2026-10-01 01:00:00+00	2026-10-10 09:51:00.697236+00
168	1	src0	ext168	\N	\N	\N	2023-24 Panini Prizm Victor Wembanyama Red Wave #46	\N	\N	\N	30.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-168.jpg	fp168	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 15:51:00.697236+00	t	\N	2026-10-01 16:00:00+00	2026-10-10 09:51:00.697236+00
48	1	src0	ext48	\N	\N	\N	2023-24 Panini Prizm Victor Wembanyama Red Wave #156	\N	\N	\N	150.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-48.jpg	fp48	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 15:51:00.697236+00	t	\N	2026-10-01 04:00:00+00	2026-10-10 09:51:00.697236+00
228	1	src0	ext228	\N	\N	\N	2023-24 Panini Mosaic Victor Wembanyama Red Wave #86	\N	\N	\N	90.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-228.jpg	fp228	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 15:51:00.697236+00	t	\N	2026-10-01 22:00:00+00	2026-10-10 09:51:00.697236+00
108	1	src0	ext108	\N	\N	\N	2023-24 Panini Mosaic Victor Wembanyama Red Wave #196	\N	\N	\N	210.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-108.jpg	fp108	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 15:51:00.697236+00	t	\N	2026-10-01 10:00:00+00	2026-10-10 09:51:00.697236+00
278	1	src2	ext278	\N	\N	\N	2023-24 Panini Prizm Victor Wembanyama Blue #148 /199	\N	\N	\N	118.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-264.jpg	fp278	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 09:51:00.697236+00	t	\N	2026-10-02 03:00:00+00	2026-10-10 09:51:00.697236+00
144	1	src0	ext144	\N	\N	\N	2023-24 Panini Prizm Victor Wembanyama Blue #68 /199	\N	\N	\N	238.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-144.jpg	fp144	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 09:51:00.697236+00	t	\N	2026-10-01 14:00:00+00	2026-10-10 09:51:00.697236+00
24	1	src0	ext24	\N	\N	\N	2023-24 Panini Prizm Victor Wembanyama Blue #178 /199	\N	\N	\N	118.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-24.jpg	fp24	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 09:51:00.697236+00	t	\N	2026-10-01 02:00:00+00	2026-10-10 09:51:00.697236+00
204	1	src0	ext204	\N	\N	\N	2023-24 Panini Mosaic Victor Wembanyama Blue #108 Auto /199	\N	\N	\N	58.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-204.jpg	fp204	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 09:51:00.697236+00	t	\N	2026-10-01 20:00:00+00	2026-10-10 09:51:00.697236+00
84	1	src0	ext84	\N	\N	\N	2023-24 Panini Mosaic Victor Wembanyama Blue #28 /199	\N	\N	\N	178.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-84.jpg	fp84	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 09:51:00.697236+00	t	\N	2026-10-01 08:00:00+00	2026-10-10 09:51:00.697236+00
240	1	src0	ext240	\N	\N	\N	2023-24 Panini Prizm Victor Wembanyama Base #170	\N	\N	\N	6.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-240.jpg	fp240	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 09:51:00.697236+00	t	\N	2026-10-02 00:00:00+00	2026-10-10 09:51:00.697236+00
120	1	src0	ext120	\N	\N	\N	2023-24 Panini Prizm Victor Wembanyama Base #90	\N	\N	\N	126.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-120.jpg	fp120	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 09:51:00.697236+00	t	\N	2026-10-01 12:00:00+00	2026-10-10 09:51:00.697236+00
180	1	src0	ext180	\N	\N	\N	2023-24 Panini Mosaic Victor Wembanyama Base #130	\N	\N	\N	186.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-180.jpg	fp180	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 09:51:00.697236+00	t	\N	2026-10-01 18:00:00+00	2026-10-10 09:51:00.697236+00
60	1	src0	ext60	\N	\N	\N	2023-24 Panini Mosaic Victor Wembanyama Base #50	\N	\N	\N	66.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-60.jpg	fp60	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 09:51:00.697236+00	t	\N	2026-10-01 06:00:00+00	2026-10-10 09:51:00.697236+00
217	2	src1	ext217	\N	\N	\N	2023-24 Panini Prizm Anthony Edwards Holo #199	\N	\N	\N	187.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-217.jpg	fp217	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 02:51:00.697236+00	t	\N	2026-10-01 21:00:00+00	2026-10-10 09:51:00.697236+00
97	2	src1	ext97	\N	\N	\N	2023-24 Panini Prizm Anthony Edwards Holo #119	\N	\N	\N	67.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-97.jpg	fp97	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 02:51:00.697236+00	t	\N	2026-10-01 09:00:00+00	2026-10-10 09:51:00.697236+00
157	2	src1	ext157	\N	\N	\N	2023-24 Panini Mosaic Anthony Edwards Holo #159	\N	\N	\N	127.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-157.jpg	fp157	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 02:51:00.697236+00	t	\N	2026-10-01 15:00:00+00	2026-10-10 09:51:00.697236+00
37	2	src1	ext37	\N	\N	\N	2023-24 Panini Mosaic Anthony Edwards Holo #79	\N	\N	\N	7.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-37.jpg	fp37	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 02:51:00.697236+00	t	\N	2026-10-01 03:00:00+00	2026-10-10 09:51:00.697236+00
193	2	src1	ext193	\N	\N	\N	2023-24 Panini Prizm Anthony Edwards Purple #31 RC /75	\N	\N	\N	155.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-193.jpg	fp193	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 20:51:00.697236+00	t	\N	2026-10-01 19:00:00+00	2026-10-10 09:51:00.697236+00
73	2	src1	ext73	\N	\N	\N	2023-24 Panini Prizm Anthony Edwards Purple #141 RC /75	\N	\N	\N	275.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-73.jpg	fp73	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 20:51:00.697236+00	t	\N	2026-10-01 07:00:00+00	2026-10-10 09:51:00.697236+00
256	2	src1	ext256	\N	\N	\N	2023-24 Panini Mosaic Anthony Edwards Purple #71 RC /75	\N	\N	\N	215.00	NZD	f	https://cdn.shopify.com/s/files/seed/card-253.jpg	fp256	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 20:51:00.697236+00	f	\N	2026-10-02 01:00:00+00	2026-10-10 09:51:00.697236+00
133	2	src1	ext133	\N	\N	\N	2023-24 Panini Mosaic Anthony Edwards Purple #181 RC /75	\N	\N	\N	95.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-133.jpg	fp133	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 20:51:00.697236+00	t	\N	2026-10-01 13:00:00+00	2026-10-10 09:51:00.697236+00
13	2	src1	ext13	\N	\N	\N	2023-24 Panini Mosaic Anthony Edwards Purple #101 RC /75	\N	\N	\N	215.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-13.jpg	fp13	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 20:51:00.697236+00	t	\N	2026-10-01 01:00:00+00	2026-10-10 09:51:00.697236+00
169	2	src1	ext169	\N	\N	\N	2023-24 Panini Prizm Anthony Edwards Red Wave #53	\N	\N	\N	43.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-169.jpg	fp169	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 14:51:00.697236+00	t	\N	2026-10-01 16:00:00+00	2026-10-10 09:51:00.697236+00
49	2	src1	ext49	\N	\N	\N	2023-24 Panini Prizm Anthony Edwards Red Wave #163	\N	\N	\N	163.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-49.jpg	fp49	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 14:51:00.697236+00	t	\N	2026-10-01 04:00:00+00	2026-10-10 09:51:00.697236+00
229	2	src1	ext229	\N	\N	\N	2023-24 Panini Mosaic Anthony Edwards Red Wave #93	\N	\N	\N	103.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-229.jpg	fp229	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 14:51:00.697236+00	t	\N	2026-10-01 22:00:00+00	2026-10-10 09:51:00.697236+00
109	2	src1	ext109	\N	\N	\N	2023-24 Panini Mosaic Anthony Edwards Red Wave #13	\N	\N	\N	223.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-109.jpg	fp109	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 14:51:00.697236+00	t	\N	2026-10-01 10:00:00+00	2026-10-10 09:51:00.697236+00
280	2	src1	ext280	\N	\N	\N	2023-24 Panini Prizm Anthony Edwards Blue #155 /199	\N	\N	\N	131.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-265.jpg	fp280	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 08:51:00.697236+00	t	\N	2026-10-02 04:00:00+00	2026-10-10 09:51:00.697236+00
145	2	src1	ext145	\N	\N	\N	2023-24 Panini Prizm Anthony Edwards Blue #75 /199	\N	\N	\N	251.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-145.jpg	fp145	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 08:51:00.697236+00	t	\N	2026-10-01 14:00:00+00	2026-10-10 09:51:00.697236+00
25	2	src1	ext25	\N	\N	\N	2023-24 Panini Prizm Anthony Edwards Blue #185 /199	\N	\N	\N	131.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-25.jpg	fp25	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 08:51:00.697236+00	t	\N	2026-10-01 02:00:00+00	2026-10-10 09:51:00.697236+00
205	2	src1	ext205	\N	\N	\N	2023-24 Panini Mosaic Anthony Edwards Blue #115 /199	\N	\N	\N	71.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-205.jpg	fp205	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 08:51:00.697236+00	t	\N	2026-10-01 20:00:00+00	2026-10-10 09:51:00.697236+00
85	2	src1	ext85	\N	\N	\N	2023-24 Panini Mosaic Anthony Edwards Blue #35 Auto /199	\N	\N	\N	191.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-85.jpg	fp85	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 08:51:00.697236+00	t	\N	2026-10-01 08:00:00+00	2026-10-10 09:51:00.697236+00
241	2	src1	ext241	\N	\N	\N	2023-24 Panini Prizm Anthony Edwards Base #177	\N	\N	\N	19.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-241.jpg	fp241	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 08:51:00.697236+00	t	\N	2026-10-02 00:00:00+00	2026-10-10 09:51:00.697236+00
121	2	src1	ext121	\N	\N	\N	2023-24 Panini Prizm Anthony Edwards Base #97	\N	\N	\N	139.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-121.jpg	fp121	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 08:51:00.697236+00	t	\N	2026-10-01 12:00:00+00	2026-10-10 09:51:00.697236+00
1	2	src1	ext1	\N	\N	\N	2023-24 Panini Prizm Anthony Edwards Base #17	\N	\N	\N	19.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-1.jpg	fp1	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 08:51:00.697236+00	t	\N	2026-10-01 00:00:00+00	2026-10-10 09:51:00.697236+00
181	2	src1	ext181	\N	\N	\N	2023-24 Panini Mosaic Anthony Edwards Base #137	\N	\N	\N	199.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-181.jpg	fp181	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 08:51:00.697236+00	t	\N	2026-10-01 18:00:00+00	2026-10-10 09:51:00.697236+00
61	2	src1	ext61	\N	\N	\N	2023-24 Panini Mosaic Anthony Edwards Base #57	\N	\N	\N	79.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-61.jpg	fp61	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 08:51:00.697236+00	t	\N	2026-10-01 06:00:00+00	2026-10-10 09:51:00.697236+00
218	3	src2	ext218	\N	\N	\N	2023-24 Panini Prizm Shai Gilgeous-Alexander Orange #16 /25	\N	\N	\N	240.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-218.jpg	fp218	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 01:51:00.697236+00	t	\N	2026-10-01 21:00:00+00	2026-10-10 09:51:00.697236+00
98	3	src2	ext98	\N	\N	\N	2023-24 Panini Prizm Shai Gilgeous-Alexander Orange #126 /25	\N	\N	\N	120.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-98.jpg	fp98	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 01:51:00.697236+00	t	\N	2026-10-01 09:00:00+00	2026-10-10 09:51:00.697236+00
158	3	src2	ext158	\N	\N	\N	2023-24 Panini Mosaic Shai Gilgeous-Alexander Orange #166 /25	\N	\N	\N	180.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-158.jpg	fp158	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 01:51:00.697236+00	t	\N	2026-10-01 15:00:00+00	2026-10-10 09:51:00.697236+00
38	3	src2	ext38	\N	\N	\N	2023-24 Panini Mosaic Shai Gilgeous-Alexander Orange #86 /25	\N	\N	\N	60.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-38.jpg	fp38	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 01:51:00.697236+00	t	\N	2026-10-01 03:00:00+00	2026-10-10 09:51:00.697236+00
194	3	src2	ext194	\N	\N	\N	2023-24 Panini Prizm Shai Gilgeous-Alexander Base #38	\N	\N	\N	128.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-194.jpg	fp194	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 19:51:00.697236+00	t	\N	2026-10-01 19:00:00+00	2026-10-10 09:51:00.697236+00
74	3	src2	ext74	\N	\N	\N	2023-24 Panini Prizm Shai Gilgeous-Alexander Base #148	\N	\N	\N	8.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-74.jpg	fp74	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 19:51:00.697236+00	t	\N	2026-10-01 07:00:00+00	2026-10-10 09:51:00.697236+00
258	3	src0	ext258	\N	\N	\N	2023-24 Panini Mosaic Shai Gilgeous-Alexander Base #78	\N	\N	\N	188.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-254.jpg	fp258	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 19:51:00.697236+00	t	\N	2026-10-02 01:00:00+00	2026-10-10 09:51:00.697236+00
134	3	src2	ext134	\N	\N	\N	2023-24 Panini Mosaic Shai Gilgeous-Alexander Base #188	\N	\N	\N	68.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-134.jpg	fp134	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 19:51:00.697236+00	t	\N	2026-10-01 13:00:00+00	2026-10-10 09:51:00.697236+00
14	3	src2	ext14	\N	\N	\N	2023-24 Panini Mosaic Shai Gilgeous-Alexander Base #108	\N	\N	\N	188.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-14.jpg	fp14	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 19:51:00.697236+00	t	\N	2026-10-01 01:00:00+00	2026-10-10 09:51:00.697236+00
170	3	src2	ext170	\N	\N	\N	2023-24 Panini Prizm Shai Gilgeous-Alexander Gold #60 Auto /10	\N	\N	\N	96.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-170.jpg	fp170	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 13:51:00.697236+00	t	\N	2026-10-01 17:00:00+00	2026-10-10 09:51:00.697236+00
50	3	src2	ext50	\N	\N	\N	2023-24 Panini Prizm Shai Gilgeous-Alexander Gold #170 /10	\N	\N	\N	216.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-50.jpg	fp50	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 13:51:00.697236+00	t	\N	2026-10-01 05:00:00+00	2026-10-10 09:51:00.697236+00
230	3	src2	ext230	\N	\N	\N	2023-24 Panini Mosaic Shai Gilgeous-Alexander Gold #100 /10	\N	\N	\N	156.00	NZD	f	https://cdn.shopify.com/s/files/seed/card-230.jpg	fp230	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 13:51:00.697236+00	f	\N	2026-10-01 23:00:00+00	2026-10-10 09:51:00.697236+00
110	3	src2	ext110	\N	\N	\N	2023-24 Panini Mosaic Shai Gilgeous-Alexander Gold #20 /10	\N	\N	\N	276.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-110.jpg	fp110	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 13:51:00.697236+00	t	\N	2026-10-01 11:00:00+00	2026-10-10 09:51:00.697236+00
281	3	src2	ext281	\N	\N	\N	2023-24 Panini Prizm Shai Gilgeous-Alexander Green #162 /99	\N	\N	\N	144.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-266.jpg	fp281	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 07:51:00.697236+00	t	\N	2026-10-02 04:00:00+00	2026-10-10 09:51:00.697236+00
146	3	src2	ext146	\N	\N	\N	2023-24 Panini Prizm Shai Gilgeous-Alexander Green #82 /99	\N	\N	\N	264.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-146.jpg	fp146	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 07:51:00.697236+00	t	\N	2026-10-01 14:00:00+00	2026-10-10 09:51:00.697236+00
26	3	src2	ext26	\N	\N	\N	2023-24 Panini Prizm Shai Gilgeous-Alexander Green #192 /99	\N	\N	\N	144.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-26.jpg	fp26	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 07:51:00.697236+00	t	\N	2026-10-01 02:00:00+00	2026-10-10 09:51:00.697236+00
206	3	src2	ext206	\N	\N	\N	2023-24 Panini Mosaic Shai Gilgeous-Alexander Green #122 /99	\N	\N	\N	84.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-206.jpg	fp206	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 07:51:00.697236+00	t	\N	2026-10-01 20:00:00+00	2026-10-10 09:51:00.697236+00
86	3	src2	ext86	\N	\N	\N	2023-24 Panini Mosaic Shai Gilgeous-Alexander Green #42 /99	\N	\N	\N	204.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-86.jpg	fp86	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 07:51:00.697236+00	t	\N	2026-10-01 08:00:00+00	2026-10-10 09:51:00.697236+00
242	3	src2	ext242	\N	\N	\N	2023-24 Panini Prizm Shai Gilgeous-Alexander Silver Prizm #184	\N	\N	\N	32.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-242.jpg	fp242	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 07:51:00.697236+00	t	\N	2026-10-02 00:00:00+00	2026-10-10 09:51:00.697236+00
122	3	src2	ext122	\N	\N	\N	2023-24 Panini Prizm Shai Gilgeous-Alexander Silver Prizm #104	\N	\N	\N	152.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-122.jpg	fp122	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 07:51:00.697236+00	t	\N	2026-10-01 12:00:00+00	2026-10-10 09:51:00.697236+00
2	3	src2	ext2	\N	\N	\N	2023-24 Panini Prizm Shai Gilgeous-Alexander Silver Prizm #24	\N	\N	\N	32.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-2.jpg	fp2	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 07:51:00.697236+00	t	\N	2026-10-01 00:00:00+00	2026-10-10 09:51:00.697236+00
182	3	src2	ext182	\N	\N	\N	2023-24 Panini Mosaic Shai Gilgeous-Alexander Silver Prizm #144	\N	\N	\N	212.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-182.jpg	fp182	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 07:51:00.697236+00	t	\N	2026-10-01 18:00:00+00	2026-10-10 09:51:00.697236+00
62	3	src2	ext62	\N	\N	\N	2023-24 Panini Mosaic Shai Gilgeous-Alexander Silver Prizm #64	\N	\N	\N	92.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-62.jpg	fp62	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 07:51:00.697236+00	t	\N	2026-10-01 06:00:00+00	2026-10-10 09:51:00.697236+00
219	4	src0	ext219	\N	\N	\N	2023-24 Panini Select Luka Doncic Orange #23 /25	\N	\N	\N	253.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-219.jpg	fp219	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 00:51:00.697236+00	t	\N	2026-10-01 21:00:00+00	2026-10-10 09:51:00.697236+00
99	4	src0	ext99	\N	\N	\N	2023-24 Panini Select Luka Doncic Orange #133 /25	\N	\N	\N	133.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-99.jpg	fp99	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 00:51:00.697236+00	t	\N	2026-10-01 09:00:00+00	2026-10-10 09:51:00.697236+00
159	4	src0	ext159	\N	\N	\N	2024-25 Panini Revolution Luka Doncic Orange #173 /25	\N	\N	\N	193.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-159.jpg	fp159	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 00:51:00.697236+00	t	\N	2026-10-01 15:00:00+00	2026-10-10 09:51:00.697236+00
39	4	src0	ext39	\N	\N	\N	2024-25 Panini Revolution Luka Doncic Orange #93 /25	\N	\N	\N	73.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-39.jpg	fp39	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 00:51:00.697236+00	t	\N	2026-10-01 03:00:00+00	2026-10-10 09:51:00.697236+00
195	4	src0	ext195	\N	\N	\N	2023-24 Panini Select Luka Doncic Base #45	\N	\N	\N	141.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-195.jpg	fp195	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 18:51:00.697236+00	t	\N	2026-10-01 19:00:00+00	2026-10-10 09:51:00.697236+00
75	4	src0	ext75	\N	\N	\N	2023-24 Panini Select Luka Doncic Base #155	\N	\N	\N	21.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-75.jpg	fp75	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 18:51:00.697236+00	t	\N	2026-10-01 07:00:00+00	2026-10-10 09:51:00.697236+00
260	4	src2	ext260	\N	\N	\N	2024-25 Panini Revolution Luka Doncic Base #85 Auto	\N	\N	\N	201.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-255.jpg	fp260	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 18:51:00.697236+00	t	\N	2026-10-02 02:00:00+00	2026-10-10 09:51:00.697236+00
135	4	src0	ext135	\N	\N	\N	2024-25 Panini Revolution Luka Doncic Base #195	\N	\N	\N	81.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-135.jpg	fp135	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 18:51:00.697236+00	t	\N	2026-10-01 13:00:00+00	2026-10-10 09:51:00.697236+00
15	4	src0	ext15	\N	\N	\N	2024-25 Panini Revolution Luka Doncic Base #115	\N	\N	\N	201.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-15.jpg	fp15	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 18:51:00.697236+00	t	\N	2026-10-01 01:00:00+00	2026-10-10 09:51:00.697236+00
171	4	src0	ext171	\N	\N	\N	2023-24 Panini Select Luka Doncic Gold #67 /10	\N	\N	\N	109.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-171.jpg	fp171	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 12:51:00.697236+00	t	\N	2026-10-01 17:00:00+00	2026-10-10 09:51:00.697236+00
51	4	src0	ext51	\N	\N	\N	2023-24 Panini Select Luka Doncic Gold #177 Auto /10	\N	\N	\N	229.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-51.jpg	fp51	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 12:51:00.697236+00	t	\N	2026-10-01 05:00:00+00	2026-10-10 09:51:00.697236+00
231	4	src0	ext231	\N	\N	\N	2024-25 Panini Revolution Luka Doncic Gold #107 /10	\N	\N	\N	169.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-231.jpg	fp231	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 12:51:00.697236+00	t	\N	2026-10-01 23:00:00+00	2026-10-10 09:51:00.697236+00
111	4	src0	ext111	\N	\N	\N	2024-25 Panini Revolution Luka Doncic Gold #27 /10	\N	\N	\N	49.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-111.jpg	fp111	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 12:51:00.697236+00	t	\N	2026-10-01 11:00:00+00	2026-10-10 09:51:00.697236+00
282	4	src0	ext282	\N	\N	\N	2023-24 Panini Select Luka Doncic Green #169 /99	\N	\N	\N	157.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-267.jpg	fp282	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 06:51:00.697236+00	t	\N	2026-10-02 04:00:00+00	2026-10-10 09:51:00.697236+00
147	4	src0	ext147	\N	\N	\N	2023-24 Panini Select Luka Doncic Green #89 /99	\N	\N	\N	277.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-147.jpg	fp147	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 06:51:00.697236+00	t	\N	2026-10-01 14:00:00+00	2026-10-10 09:51:00.697236+00
27	4	src0	ext27	\N	\N	\N	2023-24 Panini Select Luka Doncic Green #199 /99	\N	\N	\N	157.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-27.jpg	fp27	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 06:51:00.697236+00	t	\N	2026-10-01 02:00:00+00	2026-10-10 09:51:00.697236+00
207	4	src0	ext207	\N	\N	\N	2024-25 Panini Revolution Luka Doncic Green #129 /99	\N	\N	\N	97.00	NZD	f	https://cdn.shopify.com/s/files/seed/card-207.jpg	fp207	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 06:51:00.697236+00	f	\N	2026-10-01 20:00:00+00	2026-10-10 09:51:00.697236+00
87	4	src0	ext87	\N	\N	\N	2024-25 Panini Revolution Luka Doncic Green #49 /99	\N	\N	\N	217.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-87.jpg	fp87	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 06:51:00.697236+00	t	\N	2026-10-01 08:00:00+00	2026-10-10 09:51:00.697236+00
243	4	src0	ext243	\N	\N	\N	2023-24 Panini Select Luka Doncic Silver Prizm #191 RC	\N	\N	\N	45.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-243.jpg	fp243	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 06:51:00.697236+00	t	\N	2026-10-02 00:00:00+00	2026-10-10 09:51:00.697236+00
123	4	src0	ext123	\N	\N	\N	2023-24 Panini Select Luka Doncic Silver Prizm #111 RC	\N	\N	\N	165.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-123.jpg	fp123	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 06:51:00.697236+00	t	\N	2026-10-01 12:00:00+00	2026-10-10 09:51:00.697236+00
3	4	src0	ext3	\N	\N	\N	2023-24 Panini Select Luka Doncic Silver Prizm #31 RC	\N	\N	\N	45.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-3.jpg	fp3	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 06:51:00.697236+00	t	\N	2026-10-01 00:00:00+00	2026-10-10 09:51:00.697236+00
183	4	src0	ext183	\N	\N	\N	2024-25 Panini Revolution Luka Doncic Silver Prizm #151 RC	\N	\N	\N	225.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-183.jpg	fp183	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 06:51:00.697236+00	t	\N	2026-10-01 18:00:00+00	2026-10-10 09:51:00.697236+00
63	4	src0	ext63	\N	\N	\N	2024-25 Panini Revolution Luka Doncic Silver Prizm #71 RC	\N	\N	\N	105.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-63.jpg	fp63	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 06:51:00.697236+00	t	\N	2026-10-01 06:00:00+00	2026-10-10 09:51:00.697236+00
196	1	src1	ext196	\N	\N	\N	2023-24 Panini Select Jayson Tatum Holo #52	\N	\N	\N	154.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-196.jpg	fp196	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 17:51:00.697236+00	t	\N	2026-10-01 19:00:00+00	2026-10-10 09:51:00.697236+00
76	1	src1	ext76	\N	\N	\N	2023-24 Panini Select Jayson Tatum Holo #162	\N	\N	\N	34.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-76.jpg	fp76	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 17:51:00.697236+00	t	\N	2026-10-01 07:00:00+00	2026-10-10 09:51:00.697236+00
262	1	src1	ext262	\N	\N	\N	2024-25 Panini Revolution Jayson Tatum Holo #92	\N	\N	\N	214.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-256.jpg	fp262	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 17:51:00.697236+00	t	\N	2026-10-02 02:00:00+00	2026-10-10 09:51:00.697236+00
136	1	src1	ext136	\N	\N	\N	2024-25 Panini Revolution Jayson Tatum Holo #12 Auto	\N	\N	\N	94.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-136.jpg	fp136	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 17:51:00.697236+00	t	\N	2026-10-01 13:00:00+00	2026-10-10 09:51:00.697236+00
16	1	src1	ext16	\N	\N	\N	2024-25 Panini Revolution Jayson Tatum Holo #122	\N	\N	\N	214.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-16.jpg	fp16	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 17:51:00.697236+00	t	\N	2026-10-01 01:00:00+00	2026-10-10 09:51:00.697236+00
172	1	src1	ext172	\N	\N	\N	2023-24 Panini Select Jayson Tatum Purple #74 /75	\N	\N	\N	122.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-172.jpg	fp172	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 11:51:00.697236+00	t	\N	2026-10-01 17:00:00+00	2026-10-10 09:51:00.697236+00
52	1	src1	ext52	\N	\N	\N	2023-24 Panini Select Jayson Tatum Purple #184 /75	\N	\N	\N	242.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-52.jpg	fp52	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 11:51:00.697236+00	t	\N	2026-10-01 05:00:00+00	2026-10-10 09:51:00.697236+00
232	1	src1	ext232	\N	\N	\N	2024-25 Panini Revolution Jayson Tatum Purple #114 /75	\N	\N	\N	182.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-232.jpg	fp232	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 11:51:00.697236+00	t	\N	2026-10-01 23:00:00+00	2026-10-10 09:51:00.697236+00
112	1	src1	ext112	\N	\N	\N	2024-25 Panini Revolution Jayson Tatum Purple #34 /75	\N	\N	\N	62.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-112.jpg	fp112	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 11:51:00.697236+00	t	\N	2026-10-01 11:00:00+00	2026-10-10 09:51:00.697236+00
283	1	src1	ext283	\N	\N	\N	2023-24 Panini Select Jayson Tatum Red Wave #176	\N	\N	\N	130.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-268.jpg	fp283	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 05:51:00.697236+00	t	\N	2026-10-02 04:00:00+00	2026-10-10 09:51:00.697236+00
148	1	src1	ext148	\N	\N	\N	2023-24 Panini Select Jayson Tatum Red Wave #96	\N	\N	\N	10.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-148.jpg	fp148	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 05:51:00.697236+00	t	\N	2026-10-01 14:00:00+00	2026-10-10 09:51:00.697236+00
28	1	src1	ext28	\N	\N	\N	2023-24 Panini Select Jayson Tatum Red Wave #16	\N	\N	\N	130.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-28.jpg	fp28	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 05:51:00.697236+00	t	\N	2026-10-01 02:00:00+00	2026-10-10 09:51:00.697236+00
208	1	src1	ext208	\N	\N	\N	2024-25 Panini Revolution Jayson Tatum Red Wave #136	\N	\N	\N	70.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-208.jpg	fp208	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 05:51:00.697236+00	t	\N	2026-10-01 20:00:00+00	2026-10-10 09:51:00.697236+00
88	1	src1	ext88	\N	\N	\N	2024-25 Panini Revolution Jayson Tatum Red Wave #56	\N	\N	\N	190.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-88.jpg	fp88	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 05:51:00.697236+00	t	\N	2026-10-01 08:00:00+00	2026-10-10 09:51:00.697236+00
244	1	src1	ext244	\N	\N	\N	2023-24 Panini Select Jayson Tatum Blue #198 /199	\N	\N	\N	98.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-244.jpg	fp244	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 05:51:00.697236+00	t	\N	2026-10-02 00:00:00+00	2026-10-10 09:51:00.697236+00
124	1	src1	ext124	\N	\N	\N	2023-24 Panini Select Jayson Tatum Blue #118 /199	\N	\N	\N	218.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-124.jpg	fp124	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 05:51:00.697236+00	t	\N	2026-10-01 12:00:00+00	2026-10-10 09:51:00.697236+00
4	1	src1	ext4	\N	\N	\N	2023-24 Panini Select Jayson Tatum Blue #38 /199	\N	\N	\N	98.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-4.jpg	fp4	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 05:51:00.697236+00	t	\N	2026-10-01 00:00:00+00	2026-10-10 09:51:00.697236+00
184	1	src1	ext184	\N	\N	\N	2024-25 Panini Revolution Jayson Tatum Blue #158 /199	\N	\N	\N	278.00	NZD	f	https://cdn.shopify.com/s/files/seed/card-184.jpg	fp184	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 05:51:00.697236+00	f	\N	2026-10-01 18:00:00+00	2026-10-10 09:51:00.697236+00
64	1	src1	ext64	\N	\N	\N	2024-25 Panini Revolution Jayson Tatum Blue #78 /199	\N	\N	\N	158.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-64.jpg	fp64	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 05:51:00.697236+00	t	\N	2026-10-01 06:00:00+00	2026-10-10 09:51:00.697236+00
220	1	src1	ext220	\N	\N	\N	2023-24 Panini Select Jayson Tatum Base #30	\N	\N	\N	226.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-220.jpg	fp220	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 23:51:00.697236+00	t	\N	2026-10-01 22:00:00+00	2026-10-10 09:51:00.697236+00
100	1	src1	ext100	\N	\N	\N	2023-24 Panini Select Jayson Tatum Base #140	\N	\N	\N	106.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-100.jpg	fp100	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 23:51:00.697236+00	t	\N	2026-10-01 10:00:00+00	2026-10-10 09:51:00.697236+00
160	1	src1	ext160	\N	\N	\N	2024-25 Panini Revolution Jayson Tatum Base #180	\N	\N	\N	166.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-160.jpg	fp160	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 23:51:00.697236+00	t	\N	2026-10-01 16:00:00+00	2026-10-10 09:51:00.697236+00
40	1	src1	ext40	\N	\N	\N	2024-25 Panini Revolution Jayson Tatum Base #100	\N	\N	\N	46.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-40.jpg	fp40	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 23:51:00.697236+00	t	\N	2026-10-01 04:00:00+00	2026-10-10 09:51:00.697236+00
197	2	src2	ext197	\N	\N	\N	2023-24 Panini Select Stephen Curry Holo #59	\N	\N	\N	167.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-197.jpg	fp197	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 16:51:00.697236+00	t	\N	2026-10-01 19:00:00+00	2026-10-10 09:51:00.697236+00
77	2	src2	ext77	\N	\N	\N	2023-24 Panini Select Stephen Curry Holo #169	\N	\N	\N	47.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-77.jpg	fp77	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 16:51:00.697236+00	t	\N	2026-10-01 07:00:00+00	2026-10-10 09:51:00.697236+00
264	2	src0	ext264	\N	\N	\N	2024-25 Panini Revolution Stephen Curry Holo #99	\N	\N	\N	227.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-257.jpg	fp264	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 16:51:00.697236+00	t	\N	2026-10-02 02:00:00+00	2026-10-10 09:51:00.697236+00
137	2	src2	ext137	\N	\N	\N	2024-25 Panini Revolution Stephen Curry Holo #19	\N	\N	\N	107.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-137.jpg	fp137	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 16:51:00.697236+00	t	\N	2026-10-01 13:00:00+00	2026-10-10 09:51:00.697236+00
17	2	src2	ext17	\N	\N	\N	2024-25 Panini Revolution Stephen Curry Holo #129 Auto	\N	\N	\N	227.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-17.jpg	fp17	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 16:51:00.697236+00	t	\N	2026-10-01 01:00:00+00	2026-10-10 09:51:00.697236+00
173	2	src2	ext173	\N	\N	\N	2023-24 Panini Select Stephen Curry Purple #81 RC /75	\N	\N	\N	135.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-173.jpg	fp173	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 10:51:00.697236+00	t	\N	2026-10-01 17:00:00+00	2026-10-10 09:51:00.697236+00
53	2	src2	ext53	\N	\N	\N	2023-24 Panini Select Stephen Curry Purple #191 RC /75	\N	\N	\N	255.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-53.jpg	fp53	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 10:51:00.697236+00	t	\N	2026-10-01 05:00:00+00	2026-10-10 09:51:00.697236+00
233	2	src2	ext233	\N	\N	\N	2024-25 Panini Revolution Stephen Curry Purple #121 RC /75	\N	\N	\N	195.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-233.jpg	fp233	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 10:51:00.697236+00	t	\N	2026-10-01 23:00:00+00	2026-10-10 09:51:00.697236+00
113	2	src2	ext113	\N	\N	\N	2024-25 Panini Revolution Stephen Curry Purple #41 RC /75	\N	\N	\N	75.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-113.jpg	fp113	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 10:51:00.697236+00	t	\N	2026-10-01 11:00:00+00	2026-10-10 09:51:00.697236+00
284	2	src2	ext284	\N	\N	\N	2023-24 Panini Select Stephen Curry Red Wave #183	\N	\N	\N	143.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-269.jpg	fp284	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 04:51:00.697236+00	t	\N	2026-10-02 04:00:00+00	2026-10-10 09:51:00.697236+00
149	2	src2	ext149	\N	\N	\N	2023-24 Panini Select Stephen Curry Red Wave #103	\N	\N	\N	23.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-149.jpg	fp149	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 04:51:00.697236+00	t	\N	2026-10-01 14:00:00+00	2026-10-10 09:51:00.697236+00
29	2	src2	ext29	\N	\N	\N	2023-24 Panini Select Stephen Curry Red Wave #23	\N	\N	\N	143.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-29.jpg	fp29	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 04:51:00.697236+00	t	\N	2026-10-01 02:00:00+00	2026-10-10 09:51:00.697236+00
209	2	src2	ext209	\N	\N	\N	2024-25 Panini Revolution Stephen Curry Red Wave #143	\N	\N	\N	83.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-209.jpg	fp209	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 04:51:00.697236+00	t	\N	2026-10-01 20:00:00+00	2026-10-10 09:51:00.697236+00
89	2	src2	ext89	\N	\N	\N	2024-25 Panini Revolution Stephen Curry Red Wave #63	\N	\N	\N	203.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-89.jpg	fp89	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 04:51:00.697236+00	t	\N	2026-10-01 08:00:00+00	2026-10-10 09:51:00.697236+00
245	2	src2	ext245	\N	\N	\N	2023-24 Panini Select Stephen Curry Blue #15 /199	\N	\N	\N	111.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-245.jpg	fp245	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:51:00.697236+00	t	\N	2026-10-02 00:00:00+00	2026-10-10 09:51:00.697236+00
125	2	src2	ext125	\N	\N	\N	2023-24 Panini Select Stephen Curry Blue #125 /199	\N	\N	\N	231.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-125.jpg	fp125	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:51:00.697236+00	t	\N	2026-10-01 12:00:00+00	2026-10-10 09:51:00.697236+00
5	2	src2	ext5	\N	\N	\N	2023-24 Panini Select Stephen Curry Blue #45 /199	\N	\N	\N	111.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-5.jpg	fp5	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:51:00.697236+00	t	\N	2026-10-01 00:00:00+00	2026-10-10 09:51:00.697236+00
185	2	src2	ext185	\N	\N	\N	2024-25 Panini Revolution Stephen Curry Blue #165 /199	\N	\N	\N	51.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-185.jpg	fp185	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:51:00.697236+00	t	\N	2026-10-01 18:00:00+00	2026-10-10 09:51:00.697236+00
65	2	src2	ext65	\N	\N	\N	2024-25 Panini Revolution Stephen Curry Blue #85 /199	\N	\N	\N	171.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-65.jpg	fp65	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:51:00.697236+00	t	\N	2026-10-01 06:00:00+00	2026-10-10 09:51:00.697236+00
221	2	src2	ext221	\N	\N	\N	2023-24 Panini Select Stephen Curry Base #37 Auto	\N	\N	\N	239.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-221.jpg	fp221	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 22:51:00.697236+00	t	\N	2026-10-01 22:00:00+00	2026-10-10 09:51:00.697236+00
101	2	src2	ext101	\N	\N	\N	2023-24 Panini Select Stephen Curry Base #147	\N	\N	\N	119.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-101.jpg	fp101	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 22:51:00.697236+00	t	\N	2026-10-01 10:00:00+00	2026-10-10 09:51:00.697236+00
161	2	src2	ext161	\N	\N	\N	2024-25 Panini Revolution Stephen Curry Base #187	\N	\N	\N	179.00	NZD	f	https://cdn.shopify.com/s/files/seed/card-161.jpg	fp161	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 22:51:00.697236+00	f	\N	2026-10-01 16:00:00+00	2026-10-10 09:51:00.697236+00
41	2	src2	ext41	\N	\N	\N	2024-25 Panini Revolution Stephen Curry Base #107	\N	\N	\N	59.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-41.jpg	fp41	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 22:51:00.697236+00	t	\N	2026-10-01 04:00:00+00	2026-10-10 09:51:00.697236+00
198	3	src0	ext198	\N	\N	\N	2024-25 Topps Chrome Nikola Jokic Orange #66 /25	\N	\N	\N	220.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-198.jpg	fp198	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 15:51:00.697236+00	t	\N	2026-10-01 19:00:00+00	2026-10-10 09:51:00.697236+00
78	3	src0	ext78	\N	\N	\N	2024-25 Topps Chrome Nikola Jokic Orange #176 /25	\N	\N	\N	100.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-78.jpg	fp78	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 15:51:00.697236+00	t	\N	2026-10-01 07:00:00+00	2026-10-10 09:51:00.697236+00
266	3	src2	ext266	\N	\N	\N	2025-26 Topps Chrome Sapphire Nikola Jokic Orange #106 /25	\N	\N	\N	280.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-258.jpg	fp266	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 15:51:00.697236+00	t	\N	2026-10-02 02:00:00+00	2026-10-10 09:51:00.697236+00
138	3	src0	ext138	\N	\N	\N	2025-26 Topps Chrome Sapphire Nikola Jokic Orange #26 /25	\N	\N	\N	160.00	NZD	f	https://cdn.shopify.com/s/files/seed/card-138.jpg	fp138	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 15:51:00.697236+00	f	\N	2026-10-01 13:00:00+00	2026-10-10 09:51:00.697236+00
18	3	src0	ext18	\N	\N	\N	2025-26 Topps Chrome Sapphire Nikola Jokic Orange #136 /25	\N	\N	\N	280.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-18.jpg	fp18	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 15:51:00.697236+00	t	\N	2026-10-01 01:00:00+00	2026-10-10 09:51:00.697236+00
174	3	src0	ext174	\N	\N	\N	2024-25 Topps Chrome Nikola Jokic Base #88	\N	\N	\N	108.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-174.jpg	fp174	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 09:51:00.697236+00	t	\N	2026-10-01 17:00:00+00	2026-10-10 09:51:00.697236+00
54	3	src0	ext54	\N	\N	\N	2024-25 Topps Chrome Nikola Jokic Base #198	\N	\N	\N	228.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-54.jpg	fp54	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 09:51:00.697236+00	t	\N	2026-10-01 05:00:00+00	2026-10-10 09:51:00.697236+00
234	3	src0	ext234	\N	\N	\N	2025-26 Topps Chrome Sapphire Nikola Jokic Base #128	\N	\N	\N	168.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-234.jpg	fp234	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 09:51:00.697236+00	t	\N	2026-10-01 23:00:00+00	2026-10-10 09:51:00.697236+00
114	3	src0	ext114	\N	\N	\N	2025-26 Topps Chrome Sapphire Nikola Jokic Base #48	\N	\N	\N	48.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-114.jpg	fp114	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 09:51:00.697236+00	t	\N	2026-10-01 11:00:00+00	2026-10-10 09:51:00.697236+00
285	3	src0	ext285	\N	\N	\N	2024-25 Topps Chrome Nikola Jokic Gold #190 /10	\N	\N	\N	196.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-270.jpg	fp285	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 09:51:00.697236+00	t	\N	2026-10-02 04:00:00+00	2026-10-10 09:51:00.697236+00
150	3	src0	ext150	\N	\N	\N	2024-25 Topps Chrome Nikola Jokic Gold #110 /10	\N	\N	\N	76.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-150.jpg	fp150	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 09:51:00.697236+00	t	\N	2026-10-01 15:00:00+00	2026-10-10 09:51:00.697236+00
30	3	src0	ext30	\N	\N	\N	2024-25 Topps Chrome Nikola Jokic Gold #30 /10	\N	\N	\N	196.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-30.jpg	fp30	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 09:51:00.697236+00	t	\N	2026-10-01 03:00:00+00	2026-10-10 09:51:00.697236+00
210	3	src0	ext210	\N	\N	\N	2025-26 Topps Chrome Sapphire Nikola Jokic Gold #150 /10	\N	\N	\N	136.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-210.jpg	fp210	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 09:51:00.697236+00	t	\N	2026-10-01 21:00:00+00	2026-10-10 09:51:00.697236+00
90	3	src0	ext90	\N	\N	\N	2025-26 Topps Chrome Sapphire Nikola Jokic Gold #70 /10	\N	\N	\N	256.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-90.jpg	fp90	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 09:51:00.697236+00	t	\N	2026-10-01 09:00:00+00	2026-10-10 09:51:00.697236+00
246	3	src0	ext246	\N	\N	\N	2024-25 Topps Chrome Nikola Jokic Green #22 /99	\N	\N	\N	124.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-246.jpg	fp246	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 03:51:00.697236+00	t	\N	2026-10-02 00:00:00+00	2026-10-10 09:51:00.697236+00
126	3	src0	ext126	\N	\N	\N	2024-25 Topps Chrome Nikola Jokic Green #132 /99	\N	\N	\N	244.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-126.jpg	fp126	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 03:51:00.697236+00	t	\N	2026-10-01 12:00:00+00	2026-10-10 09:51:00.697236+00
6	3	src0	ext6	\N	\N	\N	2024-25 Topps Chrome Nikola Jokic Green #52 /99	\N	\N	\N	124.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-6.jpg	fp6	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 03:51:00.697236+00	t	\N	2026-10-01 00:00:00+00	2026-10-10 09:51:00.697236+00
186	3	src0	ext186	\N	\N	\N	2025-26 Topps Chrome Sapphire Nikola Jokic Green #172 /99	\N	\N	\N	64.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-186.jpg	fp186	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 03:51:00.697236+00	t	\N	2026-10-01 18:00:00+00	2026-10-10 09:51:00.697236+00
66	3	src0	ext66	\N	\N	\N	2025-26 Topps Chrome Sapphire Nikola Jokic Green #92 /99	\N	\N	\N	184.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-66.jpg	fp66	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 03:51:00.697236+00	t	\N	2026-10-01 06:00:00+00	2026-10-10 09:51:00.697236+00
222	3	src0	ext222	\N	\N	\N	2024-25 Topps Chrome Nikola Jokic Silver Prizm #44	\N	\N	\N	12.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-222.jpg	fp222	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 21:51:00.697236+00	t	\N	2026-10-01 22:00:00+00	2026-10-10 09:51:00.697236+00
102	3	src0	ext102	\N	\N	\N	2024-25 Topps Chrome Nikola Jokic Silver Prizm #154 Auto	\N	\N	\N	132.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-102.jpg	fp102	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 21:51:00.697236+00	t	\N	2026-10-01 10:00:00+00	2026-10-10 09:51:00.697236+00
162	3	src0	ext162	\N	\N	\N	2025-26 Topps Chrome Sapphire Nikola Jokic Silver Prizm #194	\N	\N	\N	192.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-162.jpg	fp162	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 21:51:00.697236+00	t	\N	2026-10-01 16:00:00+00	2026-10-10 09:51:00.697236+00
42	3	src0	ext42	\N	\N	\N	2025-26 Topps Chrome Sapphire Nikola Jokic Silver Prizm #114	\N	\N	\N	72.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-42.jpg	fp42	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 21:51:00.697236+00	t	\N	2026-10-01 04:00:00+00	2026-10-10 09:51:00.697236+00
199	4	src1	ext199	\N	\N	\N	2024-25 Topps Chrome Chet Holmgren Orange #73 /25	\N	\N	\N	233.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-199.jpg	fp199	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 14:51:00.697236+00	t	\N	2026-10-01 19:00:00+00	2026-10-10 09:51:00.697236+00
79	4	src1	ext79	\N	\N	\N	2024-25 Topps Chrome Chet Holmgren Orange #183 /25	\N	\N	\N	113.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-79.jpg	fp79	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 14:51:00.697236+00	t	\N	2026-10-01 07:00:00+00	2026-10-10 09:51:00.697236+00
268	4	src1	ext268	\N	\N	\N	2025-26 Topps Chrome Sapphire Chet Holmgren Orange #113 /25	\N	\N	\N	53.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-259.jpg	fp268	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 14:51:00.697236+00	t	\N	2026-10-02 02:00:00+00	2026-10-10 09:51:00.697236+00
139	4	src1	ext139	\N	\N	\N	2025-26 Topps Chrome Sapphire Chet Holmgren Orange #33 /25	\N	\N	\N	173.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-139.jpg	fp139	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 14:51:00.697236+00	t	\N	2026-10-01 13:00:00+00	2026-10-10 09:51:00.697236+00
19	4	src1	ext19	\N	\N	\N	2025-26 Topps Chrome Sapphire Chet Holmgren Orange #143 /25	\N	\N	\N	53.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-19.jpg	fp19	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 14:51:00.697236+00	t	\N	2026-10-01 01:00:00+00	2026-10-10 09:51:00.697236+00
175	4	src1	ext175	\N	\N	\N	2024-25 Topps Chrome Chet Holmgren Base #95	\N	\N	\N	121.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-175.jpg	fp175	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 08:51:00.697236+00	t	\N	2026-10-01 17:00:00+00	2026-10-10 09:51:00.697236+00
55	4	src1	ext55	\N	\N	\N	2024-25 Topps Chrome Chet Holmgren Base #15	\N	\N	\N	241.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-55.jpg	fp55	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 08:51:00.697236+00	t	\N	2026-10-01 05:00:00+00	2026-10-10 09:51:00.697236+00
235	4	src1	ext235	\N	\N	\N	2025-26 Topps Chrome Sapphire Chet Holmgren Base #135	\N	\N	\N	181.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-235.jpg	fp235	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 08:51:00.697236+00	t	\N	2026-10-01 23:00:00+00	2026-10-10 09:51:00.697236+00
115	4	src1	ext115	\N	\N	\N	2025-26 Topps Chrome Sapphire Chet Holmgren Base #55	\N	\N	\N	61.00	NZD	f	https://cdn.shopify.com/s/files/seed/card-115.jpg	fp115	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 08:51:00.697236+00	f	\N	2026-10-01 11:00:00+00	2026-10-10 09:51:00.697236+00
286	4	src1	ext286	\N	\N	\N	2024-25 Topps Chrome Chet Holmgren Gold #197 /10	\N	\N	\N	209.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-271.jpg	fp286	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 08:51:00.697236+00	t	\N	2026-10-02 04:00:00+00	2026-10-10 09:51:00.697236+00
151	4	src1	ext151	\N	\N	\N	2024-25 Topps Chrome Chet Holmgren Gold #117 /10	\N	\N	\N	89.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-151.jpg	fp151	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 08:51:00.697236+00	t	\N	2026-10-01 15:00:00+00	2026-10-10 09:51:00.697236+00
31	4	src1	ext31	\N	\N	\N	2024-25 Topps Chrome Chet Holmgren Gold #37 /10	\N	\N	\N	209.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-31.jpg	fp31	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 08:51:00.697236+00	t	\N	2026-10-01 03:00:00+00	2026-10-10 09:51:00.697236+00
211	4	src1	ext211	\N	\N	\N	2025-26 Topps Chrome Sapphire Chet Holmgren Gold #157 /10	\N	\N	\N	149.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-211.jpg	fp211	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 08:51:00.697236+00	t	\N	2026-10-01 21:00:00+00	2026-10-10 09:51:00.697236+00
91	4	src1	ext91	\N	\N	\N	2025-26 Topps Chrome Sapphire Chet Holmgren Gold #77 /10	\N	\N	\N	269.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-91.jpg	fp91	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 08:51:00.697236+00	t	\N	2026-10-01 09:00:00+00	2026-10-10 09:51:00.697236+00
247	4	src1	ext247	\N	\N	\N	2024-25 Topps Chrome Chet Holmgren Green #29 /99	\N	\N	\N	137.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-247.jpg	fp247	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 02:51:00.697236+00	t	\N	2026-10-02 00:00:00+00	2026-10-10 09:51:00.697236+00
127	4	src1	ext127	\N	\N	\N	2024-25 Topps Chrome Chet Holmgren Green #139 /99	\N	\N	\N	257.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-127.jpg	fp127	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 02:51:00.697236+00	t	\N	2026-10-01 12:00:00+00	2026-10-10 09:51:00.697236+00
7	4	src1	ext7	\N	\N	\N	2024-25 Topps Chrome Chet Holmgren Green #59 /99	\N	\N	\N	137.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-7.jpg	fp7	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 02:51:00.697236+00	t	\N	2026-10-01 00:00:00+00	2026-10-10 09:51:00.697236+00
187	4	src1	ext187	\N	\N	\N	2025-26 Topps Chrome Sapphire Chet Holmgren Green #179 Auto /99	\N	\N	\N	77.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-187.jpg	fp187	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 02:51:00.697236+00	t	\N	2026-10-01 18:00:00+00	2026-10-10 09:51:00.697236+00
67	4	src1	ext67	\N	\N	\N	2025-26 Topps Chrome Sapphire Chet Holmgren Green #99 /99	\N	\N	\N	197.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-67.jpg	fp67	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 02:51:00.697236+00	t	\N	2026-10-01 06:00:00+00	2026-10-10 09:51:00.697236+00
223	4	src1	ext223	\N	\N	\N	2024-25 Topps Chrome Chet Holmgren Silver Prizm #51 RC	\N	\N	\N	25.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-223.jpg	fp223	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 20:51:00.697236+00	t	\N	2026-10-01 22:00:00+00	2026-10-10 09:51:00.697236+00
103	4	src1	ext103	\N	\N	\N	2024-25 Topps Chrome Chet Holmgren Silver Prizm #161 RC	\N	\N	\N	145.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-103.jpg	fp103	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 20:51:00.697236+00	t	\N	2026-10-01 10:00:00+00	2026-10-10 09:51:00.697236+00
163	4	src1	ext163	\N	\N	\N	2025-26 Topps Chrome Sapphire Chet Holmgren Silver Prizm #11 RC	\N	\N	\N	205.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-163.jpg	fp163	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 20:51:00.697236+00	t	\N	2026-10-01 16:00:00+00	2026-10-10 09:51:00.697236+00
43	4	src1	ext43	\N	\N	\N	2025-26 Topps Chrome Sapphire Chet Holmgren Silver Prizm #121 RC	\N	\N	\N	85.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-43.jpg	fp43	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 20:51:00.697236+00	t	\N	2026-10-01 04:00:00+00	2026-10-10 09:51:00.697236+00
176	1	src2	ext176	\N	\N	\N	2024-25 Topps Chrome Paolo Banchero Holo #102	\N	\N	\N	134.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-176.jpg	fp176	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 07:51:00.697236+00	t	\N	2026-10-01 17:00:00+00	2026-10-10 09:51:00.697236+00
56	1	src2	ext56	\N	\N	\N	2024-25 Topps Chrome Paolo Banchero Holo #22	\N	\N	\N	14.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-56.jpg	fp56	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 07:51:00.697236+00	t	\N	2026-10-01 05:00:00+00	2026-10-10 09:51:00.697236+00
236	1	src2	ext236	\N	\N	\N	2025-26 Topps Chrome Sapphire Paolo Banchero Holo #142	\N	\N	\N	194.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-236.jpg	fp236	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 07:51:00.697236+00	t	\N	2026-10-01 23:00:00+00	2026-10-10 09:51:00.697236+00
116	1	src2	ext116	\N	\N	\N	2025-26 Topps Chrome Sapphire Paolo Banchero Holo #62	\N	\N	\N	74.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-116.jpg	fp116	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 07:51:00.697236+00	t	\N	2026-10-01 11:00:00+00	2026-10-10 09:51:00.697236+00
287	1	src2	ext287	\N	\N	\N	2024-25 Topps Chrome Paolo Banchero Purple #14 Auto /75	\N	\N	\N	222.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-272.jpg	fp287	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 07:51:00.697236+00	t	\N	2026-10-02 04:00:00+00	2026-10-10 09:51:00.697236+00
152	1	src2	ext152	\N	\N	\N	2024-25 Topps Chrome Paolo Banchero Purple #124 /75	\N	\N	\N	102.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-152.jpg	fp152	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 07:51:00.697236+00	t	\N	2026-10-01 15:00:00+00	2026-10-10 09:51:00.697236+00
32	1	src2	ext32	\N	\N	\N	2024-25 Topps Chrome Paolo Banchero Purple #44 /75	\N	\N	\N	222.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-32.jpg	fp32	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 07:51:00.697236+00	t	\N	2026-10-01 03:00:00+00	2026-10-10 09:51:00.697236+00
212	1	src2	ext212	\N	\N	\N	2025-26 Topps Chrome Sapphire Paolo Banchero Purple #164 /75	\N	\N	\N	162.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-212.jpg	fp212	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 07:51:00.697236+00	t	\N	2026-10-01 21:00:00+00	2026-10-10 09:51:00.697236+00
92	1	src2	ext92	\N	\N	\N	2025-26 Topps Chrome Sapphire Paolo Banchero Purple #84 /75	\N	\N	\N	282.00	NZD	f	https://cdn.shopify.com/s/files/seed/card-92.jpg	fp92	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 07:51:00.697236+00	f	\N	2026-10-01 09:00:00+00	2026-10-10 09:51:00.697236+00
248	1	src2	ext248	\N	\N	\N	2024-25 Topps Chrome Paolo Banchero Red Wave #36	\N	\N	\N	110.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-248.jpg	fp248	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 01:51:00.697236+00	t	\N	2026-10-02 00:00:00+00	2026-10-10 09:51:00.697236+00
128	1	src2	ext128	\N	\N	\N	2024-25 Topps Chrome Paolo Banchero Red Wave #146	\N	\N	\N	230.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-128.jpg	fp128	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 01:51:00.697236+00	t	\N	2026-10-01 12:00:00+00	2026-10-10 09:51:00.697236+00
8	1	src2	ext8	\N	\N	\N	2024-25 Topps Chrome Paolo Banchero Red Wave #66	\N	\N	\N	110.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-8.jpg	fp8	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 01:51:00.697236+00	t	\N	2026-10-01 00:00:00+00	2026-10-10 09:51:00.697236+00
188	1	src2	ext188	\N	\N	\N	2025-26 Topps Chrome Sapphire Paolo Banchero Red Wave #186	\N	\N	\N	50.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-188.jpg	fp188	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 01:51:00.697236+00	t	\N	2026-10-01 18:00:00+00	2026-10-10 09:51:00.697236+00
68	1	src2	ext68	\N	\N	\N	2025-26 Topps Chrome Sapphire Paolo Banchero Red Wave #106 Auto	\N	\N	\N	170.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-68.jpg	fp68	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 01:51:00.697236+00	t	\N	2026-10-01 06:00:00+00	2026-10-10 09:51:00.697236+00
224	1	src2	ext224	\N	\N	\N	2024-25 Topps Chrome Paolo Banchero Blue #58 /199	\N	\N	\N	78.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-224.jpg	fp224	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 19:51:00.697236+00	t	\N	2026-10-01 22:00:00+00	2026-10-10 09:51:00.697236+00
104	1	src2	ext104	\N	\N	\N	2024-25 Topps Chrome Paolo Banchero Blue #168 /199	\N	\N	\N	198.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-104.jpg	fp104	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 19:51:00.697236+00	t	\N	2026-10-01 10:00:00+00	2026-10-10 09:51:00.697236+00
164	1	src2	ext164	\N	\N	\N	2025-26 Topps Chrome Sapphire Paolo Banchero Blue #18 /199	\N	\N	\N	258.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-164.jpg	fp164	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 19:51:00.697236+00	t	\N	2026-10-01 16:00:00+00	2026-10-10 09:51:00.697236+00
44	1	src2	ext44	\N	\N	\N	2025-26 Topps Chrome Sapphire Paolo Banchero Blue #128 /199	\N	\N	\N	138.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-44.jpg	fp44	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 19:51:00.697236+00	t	\N	2026-10-01 04:00:00+00	2026-10-10 09:51:00.697236+00
200	1	src2	ext200	\N	\N	\N	2024-25 Topps Chrome Paolo Banchero Base #80	\N	\N	\N	206.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-200.jpg	fp200	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 13:51:00.697236+00	t	\N	2026-10-01 20:00:00+00	2026-10-10 09:51:00.697236+00
80	1	src2	ext80	\N	\N	\N	2024-25 Topps Chrome Paolo Banchero Base #190	\N	\N	\N	86.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-80.jpg	fp80	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 13:51:00.697236+00	t	\N	2026-10-01 08:00:00+00	2026-10-10 09:51:00.697236+00
270	1	src0	ext270	\N	\N	\N	2025-26 Topps Chrome Sapphire Paolo Banchero Base #120	\N	\N	\N	26.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-260.jpg	fp270	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 13:51:00.697236+00	t	\N	2026-10-02 03:00:00+00	2026-10-10 09:51:00.697236+00
140	1	src2	ext140	\N	\N	\N	2025-26 Topps Chrome Sapphire Paolo Banchero Base #40	\N	\N	\N	146.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-140.jpg	fp140	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 13:51:00.697236+00	t	\N	2026-10-01 14:00:00+00	2026-10-10 09:51:00.697236+00
20	1	src2	ext20	\N	\N	\N	2025-26 Topps Chrome Sapphire Paolo Banchero Base #150	\N	\N	\N	26.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-20.jpg	fp20	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 13:51:00.697236+00	t	\N	2026-10-01 02:00:00+00	2026-10-10 09:51:00.697236+00
177	2	src0	ext177	\N	\N	\N	2024-25 Panini Donruss Optic Cooper Flagg Holo #109	\N	\N	\N	147.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-177.jpg	fp177	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 06:51:00.697236+00	t	\N	2026-10-01 17:00:00+00	2026-10-10 09:51:00.697236+00
57	2	src0	ext57	\N	\N	\N	2024-25 Panini Donruss Optic Cooper Flagg Holo #29	\N	\N	\N	27.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-57.jpg	fp57	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 06:51:00.697236+00	t	\N	2026-10-01 05:00:00+00	2026-10-10 09:51:00.697236+00
237	2	src0	ext237	\N	\N	\N	2024-25 Panini Origins Cooper Flagg Holo #149	\N	\N	\N	207.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-237.jpg	fp237	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 06:51:00.697236+00	t	\N	2026-10-01 23:00:00+00	2026-10-10 09:51:00.697236+00
117	2	src0	ext117	\N	\N	\N	2024-25 Panini Origins Cooper Flagg Holo #69	\N	\N	\N	87.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-117.jpg	fp117	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 06:51:00.697236+00	t	\N	2026-10-01 11:00:00+00	2026-10-10 09:51:00.697236+00
288	2	src0	ext288	\N	\N	\N	2024-25 Panini Donruss Optic Cooper Flagg Purple #21 RC /75	\N	\N	\N	235.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-273.jpg	fp288	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 06:51:00.697236+00	t	\N	2026-10-02 04:00:00+00	2026-10-10 09:51:00.697236+00
153	2	src0	ext153	\N	\N	\N	2024-25 Panini Donruss Optic Cooper Flagg Purple #131 RC Auto /75	\N	\N	\N	115.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-153.jpg	fp153	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 06:51:00.697236+00	t	\N	2026-10-01 15:00:00+00	2026-10-10 09:51:00.697236+00
33	2	src0	ext33	\N	\N	\N	2024-25 Panini Donruss Optic Cooper Flagg Purple #51 RC /75	\N	\N	\N	235.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-33.jpg	fp33	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 06:51:00.697236+00	t	\N	2026-10-01 03:00:00+00	2026-10-10 09:51:00.697236+00
213	2	src0	ext213	\N	\N	\N	2024-25 Panini Origins Cooper Flagg Purple #171 RC /75	\N	\N	\N	175.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-213.jpg	fp213	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 06:51:00.697236+00	t	\N	2026-10-01 21:00:00+00	2026-10-10 09:51:00.697236+00
93	2	src0	ext93	\N	\N	\N	2024-25 Panini Origins Cooper Flagg Purple #91 RC /75	\N	\N	\N	55.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-93.jpg	fp93	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 06:51:00.697236+00	t	\N	2026-10-01 09:00:00+00	2026-10-10 09:51:00.697236+00
249	2	src0	ext249	\N	\N	\N	2024-25 Panini Donruss Optic Cooper Flagg Red Wave #43	\N	\N	\N	123.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-249.jpg	fp249	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 00:51:00.697236+00	t	\N	2026-10-02 00:00:00+00	2026-10-10 09:51:00.697236+00
129	2	src0	ext129	\N	\N	\N	2024-25 Panini Donruss Optic Cooper Flagg Red Wave #153	\N	\N	\N	243.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-129.jpg	fp129	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 00:51:00.697236+00	t	\N	2026-10-01 12:00:00+00	2026-10-10 09:51:00.697236+00
9	2	src0	ext9	\N	\N	\N	2024-25 Panini Donruss Optic Cooper Flagg Red Wave #73	\N	\N	\N	123.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-9.jpg	fp9	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 00:51:00.697236+00	t	\N	2026-10-01 00:00:00+00	2026-10-10 09:51:00.697236+00
189	2	src0	ext189	\N	\N	\N	2024-25 Panini Origins Cooper Flagg Red Wave #193	\N	\N	\N	63.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-189.jpg	fp189	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 00:51:00.697236+00	t	\N	2026-10-01 18:00:00+00	2026-10-10 09:51:00.697236+00
69	2	src0	ext69	\N	\N	\N	2024-25 Panini Origins Cooper Flagg Red Wave #113	\N	\N	\N	183.00	NZD	f	https://cdn.shopify.com/s/files/seed/card-69.jpg	fp69	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 00:51:00.697236+00	f	\N	2026-10-01 06:00:00+00	2026-10-10 09:51:00.697236+00
225	2	src0	ext225	\N	\N	\N	2024-25 Panini Donruss Optic Cooper Flagg Blue #65 /199	\N	\N	\N	91.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-225.jpg	fp225	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 18:51:00.697236+00	t	\N	2026-10-01 22:00:00+00	2026-10-10 09:51:00.697236+00
105	2	src0	ext105	\N	\N	\N	2024-25 Panini Donruss Optic Cooper Flagg Blue #175 /199	\N	\N	\N	211.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-105.jpg	fp105	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 18:51:00.697236+00	t	\N	2026-10-01 10:00:00+00	2026-10-10 09:51:00.697236+00
165	2	src0	ext165	\N	\N	\N	2024-25 Panini Origins Cooper Flagg Blue #25 /199	\N	\N	\N	271.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-165.jpg	fp165	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 18:51:00.697236+00	t	\N	2026-10-01 16:00:00+00	2026-10-10 09:51:00.697236+00
45	2	src0	ext45	\N	\N	\N	2024-25 Panini Origins Cooper Flagg Blue #135 /199	\N	\N	\N	151.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-45.jpg	fp45	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 18:51:00.697236+00	t	\N	2026-10-01 04:00:00+00	2026-10-10 09:51:00.697236+00
201	2	src0	ext201	\N	\N	\N	2024-25 Panini Donruss Optic Cooper Flagg Base #87	\N	\N	\N	219.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-201.jpg	fp201	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 12:51:00.697236+00	t	\N	2026-10-01 20:00:00+00	2026-10-10 09:51:00.697236+00
81	2	src0	ext81	\N	\N	\N	2024-25 Panini Donruss Optic Cooper Flagg Base #197	\N	\N	\N	99.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-81.jpg	fp81	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 12:51:00.697236+00	t	\N	2026-10-01 08:00:00+00	2026-10-10 09:51:00.697236+00
272	2	src2	ext272	\N	\N	\N	2024-25 Panini Origins Cooper Flagg Base #127	\N	\N	\N	39.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-261.jpg	fp272	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 12:51:00.697236+00	t	\N	2026-10-02 03:00:00+00	2026-10-10 09:51:00.697236+00
141	2	src0	ext141	\N	\N	\N	2024-25 Panini Origins Cooper Flagg Base #47	\N	\N	\N	159.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-141.jpg	fp141	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 12:51:00.697236+00	t	\N	2026-10-01 14:00:00+00	2026-10-10 09:51:00.697236+00
21	2	src0	ext21	\N	\N	\N	2024-25 Panini Origins Cooper Flagg Base #157	\N	\N	\N	39.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-21.jpg	fp21	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 12:51:00.697236+00	t	\N	2026-10-01 02:00:00+00	2026-10-10 09:51:00.697236+00
178	3	src1	ext178	\N	\N	\N	2024-25 Panini Donruss Optic Jalen Williams Orange #116 /25	\N	\N	\N	200.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-178.jpg	fp178	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 05:51:00.697236+00	t	\N	2026-10-01 17:00:00+00	2026-10-10 09:51:00.697236+00
58	3	src1	ext58	\N	\N	\N	2024-25 Panini Donruss Optic Jalen Williams Orange #36 /25	\N	\N	\N	80.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-58.jpg	fp58	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 05:51:00.697236+00	t	\N	2026-10-01 05:00:00+00	2026-10-10 09:51:00.697236+00
238	3	src1	ext238	\N	\N	\N	2024-25 Panini Origins Jalen Williams Orange #156 Auto /25	\N	\N	\N	260.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-238.jpg	fp238	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 05:51:00.697236+00	t	\N	2026-10-01 23:00:00+00	2026-10-10 09:51:00.697236+00
118	3	src1	ext118	\N	\N	\N	2024-25 Panini Origins Jalen Williams Orange #76 /25	\N	\N	\N	140.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-118.jpg	fp118	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 05:51:00.697236+00	t	\N	2026-10-01 11:00:00+00	2026-10-10 09:51:00.697236+00
289	3	src1	ext289	\N	\N	\N	2024-25 Panini Donruss Optic Jalen Williams Base #28	\N	\N	\N	208.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-274.jpg	fp289	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 05:51:00.697236+00	t	\N	2026-10-02 04:00:00+00	2026-10-10 09:51:00.697236+00
154	3	src1	ext154	\N	\N	\N	2024-25 Panini Donruss Optic Jalen Williams Base #138	\N	\N	\N	88.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-154.jpg	fp154	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 05:51:00.697236+00	t	\N	2026-10-01 15:00:00+00	2026-10-10 09:51:00.697236+00
34	3	src1	ext34	\N	\N	\N	2024-25 Panini Donruss Optic Jalen Williams Base #58 Auto	\N	\N	\N	208.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-34.jpg	fp34	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 05:51:00.697236+00	t	\N	2026-10-01 03:00:00+00	2026-10-10 09:51:00.697236+00
214	3	src1	ext214	\N	\N	\N	2024-25 Panini Origins Jalen Williams Base #178	\N	\N	\N	148.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-214.jpg	fp214	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 05:51:00.697236+00	t	\N	2026-10-01 21:00:00+00	2026-10-10 09:51:00.697236+00
94	3	src1	ext94	\N	\N	\N	2024-25 Panini Origins Jalen Williams Base #98	\N	\N	\N	28.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-94.jpg	fp94	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 05:51:00.697236+00	t	\N	2026-10-01 09:00:00+00	2026-10-10 09:51:00.697236+00
250	3	src1	ext250	\N	\N	\N	2024-25 Panini Donruss Optic Jalen Williams Gold #50 /10	\N	\N	\N	176.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-250.jpg	fp250	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 23:51:00.697236+00	t	\N	2026-10-02 01:00:00+00	2026-10-10 09:51:00.697236+00
130	3	src1	ext130	\N	\N	\N	2024-25 Panini Donruss Optic Jalen Williams Gold #160 /10	\N	\N	\N	56.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-130.jpg	fp130	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 23:51:00.697236+00	t	\N	2026-10-01 13:00:00+00	2026-10-10 09:51:00.697236+00
10	3	src1	ext10	\N	\N	\N	2024-25 Panini Donruss Optic Jalen Williams Gold #80 /10	\N	\N	\N	176.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-10.jpg	fp10	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 23:51:00.697236+00	t	\N	2026-10-01 01:00:00+00	2026-10-10 09:51:00.697236+00
190	3	src1	ext190	\N	\N	\N	2024-25 Panini Origins Jalen Williams Gold #10 /10	\N	\N	\N	116.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-190.jpg	fp190	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 23:51:00.697236+00	t	\N	2026-10-01 19:00:00+00	2026-10-10 09:51:00.697236+00
70	3	src1	ext70	\N	\N	\N	2024-25 Panini Origins Jalen Williams Gold #120 /10	\N	\N	\N	236.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-70.jpg	fp70	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 23:51:00.697236+00	t	\N	2026-10-01 07:00:00+00	2026-10-10 09:51:00.697236+00
226	3	src1	ext226	\N	\N	\N	2024-25 Panini Donruss Optic Jalen Williams Green #72 /99	\N	\N	\N	104.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-226.jpg	fp226	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 17:51:00.697236+00	t	\N	2026-10-01 22:00:00+00	2026-10-10 09:51:00.697236+00
106	3	src1	ext106	\N	\N	\N	2024-25 Panini Donruss Optic Jalen Williams Green #182 /99	\N	\N	\N	224.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-106.jpg	fp106	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 17:51:00.697236+00	t	\N	2026-10-01 10:00:00+00	2026-10-10 09:51:00.697236+00
166	3	src1	ext166	\N	\N	\N	2024-25 Panini Origins Jalen Williams Green #32 /99	\N	\N	\N	284.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-166.jpg	fp166	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 17:51:00.697236+00	t	\N	2026-10-01 16:00:00+00	2026-10-10 09:51:00.697236+00
46	3	src1	ext46	\N	\N	\N	2024-25 Panini Origins Jalen Williams Green #142 /99	\N	\N	\N	164.00	NZD	f	https://cdn.shopify.com/s/files/seed/card-46.jpg	fp46	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 17:51:00.697236+00	f	\N	2026-10-01 04:00:00+00	2026-10-10 09:51:00.697236+00
202	3	src1	ext202	\N	\N	\N	2024-25 Panini Donruss Optic Jalen Williams Silver Prizm #94	\N	\N	\N	232.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-202.jpg	fp202	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 11:51:00.697236+00	t	\N	2026-10-01 20:00:00+00	2026-10-10 09:51:00.697236+00
82	3	src1	ext82	\N	\N	\N	2024-25 Panini Donruss Optic Jalen Williams Silver Prizm #14	\N	\N	\N	112.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-82.jpg	fp82	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 11:51:00.697236+00	t	\N	2026-10-01 08:00:00+00	2026-10-10 09:51:00.697236+00
274	3	src1	ext274	\N	\N	\N	2024-25 Panini Origins Jalen Williams Silver Prizm #134	\N	\N	\N	52.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-262.jpg	fp274	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 11:51:00.697236+00	t	\N	2026-10-02 03:00:00+00	2026-10-10 09:51:00.697236+00
142	3	src1	ext142	\N	\N	\N	2024-25 Panini Origins Jalen Williams Silver Prizm #54	\N	\N	\N	172.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-142.jpg	fp142	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 11:51:00.697236+00	t	\N	2026-10-01 14:00:00+00	2026-10-10 09:51:00.697236+00
22	3	src1	ext22	\N	\N	\N	2024-25 Panini Origins Jalen Williams Silver Prizm #164	\N	\N	\N	52.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-22.jpg	fp22	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 11:51:00.697236+00	t	\N	2026-10-01 02:00:00+00	2026-10-10 09:51:00.697236+00
179	4	src2	ext179	\N	\N	\N	2024-25 Panini Donruss Optic LeBron James Orange #123 /25	\N	\N	\N	213.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-179.jpg	fp179	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 04:51:00.697236+00	t	\N	2026-10-01 17:00:00+00	2026-10-10 09:51:00.697236+00
59	4	src2	ext59	\N	\N	\N	2024-25 Panini Donruss Optic LeBron James Orange #43 /25	\N	\N	\N	93.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-59.jpg	fp59	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 04:51:00.697236+00	t	\N	2026-10-01 05:00:00+00	2026-10-10 09:51:00.697236+00
239	4	src2	ext239	\N	\N	\N	2024-25 Panini Origins LeBron James Orange #163 /25	\N	\N	\N	273.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-239.jpg	fp239	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 04:51:00.697236+00	t	\N	2026-10-01 23:00:00+00	2026-10-10 09:51:00.697236+00
119	4	src2	ext119	\N	\N	\N	2024-25 Panini Origins LeBron James Orange #83 Auto /25	\N	\N	\N	153.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-119.jpg	fp119	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 04:51:00.697236+00	t	\N	2026-10-01 11:00:00+00	2026-10-10 09:51:00.697236+00
290	4	src2	ext290	\N	\N	\N	2024-25 Panini Donruss Optic LeBron James Base #35	\N	\N	\N	221.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-275.jpg	fp290	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:51:00.697236+00	t	\N	2026-10-02 05:00:00+00	2026-10-10 09:51:00.697236+00
155	4	src2	ext155	\N	\N	\N	2024-25 Panini Donruss Optic LeBron James Base #145	\N	\N	\N	101.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-155.jpg	fp155	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:51:00.697236+00	t	\N	2026-10-01 15:00:00+00	2026-10-10 09:51:00.697236+00
35	4	src2	ext35	\N	\N	\N	2024-25 Panini Donruss Optic LeBron James Base #65	\N	\N	\N	221.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-35.jpg	fp35	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:51:00.697236+00	t	\N	2026-10-01 03:00:00+00	2026-10-10 09:51:00.697236+00
215	4	src2	ext215	\N	\N	\N	2024-25 Panini Origins LeBron James Base #185	\N	\N	\N	161.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-215.jpg	fp215	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:51:00.697236+00	t	\N	2026-10-01 21:00:00+00	2026-10-10 09:51:00.697236+00
95	4	src2	ext95	\N	\N	\N	2024-25 Panini Origins LeBron James Base #105	\N	\N	\N	41.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-95.jpg	fp95	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-10 04:51:00.697236+00	t	\N	2026-10-01 09:00:00+00	2026-10-10 09:51:00.697236+00
252	4	src0	ext252	\N	\N	\N	2024-25 Panini Donruss Optic LeBron James Gold #57 /10	\N	\N	\N	189.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-251.jpg	fp252	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 22:51:00.697236+00	t	\N	2026-10-02 01:00:00+00	2026-10-10 09:51:00.697236+00
131	4	src2	ext131	\N	\N	\N	2024-25 Panini Donruss Optic LeBron James Gold #167 /10	\N	\N	\N	69.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-131.jpg	fp131	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 22:51:00.697236+00	t	\N	2026-10-01 13:00:00+00	2026-10-10 09:51:00.697236+00
11	4	src2	ext11	\N	\N	\N	2024-25 Panini Donruss Optic LeBron James Gold #87 /10	\N	\N	\N	189.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-11.jpg	fp11	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 22:51:00.697236+00	t	\N	2026-10-01 01:00:00+00	2026-10-10 09:51:00.697236+00
191	4	src2	ext191	\N	\N	\N	2024-25 Panini Origins LeBron James Gold #17 /10	\N	\N	\N	129.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-191.jpg	fp191	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 22:51:00.697236+00	t	\N	2026-10-01 19:00:00+00	2026-10-10 09:51:00.697236+00
71	4	src2	ext71	\N	\N	\N	2024-25 Panini Origins LeBron James Gold #127 /10	\N	\N	\N	249.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-71.jpg	fp71	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 22:51:00.697236+00	t	\N	2026-10-01 07:00:00+00	2026-10-10 09:51:00.697236+00
227	4	src2	ext227	\N	\N	\N	2024-25 Panini Donruss Optic LeBron James Green #79 /99	\N	\N	\N	117.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-227.jpg	fp227	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 16:51:00.697236+00	t	\N	2026-10-01 22:00:00+00	2026-10-10 09:51:00.697236+00
107	4	src2	ext107	\N	\N	\N	2024-25 Panini Donruss Optic LeBron James Green #189 /99	\N	\N	\N	237.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-107.jpg	fp107	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 16:51:00.697236+00	t	\N	2026-10-01 10:00:00+00	2026-10-10 09:51:00.697236+00
167	4	src2	ext167	\N	\N	\N	2024-25 Panini Origins LeBron James Green #39 /99	\N	\N	\N	57.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-167.jpg	fp167	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 16:51:00.697236+00	t	\N	2026-10-01 16:00:00+00	2026-10-10 09:51:00.697236+00
47	4	src2	ext47	\N	\N	\N	2024-25 Panini Origins LeBron James Green #149 /99	\N	\N	\N	177.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-47.jpg	fp47	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 16:51:00.697236+00	t	\N	2026-10-01 04:00:00+00	2026-10-10 09:51:00.697236+00
203	4	src2	ext203	\N	\N	\N	2024-25 Panini Donruss Optic LeBron James Silver Prizm #101 RC	\N	\N	\N	245.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-203.jpg	fp203	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 10:51:00.697236+00	t	\N	2026-10-01 20:00:00+00	2026-10-10 09:51:00.697236+00
83	4	src2	ext83	\N	\N	\N	2024-25 Panini Donruss Optic LeBron James Silver Prizm #21 RC	\N	\N	\N	125.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-83.jpg	fp83	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 10:51:00.697236+00	t	\N	2026-10-01 08:00:00+00	2026-10-10 09:51:00.697236+00
276	4	src0	ext276	\N	\N	\N	2024-25 Panini Origins LeBron James Silver Prizm #141 RC	\N	\N	\N	65.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-263.jpg	fp276	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 10:51:00.697236+00	t	\N	2026-10-02 03:00:00+00	2026-10-10 09:51:00.697236+00
143	4	src2	ext143	\N	\N	\N	2024-25 Panini Origins LeBron James Silver Prizm #61 RC	\N	\N	\N	185.00	NZD	t	https://cdn.shopify.com/s/files/seed/card-143.jpg	fp143	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 10:51:00.697236+00	t	\N	2026-10-01 14:00:00+00	2026-10-10 09:51:00.697236+00
23	4	src2	ext23	\N	\N	\N	2024-25 Panini Origins LeBron James Silver Prizm #171 RC	\N	\N	\N	65.00	NZD	f	https://cdn.shopify.com/s/files/seed/card-23.jpg	fp23	2026-10-10 08:37:40.849906+00	2026-10-10 08:37:40.849906+00	2026-10-09 10:51:00.697236+00	f	\N	2026-10-01 02:00:00+00	2026-10-10 09:51:00.697236+00
\.


--
-- Data for Name: store_scan_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.store_scan_jobs (id, scan_job_id, store_scan_run_id, store_id, store_slug, store_name, base_url, scan_mode, scan_strategy, early_stop_enabled, early_stop_unchanged_pages, page_concurrency, status, locked_by, locked_at, heartbeat_at, attempts, max_attempts, next_attempt_at, started_at, completed_at, cancel_requested_at, cancel_requested_by, products_seen, products_processed, products_matched, products_marked_unavailable, pages_fetched, last_page_fetched, stop_reason, error_message, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: store_scan_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.store_scan_runs (id, store_id, store_slug, status, started_at, completed_at, products_seen, products_created, products_updated, products_marked_unavailable, error_message, metadata, created_at, products_processed, products_matched) FROM stdin;
\.


--
-- Data for Name: stores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stores (id, slug, name, base_url, source_type, country_code, currency, is_active, scan_frequency_minutes, last_successful_scan_at, last_failed_scan_at, created_at, updated_at, scan_strategy, early_stop_enabled, early_stop_unchanged_pages) FROM stdin;
1	topplay	TopPlay Sports Cards	https://topplaysportscards.co.nz	shopify	NZ	NZD	t	1440	\N	\N	2026-10-10 08:37:01.493585+00	2026-10-10 08:37:01.493585+00	incremental	t	2
2	dime-city-cards	Dime City Cards	https://dimecitycards.com	shopify	US	USD	t	1440	\N	\N	2026-10-10 08:37:01.493585+00	2026-10-10 08:37:01.493585+00	incremental	t	2
3	sports-cards-nz	Sports Cards NZ	https://sportscards.co.nz	shopify	NZ	NZD	t	1440	\N	\N	2026-10-10 08:37:01.493585+00	2026-10-10 08:37:01.493585+00	incremental	t	2
4	Icons of Sport	Icons of Sport AU	https://iconsofsport.com.au	shopify	AU	AUD	t	1440	\N	\N	2026-10-10 08:37:01.493585+00	2026-10-10 08:37:01.493585+00	incremental	t	2
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.teams (id, name, abbreviation, league, created_at) FROM stdin;
\.


--
-- Data for Name: watchlist; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watchlist (id, player_name, variants, target_numbers, is_active) FROM stdin;
\.


--
-- Data for Name: watchlist_matches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watchlist_matches (id, watchlist_id, watchlist_rule_id, store_product_id, source, external_id, product_card_match_id, confidence, status, first_matched_at, last_matched_at, created_at, updated_at) FROM stdin;
623	4	4	251	\N	\N	\N	0.9000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00
625	4	4	253	\N	\N	\N	0.9000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00
627	4	4	255	\N	\N	\N	0.9000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00
629	4	4	257	\N	\N	\N	0.9000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00
631	4	4	259	\N	\N	\N	0.9000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00
633	4	4	261	\N	\N	\N	0.9000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00
635	4	4	263	\N	\N	\N	0.9000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00
637	4	4	265	\N	\N	\N	0.9000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00
639	4	4	267	\N	\N	\N	0.9000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00
641	4	4	269	\N	\N	\N	0.9000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00
643	4	4	271	\N	\N	\N	0.9000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00
645	4	4	273	\N	\N	\N	0.9000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00
647	4	4	275	\N	\N	\N	0.9000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00
649	4	4	277	\N	\N	\N	0.9000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00
651	4	4	279	\N	\N	\N	0.9000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00
1	1	1	1	\N	\N	1	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:39.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
2	1	1	2	\N	\N	2	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:38.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
3	1	1	3	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:37.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
4	1	1	4	\N	\N	4	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:36.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
5	1	1	5	\N	\N	5	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:35.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
6	1	1	6	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:34.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
7	1	1	7	\N	\N	7	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:33.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
8	1	1	8	\N	\N	8	0.6200	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:32.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
9	1	1	9	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:31.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
10	1	1	10	\N	\N	10	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:30.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
11	1	1	11	\N	\N	11	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:29.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
12	1	1	12	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:28.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
13	1	1	13	\N	\N	13	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:27.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
14	1	1	14	\N	\N	14	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:26.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
15	1	1	15	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:25.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
16	1	1	16	\N	\N	16	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:24.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
17	1	1	17	\N	\N	17	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:23.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
18	1	1	18	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:22.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
19	1	1	19	\N	\N	19	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:21.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
20	1	1	20	\N	\N	20	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:20.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
21	1	1	21	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:19.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
22	1	1	22	\N	\N	22	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:18.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
23	1	1	23	\N	\N	23	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:17.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
24	1	1	24	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:16.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
25	1	1	25	\N	\N	25	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:15.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
26	1	1	26	\N	\N	26	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:14.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
27	1	1	27	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:13.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
28	1	1	28	\N	\N	28	0.6200	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:12.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
29	1	1	29	\N	\N	29	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:11.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
30	1	1	30	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:10.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
31	1	1	31	\N	\N	31	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:09.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
32	1	1	32	\N	\N	32	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:08.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
33	1	1	33	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:07.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
34	1	1	34	\N	\N	34	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:06.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
35	1	1	35	\N	\N	35	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:05.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
36	1	1	36	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:04.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
37	1	1	37	\N	\N	37	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:03.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
38	1	1	38	\N	\N	38	0.6800	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:02.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
39	1	1	39	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:01.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
40	1	1	40	\N	\N	40	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:37:00.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
41	1	1	41	\N	\N	41	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:59.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
42	1	1	42	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:58.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
43	1	1	43	\N	\N	43	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:57.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
44	1	1	44	\N	\N	44	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:56.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
45	1	1	45	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:55.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
46	1	1	46	\N	\N	46	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:54.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
47	1	1	47	\N	\N	47	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:53.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
48	1	1	48	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:52.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
49	1	1	49	\N	\N	49	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:51.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
50	1	1	50	\N	\N	50	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:50.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
51	1	1	51	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:49.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
52	1	1	52	\N	\N	52	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:48.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
53	1	1	53	\N	\N	53	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:47.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
54	1	1	54	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:46.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
55	1	1	55	\N	\N	55	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:45.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
56	1	1	56	\N	\N	56	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:44.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
57	1	1	57	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:43.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
58	1	1	58	\N	\N	58	0.6800	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:42.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
59	1	1	59	\N	\N	59	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:41.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
60	1	1	60	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:40.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
61	1	1	61	\N	\N	61	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:39.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
62	1	1	62	\N	\N	62	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:38.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
63	1	1	63	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:37.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
64	1	1	64	\N	\N	64	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:36.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
65	1	1	65	\N	\N	65	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:35.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
66	1	1	66	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:34.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
67	1	1	67	\N	\N	67	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:33.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
68	1	1	68	\N	\N	68	0.6200	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:32.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
69	1	1	69	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:31.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
70	1	1	70	\N	\N	70	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:30.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
71	1	1	71	\N	\N	71	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:29.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
72	1	1	72	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:28.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
73	1	1	73	\N	\N	73	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:27.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
74	1	1	74	\N	\N	74	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:26.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
75	1	1	75	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:25.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
76	1	1	76	\N	\N	76	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:24.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
77	1	1	77	\N	\N	77	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:23.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
78	1	1	78	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:22.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
79	1	1	79	\N	\N	79	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:21.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
80	1	1	80	\N	\N	80	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:20.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
81	1	1	81	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:19.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
82	1	1	82	\N	\N	82	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:18.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
83	1	1	83	\N	\N	83	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:17.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
84	1	1	84	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:16.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
85	1	1	85	\N	\N	85	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:15.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
86	1	1	86	\N	\N	86	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:14.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
87	1	1	87	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:13.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
88	1	1	88	\N	\N	88	0.6200	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:12.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
89	1	1	89	\N	\N	89	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:11.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
90	1	1	90	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:10.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
91	1	1	91	\N	\N	91	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:09.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
92	1	1	92	\N	\N	92	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:08.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
93	1	1	93	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:07.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
94	1	1	94	\N	\N	94	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:06.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
95	1	1	95	\N	\N	95	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:05.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
96	1	1	96	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:04.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
97	1	1	97	\N	\N	97	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:03.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
98	1	1	98	\N	\N	98	0.6800	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:02.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
99	1	1	99	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:01.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
100	1	1	100	\N	\N	100	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:36:00.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
101	1	1	101	\N	\N	101	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:59.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
102	1	1	102	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:58.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
103	1	1	103	\N	\N	103	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:57.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
104	1	1	104	\N	\N	104	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:56.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
105	1	1	105	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:55.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
106	1	1	106	\N	\N	106	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:54.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
107	1	1	107	\N	\N	107	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:53.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
108	1	1	108	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:52.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
109	1	1	109	\N	\N	109	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:51.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
110	1	1	110	\N	\N	110	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:50.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
111	1	1	111	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:49.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
112	1	1	112	\N	\N	112	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:48.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
113	1	1	113	\N	\N	113	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:47.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
114	1	1	114	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:46.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
115	1	1	115	\N	\N	115	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:45.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
116	1	1	116	\N	\N	116	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:44.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
117	1	1	117	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:43.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
118	1	1	118	\N	\N	118	0.6800	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:42.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
119	1	1	119	\N	\N	119	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:41.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
120	1	1	120	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:40.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
121	1	1	121	\N	\N	121	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:39.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
122	1	1	122	\N	\N	122	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:38.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
123	1	1	123	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:37.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
124	1	1	124	\N	\N	124	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:36.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
125	1	1	125	\N	\N	125	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:35.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
126	1	1	126	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:34.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
127	1	1	127	\N	\N	127	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:33.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
128	1	1	128	\N	\N	128	0.6200	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:32.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
129	1	1	129	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:31.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
130	1	1	130	\N	\N	130	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:30.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
131	1	1	131	\N	\N	131	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:29.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
132	1	1	132	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:28.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
133	1	1	133	\N	\N	133	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:27.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
134	1	1	134	\N	\N	134	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:26.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
135	1	1	135	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:25.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
136	1	1	136	\N	\N	136	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:24.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
137	1	1	137	\N	\N	137	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:23.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
138	1	1	138	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:22.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
139	1	1	139	\N	\N	139	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:21.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
140	1	1	140	\N	\N	140	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:20.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
141	1	1	141	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:19.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
142	1	1	142	\N	\N	142	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:18.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
143	1	1	143	\N	\N	143	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:17.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
144	1	1	144	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:16.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
145	1	1	145	\N	\N	145	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:15.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
146	1	1	146	\N	\N	146	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:14.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
147	1	1	147	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:13.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
148	1	1	148	\N	\N	148	0.6200	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:12.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
149	1	1	149	\N	\N	149	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:11.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
150	1	1	150	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:10.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
151	1	1	151	\N	\N	151	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:09.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
152	1	1	152	\N	\N	152	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:08.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
153	1	1	153	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:07.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
154	1	1	154	\N	\N	154	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:06.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
155	1	1	155	\N	\N	155	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:05.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
156	1	1	156	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:04.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
157	1	1	157	\N	\N	157	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:03.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
158	1	1	158	\N	\N	158	0.6800	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:02.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
159	1	1	159	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:01.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
160	1	1	160	\N	\N	160	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:35:00.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
161	1	1	161	\N	\N	161	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:59.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
162	1	1	162	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:58.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
163	1	1	163	\N	\N	163	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:57.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
164	1	1	164	\N	\N	164	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:56.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
165	1	1	165	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:55.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
166	1	1	166	\N	\N	166	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:54.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
167	1	1	167	\N	\N	167	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:53.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
168	1	1	168	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:52.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
169	1	1	169	\N	\N	169	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:51.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
170	1	1	170	\N	\N	170	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:50.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
171	1	1	171	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:49.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
172	1	1	172	\N	\N	172	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:48.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
173	1	1	173	\N	\N	173	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:47.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
174	1	1	174	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:46.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
175	1	1	175	\N	\N	175	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:45.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
176	1	1	176	\N	\N	176	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:44.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
177	1	1	177	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:43.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
178	1	1	178	\N	\N	178	0.6800	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:42.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
179	1	1	179	\N	\N	179	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:41.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
180	1	1	180	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:40.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
181	1	1	181	\N	\N	181	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:39.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
182	1	1	182	\N	\N	182	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:38.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
183	1	1	183	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:37.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
184	1	1	184	\N	\N	184	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:36.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
185	1	1	185	\N	\N	185	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:35.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
186	1	1	186	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:34.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
187	1	1	187	\N	\N	187	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:33.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
188	1	1	188	\N	\N	188	0.6200	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:32.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
189	1	1	189	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:31.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
190	1	1	190	\N	\N	190	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:30.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
191	1	1	191	\N	\N	191	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:29.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
192	1	1	192	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:28.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
193	1	1	193	\N	\N	193	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:27.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
194	1	1	194	\N	\N	194	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:26.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
195	1	1	195	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:25.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
196	1	1	196	\N	\N	196	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:24.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
197	1	1	197	\N	\N	197	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:23.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
198	1	1	198	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:22.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
199	1	1	199	\N	\N	199	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:21.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
200	1	1	200	\N	\N	200	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:20.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
201	1	1	201	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:19.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
202	1	1	202	\N	\N	202	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:18.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
203	1	1	203	\N	\N	203	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:17.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
204	1	1	204	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:16.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
205	1	1	205	\N	\N	205	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:15.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
206	1	1	206	\N	\N	206	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:14.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
207	1	1	207	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:13.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
208	1	1	208	\N	\N	208	0.6200	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:12.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
209	1	1	209	\N	\N	209	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:11.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
210	1	1	210	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:10.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
211	1	1	211	\N	\N	211	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:09.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
212	1	1	212	\N	\N	212	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:08.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
213	1	1	213	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:07.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
214	1	1	214	\N	\N	214	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:06.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
215	1	1	215	\N	\N	215	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:05.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
216	1	1	216	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:04.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
217	1	1	217	\N	\N	217	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:03.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
218	1	1	218	\N	\N	218	0.6800	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:02.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
219	1	1	219	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:01.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
220	1	1	220	\N	\N	220	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:34:00.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
221	1	1	221	\N	\N	221	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:59.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
222	1	1	222	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:58.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
223	1	1	223	\N	\N	223	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:57.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
224	1	1	224	\N	\N	224	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:56.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
225	1	1	225	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:55.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
226	1	1	226	\N	\N	226	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:54.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
227	1	1	227	\N	\N	227	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:53.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
228	1	1	228	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:52.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
229	1	1	229	\N	\N	229	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:51.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
230	1	1	230	\N	\N	230	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:50.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
231	1	1	231	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:49.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
232	1	1	232	\N	\N	232	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:48.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
233	1	1	233	\N	\N	233	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:47.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
234	1	1	234	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:46.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
235	1	1	235	\N	\N	235	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:45.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
236	1	1	236	\N	\N	236	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:44.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
237	1	1	237	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:43.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
238	1	1	238	\N	\N	238	0.6800	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:42.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
239	1	1	239	\N	\N	239	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:41.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
240	1	1	240	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:40.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
241	1	1	241	\N	\N	241	0.8300	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:39.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
242	1	1	242	\N	\N	242	0.8600	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:38.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
243	1	1	243	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:37.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
244	1	1	244	\N	\N	244	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:36.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
245	1	1	245	\N	\N	245	0.9500	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:35.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
246	1	1	246	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:34.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
247	1	1	247	\N	\N	247	0.7100	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:33.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
248	1	1	248	\N	\N	248	0.6200	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:32.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
249	1	1	249	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:31.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
250	1	1	250	\N	\N	250	0.9200	confirmed	2026-10-10 08:37:40.863408+00	2026-10-10 08:33:30.863408+00	2026-10-10 08:37:40.863408+00	2026-10-10 09:51:00.697236+00
251	2	2	100	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
252	2	2	102	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
253	2	2	104	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
254	2	2	106	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
255	2	2	108	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
256	2	2	110	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
257	2	2	112	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
258	2	2	114	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
259	2	2	116	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
260	2	2	118	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
261	2	2	120	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
262	2	2	122	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
263	2	2	124	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
264	2	2	126	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
265	2	2	128	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
266	2	2	130	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
267	2	2	132	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
268	2	2	134	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
269	2	2	136	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
270	2	2	138	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
271	2	2	140	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
272	2	2	142	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
273	2	2	144	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
274	2	2	146	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
275	2	2	148	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
276	2	2	150	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
277	2	2	152	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
278	2	2	154	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
279	2	2	156	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
280	2	2	158	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
281	2	2	160	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
282	2	2	162	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
283	2	2	164	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
284	2	2	166	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
285	2	2	168	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
286	2	2	170	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
287	2	2	172	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
288	2	2	174	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
289	2	2	176	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
290	2	2	178	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
291	2	2	180	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
292	2	2	182	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
293	2	2	184	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
294	2	2	186	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
295	2	2	188	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
296	2	2	190	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
297	2	2	192	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
298	2	2	194	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
299	2	2	196	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
300	2	2	198	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
301	2	2	200	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
302	2	2	202	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
303	2	2	204	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
304	2	2	206	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
305	2	2	208	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
306	2	2	210	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
307	2	2	212	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
308	2	2	214	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
309	2	2	216	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
310	2	2	218	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
311	2	2	220	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
312	2	2	222	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
313	2	2	224	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
314	2	2	226	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
315	2	2	228	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
316	2	2	230	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
317	2	2	232	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
318	2	2	234	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
319	2	2	236	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
320	2	2	238	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
321	2	2	240	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
322	2	2	242	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
323	2	2	244	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
324	2	2	246	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
325	2	2	248	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
326	2	2	250	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
327	2	2	252	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
328	2	2	254	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
329	2	2	256	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
330	2	2	258	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
331	2	2	260	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
332	2	2	262	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
333	2	2	264	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
334	2	2	266	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
335	2	2	268	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
336	2	2	270	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
337	2	2	272	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
338	2	2	274	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
339	2	2	276	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
340	2	2	278	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
341	2	2	280	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
342	2	2	282	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
343	2	2	284	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
344	2	2	286	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
345	2	2	288	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
346	2	2	290	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
347	2	2	292	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
348	2	2	294	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
349	2	2	296	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
350	2	2	298	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
351	2	2	300	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 08:37:40.870529+00	2026-10-10 09:51:00.697236+00
352	3	3	280	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
353	3	3	281	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
354	3	3	282	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
355	3	3	283	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
356	3	3	284	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
357	3	3	285	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
358	3	3	286	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
359	3	3	287	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
360	3	3	288	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
361	3	3	289	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
362	3	3	290	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
363	3	3	291	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
364	3	3	292	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
365	3	3	293	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
366	3	3	294	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
367	3	3	295	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
368	3	3	296	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
369	3	3	297	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
370	3	3	298	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
371	3	3	299	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
372	3	3	300	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 08:37:40.873185+00	2026-10-10 09:51:00.697236+00
373	4	4	1	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
374	4	4	2	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
375	4	4	3	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
376	4	4	4	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
377	4	4	5	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
378	4	4	6	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
379	4	4	7	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
380	4	4	8	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
381	4	4	9	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
382	4	4	10	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
383	4	4	11	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
384	4	4	12	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
385	4	4	13	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
386	4	4	14	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
387	4	4	15	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
388	4	4	16	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
389	4	4	17	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
390	4	4	18	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
391	4	4	19	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
392	4	4	20	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
393	4	4	21	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
394	4	4	22	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
395	4	4	23	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
396	4	4	24	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
397	4	4	25	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
398	4	4	26	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
399	4	4	27	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
400	4	4	28	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
401	4	4	29	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
402	4	4	30	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
403	4	4	31	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
404	4	4	32	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
405	4	4	33	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
406	4	4	34	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
407	4	4	35	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
408	4	4	36	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
409	4	4	37	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
410	4	4	38	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
411	4	4	39	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
412	4	4	40	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
413	4	4	41	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
414	4	4	42	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
415	4	4	43	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
416	4	4	44	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
417	4	4	45	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
418	4	4	46	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
419	4	4	47	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
420	4	4	48	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
421	4	4	49	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
422	4	4	50	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
423	4	4	51	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
424	4	4	52	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
425	4	4	53	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
426	4	4	54	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
427	4	4	55	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
428	4	4	56	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
429	4	4	57	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
430	4	4	58	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
431	4	4	59	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
432	4	4	60	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
433	4	4	61	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
434	4	4	62	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
435	4	4	63	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
436	4	4	64	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
437	4	4	65	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
438	4	4	66	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
439	4	4	67	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
440	4	4	68	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
441	4	4	69	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
442	4	4	70	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
443	4	4	71	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
444	4	4	72	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
445	4	4	73	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
446	4	4	74	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
447	4	4	75	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
448	4	4	76	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
449	4	4	77	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
450	4	4	78	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
451	4	4	79	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
452	4	4	80	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
453	4	4	81	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
454	4	4	82	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
455	4	4	83	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
456	4	4	84	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
457	4	4	85	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
458	4	4	86	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
459	4	4	87	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
460	4	4	88	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
461	4	4	89	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
462	4	4	90	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
463	4	4	91	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
464	4	4	92	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
465	4	4	93	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
466	4	4	94	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
467	4	4	95	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
468	4	4	96	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
469	4	4	97	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
470	4	4	98	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
471	4	4	99	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
472	4	4	100	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
473	4	4	101	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
474	4	4	102	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
475	4	4	103	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
476	4	4	104	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
477	4	4	105	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
478	4	4	106	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
479	4	4	107	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
480	4	4	108	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
481	4	4	109	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
482	4	4	110	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
483	4	4	111	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
484	4	4	112	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
485	4	4	113	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
486	4	4	114	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
487	4	4	115	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
488	4	4	116	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
489	4	4	117	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
490	4	4	118	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
491	4	4	119	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
492	4	4	120	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
493	4	4	121	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
494	4	4	122	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
495	4	4	123	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
496	4	4	124	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
497	4	4	125	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
498	4	4	126	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
499	4	4	127	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
500	4	4	128	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
501	4	4	129	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
502	4	4	130	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
503	4	4	131	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
504	4	4	132	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
505	4	4	133	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
506	4	4	134	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
507	4	4	135	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
508	4	4	136	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
509	4	4	137	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
510	4	4	138	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
511	4	4	139	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
512	4	4	140	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
513	4	4	141	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
514	4	4	142	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
515	4	4	143	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
516	4	4	144	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
517	4	4	145	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
518	4	4	146	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
519	4	4	147	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
520	4	4	148	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
521	4	4	149	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
522	4	4	150	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
523	4	4	151	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
524	4	4	152	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
525	4	4	153	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
526	4	4	154	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
527	4	4	155	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
528	4	4	156	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
529	4	4	157	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
530	4	4	158	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
531	4	4	159	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
532	4	4	160	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
533	4	4	161	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
534	4	4	162	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
535	4	4	163	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
536	4	4	164	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
537	4	4	165	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
538	4	4	166	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
539	4	4	167	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
540	4	4	168	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
541	4	4	169	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
542	4	4	170	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
543	4	4	171	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
544	4	4	172	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
545	4	4	173	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
546	4	4	174	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
547	4	4	175	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
548	4	4	176	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
549	4	4	177	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
550	4	4	178	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
551	4	4	179	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
552	4	4	180	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
553	4	4	181	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
554	4	4	182	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
555	4	4	183	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
556	4	4	184	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
557	4	4	185	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
558	4	4	186	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
559	4	4	187	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
560	4	4	188	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
561	4	4	189	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
562	4	4	190	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
563	4	4	191	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
564	4	4	192	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
565	4	4	193	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
566	4	4	194	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
567	4	4	195	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
568	4	4	196	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
569	4	4	197	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
570	4	4	198	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
571	4	4	199	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
572	4	4	200	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
573	4	4	201	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
574	4	4	202	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
575	4	4	203	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
576	4	4	204	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
577	4	4	205	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
578	4	4	206	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
579	4	4	207	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
580	4	4	208	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
581	4	4	209	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
582	4	4	210	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
583	4	4	211	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
584	4	4	212	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
585	4	4	213	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
586	4	4	214	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
587	4	4	215	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
588	4	4	216	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
589	4	4	217	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
590	4	4	218	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
591	4	4	219	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
592	4	4	220	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
593	4	4	221	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
594	4	4	222	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
595	4	4	223	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
596	4	4	224	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
597	4	4	225	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
598	4	4	226	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
599	4	4	227	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
600	4	4	228	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
601	4	4	229	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
602	4	4	230	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
603	4	4	231	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
604	4	4	232	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
605	4	4	233	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
606	4	4	234	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
607	4	4	235	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
608	4	4	236	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
609	4	4	237	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
610	4	4	238	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
611	4	4	239	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
612	4	4	240	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
613	4	4	241	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
614	4	4	242	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
615	4	4	243	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
616	4	4	244	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
617	4	4	245	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
618	4	4	246	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
619	4	4	247	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
620	4	4	248	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
621	4	4	249	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
622	4	4	250	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
624	4	4	252	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
626	4	4	254	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
628	4	4	256	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
630	4	4	258	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
632	4	4	260	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
634	4	4	262	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
636	4	4	264	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
638	4	4	266	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
640	4	4	268	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
642	4	4	270	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
644	4	4	272	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
646	4	4	274	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
648	4	4	276	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
650	4	4	278	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
652	4	4	280	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
653	4	4	281	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
654	4	4	282	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
655	4	4	283	\N	\N	\N	0.6200	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
656	4	4	284	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
657	4	4	285	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
658	4	4	286	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
659	4	4	287	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
660	4	4	288	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
661	4	4	289	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
662	4	4	290	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
663	4	4	291	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
664	4	4	292	\N	\N	\N	0.6500	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
665	4	4	293	\N	\N	\N	0.6800	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
666	4	4	294	\N	\N	\N	0.7100	possible	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
667	4	4	295	\N	\N	\N	0.9200	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
668	4	4	296	\N	\N	\N	0.9500	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
669	4	4	297	\N	\N	\N	0.8000	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
670	4	4	298	\N	\N	\N	0.8300	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
671	4	4	299	\N	\N	\N	0.8600	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
672	4	4	300	\N	\N	\N	0.8900	confirmed	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 08:37:40.874148+00	2026-10-10 09:51:00.697236+00
\.


--
-- Data for Name: watchlist_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watchlist_rules (id, watchlist_id, player_id, team_id, brand, product_line, season, set_id, card_number, parallel, rookie_only, autograph_only, relic_only, serial_numbered_only, graded_only, raw_only, min_price, max_price, currency, include_terms, exclude_terms, minimum_match_confidence, created_at, updated_at, intent_type, catalogue_card_id, catalogue_variant_id) FROM stdin;
1	1	1	\N	\N	\N	\N	\N	\N	\N	f	f	f	f	f	f	\N	\N	NZD	\N	\N	0.750	2026-10-10 08:37:40.847604+00	2026-10-10 08:37:40.847604+00	custom	\N	\N
2	2	\N	\N	\N	\N	\N	\N	\N	\N	f	f	f	f	f	f	\N	\N	NZD	\N	\N	0.750	2026-10-10 08:37:40.847604+00	2026-10-10 08:37:40.847604+00	custom	\N	\N
3	3	\N	\N	\N	\N	\N	\N	\N	\N	f	f	f	f	f	f	\N	\N	NZD	\N	\N	0.750	2026-10-10 08:37:40.847604+00	2026-10-10 08:37:40.847604+00	custom	\N	\N
4	4	1	\N	\N	\N	\N	\N	\N	\N	f	f	f	f	f	f	\N	\N	NZD	\N	\N	0.750	2026-10-10 08:37:40.847604+00	2026-10-10 08:37:40.847604+00	custom	\N	\N
\.


--
-- Data for Name: watchlists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watchlists (id, user_id, name, is_active, notification_enabled, created_at, updated_at) FROM stdin;
1	11111111-1111-1111-1111-111111111111	Wemby	t	f	2026-10-10 08:37:40.845647+00	2026-10-10 08:37:40.845647+00
2	11111111-1111-1111-1111-111111111111	Rookies	t	f	2026-10-10 08:37:40.845647+00	2026-10-10 08:37:40.845647+00
3	11111111-1111-1111-1111-111111111111	Old inactive	f	f	2026-10-10 08:37:40.845647+00	2026-10-10 08:37:40.845647+00
4	22222222-2222-2222-2222-222222222222	Other user	t	f	2026-10-10 08:37:40.845647+00	2026-10-10 08:37:40.845647+00
\.


--
-- Name: admin_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_audit_log_id_seq', 1, false);


--
-- Name: alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.alerts_id_seq', 1, false);


--
-- Name: card_catalogue_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.card_catalogue_cards_id_seq', 1, false);


--
-- Name: card_catalogue_sets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.card_catalogue_sets_id_seq', 1, false);


--
-- Name: card_catalogue_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.card_catalogue_variants_id_seq', 1, false);


--
-- Name: listings_feed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.listings_feed_id_seq', 1, false);


--
-- Name: match_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.match_feedback_id_seq', 462, true);


--
-- Name: player_aliases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.player_aliases_id_seq', 1, false);


--
-- Name: players_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.players_id_seq', 33, true);


--
-- Name: product_availability_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_availability_events_id_seq', 1, false);


--
-- Name: product_card_matches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_card_matches_id_seq', 1, false);


--
-- Name: product_classifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_classifications_id_seq', 330, true);


--
-- Name: product_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_snapshots_id_seq', 1, false);


--
-- Name: profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.profiles_id_seq', 1, false);


--
-- Name: reference_checklists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reference_checklists_id_seq', 1, false);


--
-- Name: scan_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.scan_jobs_id_seq', 1, false);


--
-- Name: scan_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.scan_runs_id_seq', 1, false);


--
-- Name: store_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.store_products_id_seq', 1, false);


--
-- Name: store_scan_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.store_scan_jobs_id_seq', 1, false);


--
-- Name: store_scan_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.store_scan_runs_id_seq', 1, false);


--
-- Name: stores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stores_id_seq', 33, true);


--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.teams_id_seq', 1, false);


--
-- Name: watchlist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.watchlist_id_seq', 1, false);


--
-- Name: watchlist_matches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.watchlist_matches_id_seq', 693, true);


--
-- Name: watchlist_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.watchlist_rules_id_seq', 1, false);


--
-- Name: watchlists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.watchlists_id_seq', 1, false);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: admin_audit_log admin_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_pkey PRIMARY KEY (id);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: card_catalogue_cards card_catalogue_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_catalogue_cards
    ADD CONSTRAINT card_catalogue_cards_pkey PRIMARY KEY (id);


--
-- Name: card_catalogue_cards card_catalogue_cards_set_id_player_id_card_number_subset_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_catalogue_cards
    ADD CONSTRAINT card_catalogue_cards_set_id_player_id_card_number_subset_key UNIQUE (set_id, player_id, card_number, subset);


--
-- Name: card_catalogue_sets card_catalogue_sets_brand_product_line_season_league_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_catalogue_sets
    ADD CONSTRAINT card_catalogue_sets_brand_product_line_season_league_key UNIQUE (brand, product_line, season, league);


--
-- Name: card_catalogue_sets card_catalogue_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_catalogue_sets
    ADD CONSTRAINT card_catalogue_sets_pkey PRIMARY KEY (id);


--
-- Name: card_catalogue_variants card_catalogue_variants_card_id_normalized_parallel_name_se_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_catalogue_variants
    ADD CONSTRAINT card_catalogue_variants_card_id_normalized_parallel_name_se_key UNIQUE (card_id, normalized_parallel_name, serial_limit);


--
-- Name: card_catalogue_variants card_catalogue_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_catalogue_variants
    ADD CONSTRAINT card_catalogue_variants_pkey PRIMARY KEY (id);


--
-- Name: listings_feed listings_feed_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listings_feed
    ADD CONSTRAINT listings_feed_pkey PRIMARY KEY (id);


--
-- Name: listings_feed listings_feed_source_external_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listings_feed
    ADD CONSTRAINT listings_feed_source_external_id_key UNIQUE (source, external_id);


--
-- Name: match_feedback match_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_feedback
    ADD CONSTRAINT match_feedback_pkey PRIMARY KEY (id);


--
-- Name: player_aliases player_aliases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_aliases
    ADD CONSTRAINT player_aliases_pkey PRIMARY KEY (id);


--
-- Name: player_aliases player_aliases_player_id_normalized_alias_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_aliases
    ADD CONSTRAINT player_aliases_player_id_normalized_alias_key UNIQUE (player_id, normalized_alias);


--
-- Name: players players_normalized_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_normalized_name_key UNIQUE (normalized_name);


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- Name: product_availability_events product_availability_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability_events
    ADD CONSTRAINT product_availability_events_pkey PRIMARY KEY (id);


--
-- Name: product_card_matches product_card_matches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_card_matches
    ADD CONSTRAINT product_card_matches_pkey PRIMARY KEY (id);


--
-- Name: product_card_matches product_card_matches_source_external_id_matcher_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_card_matches
    ADD CONSTRAINT product_card_matches_source_external_id_matcher_version_key UNIQUE (source, external_id, matcher_version);


--
-- Name: product_classifications product_classifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_classifications
    ADD CONSTRAINT product_classifications_pkey PRIMARY KEY (id);


--
-- Name: product_snapshots product_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_snapshots
    ADD CONSTRAINT product_snapshots_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_user_id_key UNIQUE (user_id);


--
-- Name: reference_checklists reference_checklists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reference_checklists
    ADD CONSTRAINT reference_checklists_pkey PRIMARY KEY (id);


--
-- Name: scan_jobs scan_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_jobs
    ADD CONSTRAINT scan_jobs_pkey PRIMARY KEY (id);


--
-- Name: scan_runs scan_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_runs
    ADD CONSTRAINT scan_runs_pkey PRIMARY KEY (id);


--
-- Name: source_products source_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_products
    ADD CONSTRAINT source_products_pkey PRIMARY KEY (source, external_id);


--
-- Name: store_products store_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_products
    ADD CONSTRAINT store_products_pkey PRIMARY KEY (id);


--
-- Name: store_products store_products_source_external_product_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_products
    ADD CONSTRAINT store_products_source_external_product_id_key UNIQUE (source, external_product_id);


--
-- Name: store_scan_jobs store_scan_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_scan_jobs
    ADD CONSTRAINT store_scan_jobs_pkey PRIMARY KEY (id);


--
-- Name: store_scan_runs store_scan_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_scan_runs
    ADD CONSTRAINT store_scan_runs_pkey PRIMARY KEY (id);


--
-- Name: stores stores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT stores_pkey PRIMARY KEY (id);


--
-- Name: stores stores_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT stores_slug_key UNIQUE (slug);


--
-- Name: teams teams_league_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_league_name_key UNIQUE (league, name);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: watchlist_matches watchlist_matches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlist_matches
    ADD CONSTRAINT watchlist_matches_pkey PRIMARY KEY (id);


--
-- Name: watchlist watchlist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlist
    ADD CONSTRAINT watchlist_pkey PRIMARY KEY (id);


--
-- Name: watchlist_rules watchlist_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlist_rules
    ADD CONSTRAINT watchlist_rules_pkey PRIMARY KEY (id);


--
-- Name: watchlists watchlists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlists
    ADD CONSTRAINT watchlists_pkey PRIMARY KEY (id);


--
-- Name: idx_admin_audit_log_admin_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_audit_log_admin_user_id ON public.admin_audit_log USING btree (admin_user_id);


--
-- Name: idx_alerts_claimable; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_claimable ON public.alerts USING btree (status, next_attempt_at, attempts, created_at) WHERE (status = ANY (ARRAY['pending'::text, 'failed'::text]));


--
-- Name: idx_alerts_dedupe_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_alerts_dedupe_key ON public.alerts USING btree (dedupe_key);


--
-- Name: idx_alerts_processing_stale; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_processing_stale ON public.alerts USING btree (updated_at) WHERE (status = 'processing'::text);


--
-- Name: idx_alerts_product_card_match_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_product_card_match_id ON public.alerts USING btree (product_card_match_id);


--
-- Name: idx_alerts_retry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_retry ON public.alerts USING btree (status, next_attempt_at, attempts) WHERE (status = ANY (ARRAY['pending'::text, 'failed'::text]));


--
-- Name: idx_alerts_store_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_store_product ON public.alerts USING btree (store_product_id);


--
-- Name: idx_alerts_user_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_user_created_at ON public.alerts USING btree (user_id, created_at DESC);


--
-- Name: idx_alerts_watchlist; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_watchlist ON public.alerts USING btree (watchlist_id, created_at DESC);


--
-- Name: idx_alerts_watchlist_match_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_watchlist_match_id ON public.alerts USING btree (watchlist_match_id);


--
-- Name: idx_card_catalogue_cards_player_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_card_catalogue_cards_player_id ON public.card_catalogue_cards USING btree (player_id);


--
-- Name: idx_card_catalogue_cards_set_player_card_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_card_catalogue_cards_set_player_card_number ON public.card_catalogue_cards USING btree (set_id, player_id, lower(regexp_replace(TRIM(BOTH FROM card_number), '\s+'::text, ' '::text, 'g'::text))) WHERE ((player_id IS NOT NULL) AND (NULLIF(TRIM(BOTH FROM card_number), ''::text) IS NOT NULL));


--
-- Name: idx_card_catalogue_cards_team_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_card_catalogue_cards_team_id ON public.card_catalogue_cards USING btree (team_id);


--
-- Name: idx_card_catalogue_sets_sport_league_season_product_line; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_card_catalogue_sets_sport_league_season_product_line ON public.card_catalogue_sets USING btree (sport, league, COALESCE(season, ''::text), lower(regexp_replace(TRIM(BOTH FROM product_line), '\s+'::text, ' '::text, 'g'::text))) WHERE (NULLIF(TRIM(BOTH FROM product_line), ''::text) IS NOT NULL);


--
-- Name: idx_listings_feed_source_external; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_feed_source_external ON public.listings_feed USING btree (source, external_id);


--
-- Name: idx_listings_feed_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_feed_status ON public.listings_feed USING btree (match_status, match_confidence DESC);


--
-- Name: idx_match_feedback_product_card_match_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_match_feedback_product_card_match_id ON public.match_feedback USING btree (product_card_match_id);


--
-- Name: idx_match_feedback_store_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_match_feedback_store_product_id ON public.match_feedback USING btree (store_product_id);


--
-- Name: idx_match_feedback_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_match_feedback_user ON public.match_feedback USING btree (user_id, created_at DESC);


--
-- Name: idx_match_feedback_user_product_type_recent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_match_feedback_user_product_type_recent ON public.match_feedback USING btree (user_id, store_product_id, feedback_type, created_at DESC, id DESC);


--
-- Name: idx_players_sport_league_normalized_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_players_sport_league_normalized_name ON public.players USING btree (sport, league, normalized_name);


--
-- Name: idx_product_availability_events_dedupe_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_product_availability_events_dedupe_key ON public.product_availability_events USING btree (dedupe_key);


--
-- Name: idx_product_availability_events_product_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_availability_events_product_created ON public.product_availability_events USING btree (store_product_id, created_at DESC);


--
-- Name: idx_product_availability_events_source_external_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_availability_events_source_external_created ON public.product_availability_events USING btree (source, external_id, created_at DESC);


--
-- Name: idx_product_availability_events_store_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_availability_events_store_created ON public.product_availability_events USING btree (store_id, created_at DESC);


--
-- Name: idx_product_availability_events_type_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_availability_events_type_created ON public.product_availability_events USING btree (event_type, created_at DESC);


--
-- Name: idx_product_card_matches_catalogue_card_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_card_matches_catalogue_card_id ON public.product_card_matches USING btree (catalogue_card_id);


--
-- Name: idx_product_card_matches_catalogue_variant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_card_matches_catalogue_variant_id ON public.product_card_matches USING btree (catalogue_variant_id);


--
-- Name: idx_product_card_matches_checklist_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_card_matches_checklist_id ON public.product_card_matches USING btree (checklist_id);


--
-- Name: idx_product_card_matches_legacy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_card_matches_legacy ON public.product_card_matches USING btree (source, external_id, matcher_version);


--
-- Name: idx_product_card_matches_matched_player_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_card_matches_matched_player_id ON public.product_card_matches USING btree (matched_player_id);


--
-- Name: idx_product_card_matches_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_card_matches_product ON public.product_card_matches USING btree (store_product_id, confidence DESC);


--
-- Name: idx_product_card_matches_product_confidence_recent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_card_matches_product_confidence_recent ON public.product_card_matches USING btree (store_product_id, confidence DESC, updated_at DESC);


--
-- Name: idx_product_card_matches_reviewed_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_card_matches_reviewed_by ON public.product_card_matches USING btree (reviewed_by);


--
-- Name: idx_product_snapshots_legacy_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_snapshots_legacy_lookup ON public.product_snapshots USING btree (source, external_id, observed_at DESC);


--
-- Name: idx_product_snapshots_product_observed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_snapshots_product_observed ON public.product_snapshots USING btree (store_product_id, observed_at DESC);


--
-- Name: idx_reference_checklists_card_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reference_checklists_card_number ON public.reference_checklists USING btree (card_number);


--
-- Name: idx_reference_checklists_card_number_set_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reference_checklists_card_number_set_name ON public.reference_checklists USING btree (card_number, set_name);


--
-- Name: idx_reference_checklists_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reference_checklists_lookup ON public.reference_checklists USING btree (set_name, card_number, player_name);


--
-- Name: idx_scan_jobs_claimable; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_jobs_claimable ON public.scan_jobs USING btree (priority, created_at) WHERE (status = 'queued'::text);


--
-- Name: idx_scan_jobs_recent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_jobs_recent ON public.scan_jobs USING btree (created_at DESC);


--
-- Name: idx_scan_jobs_running_heartbeat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_jobs_running_heartbeat ON public.scan_jobs USING btree (heartbeat_at) WHERE (status = 'running'::text);


--
-- Name: idx_scan_jobs_scan_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_jobs_scan_run ON public.scan_jobs USING btree (scan_run_id) WHERE (scan_run_id IS NOT NULL);


--
-- Name: idx_scan_runs_running_started; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_runs_running_started ON public.scan_runs USING btree (started_at DESC) WHERE (status = 'running'::text);


--
-- Name: idx_scan_runs_started_recent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scan_runs_started_recent ON public.scan_runs USING btree (started_at DESC);


--
-- Name: idx_source_products_available; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_source_products_available ON public.source_products USING btree (available, last_checked_at DESC);


--
-- Name: idx_source_products_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_source_products_seen ON public.source_products USING btree (source, last_seen_at DESC);


--
-- Name: idx_store_products_active_current_recent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_store_products_active_current_recent ON public.store_products USING btree (last_checked_at DESC NULLS LAST, last_seen_at DESC, created_at DESC, id) WHERE ((is_active = true) AND (current_availability = true));


--
-- Name: idx_store_products_active_source_price; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_store_products_active_source_price ON public.store_products USING btree (source, current_price, last_checked_at DESC) WHERE ((is_active = true) AND (current_availability = true));


--
-- Name: idx_store_products_source_external; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_store_products_source_external ON public.store_products USING btree (source, external_product_id);


--
-- Name: idx_store_products_store_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_store_products_store_seen ON public.store_products USING btree (store_id, last_seen_at DESC);


--
-- Name: idx_store_scan_jobs_parent_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_store_scan_jobs_parent_status ON public.store_scan_jobs USING btree (scan_job_id, status);


--
-- Name: idx_store_scan_jobs_queue_claimable; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_store_scan_jobs_queue_claimable ON public.store_scan_jobs USING btree (created_at) WHERE (status = 'queued'::text);


--
-- Name: idx_store_scan_jobs_running_heartbeat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_store_scan_jobs_running_heartbeat ON public.store_scan_jobs USING btree (heartbeat_at) WHERE (status = 'running'::text);


--
-- Name: idx_store_scan_jobs_store_recent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_store_scan_jobs_store_recent ON public.store_scan_jobs USING btree (store_id, created_at DESC) WHERE (store_id IS NOT NULL);


--
-- Name: idx_store_scan_runs_running_store; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_store_scan_runs_running_store ON public.store_scan_runs USING btree (store_id, store_slug, started_at DESC) WHERE (status = 'running'::text);


--
-- Name: idx_store_scan_runs_started_recent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_store_scan_runs_started_recent ON public.store_scan_runs USING btree (started_at DESC);


--
-- Name: idx_store_scan_runs_store_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_store_scan_runs_store_id ON public.store_scan_runs USING btree (store_id);


--
-- Name: idx_stores_admin_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stores_admin_list ON public.stores USING btree (is_active DESC, name);


--
-- Name: idx_watchlist_matches_dedupe; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_watchlist_matches_dedupe ON public.watchlist_matches USING btree (watchlist_id, watchlist_rule_id, source, external_id) WHERE ((source IS NOT NULL) AND (external_id IS NOT NULL));


--
-- Name: idx_watchlist_matches_product_card_match_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_watchlist_matches_product_card_match_id ON public.watchlist_matches USING btree (product_card_match_id);


--
-- Name: idx_watchlist_matches_product_recent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_watchlist_matches_product_recent ON public.watchlist_matches USING btree (store_product_id, last_matched_at DESC);


--
-- Name: idx_watchlist_matches_store_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_watchlist_matches_store_product_id ON public.watchlist_matches USING btree (store_product_id);


--
-- Name: idx_watchlist_matches_watchlist; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_watchlist_matches_watchlist ON public.watchlist_matches USING btree (watchlist_id, status, last_matched_at DESC);


--
-- Name: idx_watchlist_matches_watchlist_product_recent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_watchlist_matches_watchlist_product_recent ON public.watchlist_matches USING btree (watchlist_id, store_product_id, last_matched_at DESC);


--
-- Name: idx_watchlist_matches_watchlist_rule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_watchlist_matches_watchlist_rule_id ON public.watchlist_matches USING btree (watchlist_rule_id);


--
-- Name: idx_watchlist_rules_catalogue_card_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_watchlist_rules_catalogue_card_id ON public.watchlist_rules USING btree (catalogue_card_id);


--
-- Name: idx_watchlist_rules_catalogue_variant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_watchlist_rules_catalogue_variant_id ON public.watchlist_rules USING btree (catalogue_variant_id);


--
-- Name: idx_watchlist_rules_intent_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_watchlist_rules_intent_type ON public.watchlist_rules USING btree (intent_type);


--
-- Name: idx_watchlist_rules_player_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_watchlist_rules_player_id ON public.watchlist_rules USING btree (player_id);


--
-- Name: idx_watchlist_rules_set_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_watchlist_rules_set_id ON public.watchlist_rules USING btree (set_id);


--
-- Name: idx_watchlist_rules_team_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_watchlist_rules_team_id ON public.watchlist_rules USING btree (team_id);


--
-- Name: idx_watchlist_rules_watchlist_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_watchlist_rules_watchlist_id ON public.watchlist_rules USING btree (watchlist_id);


--
-- Name: idx_watchlists_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_watchlists_user ON public.watchlists USING btree (user_id, is_active);


--
-- Name: idx_watchlists_user_active_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_watchlists_user_active_updated ON public.watchlists USING btree (user_id, is_active, updated_at DESC, id);


--
-- Name: alerts alerts_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER alerts_set_updated_at BEFORE UPDATE ON public.alerts FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: card_catalogue_cards card_catalogue_cards_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER card_catalogue_cards_set_updated_at BEFORE UPDATE ON public.card_catalogue_cards FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: card_catalogue_sets card_catalogue_sets_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER card_catalogue_sets_set_updated_at BEFORE UPDATE ON public.card_catalogue_sets FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: card_catalogue_variants card_catalogue_variants_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER card_catalogue_variants_set_updated_at BEFORE UPDATE ON public.card_catalogue_variants FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: product_card_matches product_card_matches_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER product_card_matches_set_updated_at BEFORE UPDATE ON public.product_card_matches FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: profiles profiles_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER profiles_set_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: scan_jobs scan_jobs_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER scan_jobs_set_updated_at BEFORE UPDATE ON public.scan_jobs FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: store_products store_products_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER store_products_set_updated_at BEFORE UPDATE ON public.store_products FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: store_scan_jobs store_scan_jobs_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER store_scan_jobs_set_updated_at BEFORE UPDATE ON public.store_scan_jobs FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: stores stores_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER stores_set_updated_at BEFORE UPDATE ON public.stores FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: watchlist_matches watchlist_matches_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER watchlist_matches_set_updated_at BEFORE UPDATE ON public.watchlist_matches FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: watchlist_rules watchlist_rules_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER watchlist_rules_set_updated_at BEFORE UPDATE ON public.watchlist_rules FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: watchlists watchlists_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER watchlists_set_updated_at BEFORE UPDATE ON public.watchlists FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: admin_audit_log admin_audit_log_admin_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_admin_user_id_fkey FOREIGN KEY (admin_user_id) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: alerts alerts_product_card_match_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_product_card_match_id_fkey FOREIGN KEY (product_card_match_id) REFERENCES public.product_card_matches(id) ON DELETE SET NULL;


--
-- Name: alerts alerts_store_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_store_product_id_fkey FOREIGN KEY (store_product_id) REFERENCES public.store_products(id) ON DELETE CASCADE;


--
-- Name: alerts alerts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: alerts alerts_watchlist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_watchlist_id_fkey FOREIGN KEY (watchlist_id) REFERENCES public.watchlists(id) ON DELETE CASCADE;


--
-- Name: alerts alerts_watchlist_match_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_watchlist_match_id_fkey FOREIGN KEY (watchlist_match_id) REFERENCES public.watchlist_matches(id) ON DELETE SET NULL;


--
-- Name: card_catalogue_cards card_catalogue_cards_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_catalogue_cards
    ADD CONSTRAINT card_catalogue_cards_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE SET NULL;


--
-- Name: card_catalogue_cards card_catalogue_cards_set_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_catalogue_cards
    ADD CONSTRAINT card_catalogue_cards_set_id_fkey FOREIGN KEY (set_id) REFERENCES public.card_catalogue_sets(id) ON DELETE CASCADE;


--
-- Name: card_catalogue_cards card_catalogue_cards_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_catalogue_cards
    ADD CONSTRAINT card_catalogue_cards_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE SET NULL;


--
-- Name: card_catalogue_variants card_catalogue_variants_card_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_catalogue_variants
    ADD CONSTRAINT card_catalogue_variants_card_id_fkey FOREIGN KEY (card_id) REFERENCES public.card_catalogue_cards(id) ON DELETE CASCADE;


--
-- Name: match_feedback match_feedback_product_card_match_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_feedback
    ADD CONSTRAINT match_feedback_product_card_match_id_fkey FOREIGN KEY (product_card_match_id) REFERENCES public.product_card_matches(id) ON DELETE CASCADE;


--
-- Name: match_feedback match_feedback_store_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_feedback
    ADD CONSTRAINT match_feedback_store_product_id_fkey FOREIGN KEY (store_product_id) REFERENCES public.store_products(id) ON DELETE CASCADE;


--
-- Name: match_feedback match_feedback_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.match_feedback
    ADD CONSTRAINT match_feedback_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: player_aliases player_aliases_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_aliases
    ADD CONSTRAINT player_aliases_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE CASCADE;


--
-- Name: product_availability_events product_availability_events_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability_events
    ADD CONSTRAINT product_availability_events_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE SET NULL;


--
-- Name: product_availability_events product_availability_events_store_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability_events
    ADD CONSTRAINT product_availability_events_store_product_id_fkey FOREIGN KEY (store_product_id) REFERENCES public.store_products(id) ON DELETE CASCADE;


--
-- Name: product_card_matches product_card_matches_catalogue_card_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_card_matches
    ADD CONSTRAINT product_card_matches_catalogue_card_id_fkey FOREIGN KEY (catalogue_card_id) REFERENCES public.card_catalogue_cards(id) ON DELETE SET NULL;


--
-- Name: product_card_matches product_card_matches_catalogue_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_card_matches
    ADD CONSTRAINT product_card_matches_catalogue_variant_id_fkey FOREIGN KEY (catalogue_variant_id) REFERENCES public.card_catalogue_variants(id) ON DELETE SET NULL;


--
-- Name: product_card_matches product_card_matches_checklist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_card_matches
    ADD CONSTRAINT product_card_matches_checklist_id_fkey FOREIGN KEY (checklist_id) REFERENCES public.reference_checklists(id) ON DELETE SET NULL;


--
-- Name: product_card_matches product_card_matches_matched_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_card_matches
    ADD CONSTRAINT product_card_matches_matched_player_id_fkey FOREIGN KEY (matched_player_id) REFERENCES public.players(id) ON DELETE SET NULL;


--
-- Name: product_card_matches product_card_matches_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_card_matches
    ADD CONSTRAINT product_card_matches_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: product_card_matches product_card_matches_store_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_card_matches
    ADD CONSTRAINT product_card_matches_store_product_id_fkey FOREIGN KEY (store_product_id) REFERENCES public.store_products(id) ON DELETE CASCADE;


--
-- Name: product_classifications product_classifications_store_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_classifications
    ADD CONSTRAINT product_classifications_store_product_id_fkey FOREIGN KEY (store_product_id) REFERENCES public.store_products(id);


--
-- Name: product_snapshots product_snapshots_store_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_snapshots
    ADD CONSTRAINT product_snapshots_store_product_id_fkey FOREIGN KEY (store_product_id) REFERENCES public.store_products(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: scan_jobs scan_jobs_cancel_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_jobs
    ADD CONSTRAINT scan_jobs_cancel_requested_by_fkey FOREIGN KEY (cancel_requested_by) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: scan_jobs scan_jobs_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_jobs
    ADD CONSTRAINT scan_jobs_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: scan_jobs scan_jobs_scan_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scan_jobs
    ADD CONSTRAINT scan_jobs_scan_run_id_fkey FOREIGN KEY (scan_run_id) REFERENCES public.scan_runs(id) ON DELETE SET NULL;


--
-- Name: store_products store_products_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_products
    ADD CONSTRAINT store_products_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE SET NULL;


--
-- Name: store_scan_jobs store_scan_jobs_cancel_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_scan_jobs
    ADD CONSTRAINT store_scan_jobs_cancel_requested_by_fkey FOREIGN KEY (cancel_requested_by) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: store_scan_jobs store_scan_jobs_scan_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_scan_jobs
    ADD CONSTRAINT store_scan_jobs_scan_job_id_fkey FOREIGN KEY (scan_job_id) REFERENCES public.scan_jobs(id) ON DELETE CASCADE;


--
-- Name: store_scan_jobs store_scan_jobs_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_scan_jobs
    ADD CONSTRAINT store_scan_jobs_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE SET NULL;


--
-- Name: store_scan_jobs store_scan_jobs_store_scan_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_scan_jobs
    ADD CONSTRAINT store_scan_jobs_store_scan_run_id_fkey FOREIGN KEY (store_scan_run_id) REFERENCES public.store_scan_runs(id) ON DELETE SET NULL;


--
-- Name: store_scan_runs store_scan_runs_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_scan_runs
    ADD CONSTRAINT store_scan_runs_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE SET NULL;


--
-- Name: watchlist_matches watchlist_matches_product_card_match_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlist_matches
    ADD CONSTRAINT watchlist_matches_product_card_match_id_fkey FOREIGN KEY (product_card_match_id) REFERENCES public.product_card_matches(id) ON DELETE CASCADE;


--
-- Name: watchlist_matches watchlist_matches_store_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlist_matches
    ADD CONSTRAINT watchlist_matches_store_product_id_fkey FOREIGN KEY (store_product_id) REFERENCES public.store_products(id) ON DELETE CASCADE;


--
-- Name: watchlist_matches watchlist_matches_watchlist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlist_matches
    ADD CONSTRAINT watchlist_matches_watchlist_id_fkey FOREIGN KEY (watchlist_id) REFERENCES public.watchlists(id) ON DELETE CASCADE;


--
-- Name: watchlist_matches watchlist_matches_watchlist_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlist_matches
    ADD CONSTRAINT watchlist_matches_watchlist_rule_id_fkey FOREIGN KEY (watchlist_rule_id) REFERENCES public.watchlist_rules(id) ON DELETE CASCADE;


--
-- Name: watchlist_rules watchlist_rules_catalogue_card_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlist_rules
    ADD CONSTRAINT watchlist_rules_catalogue_card_id_fkey FOREIGN KEY (catalogue_card_id) REFERENCES public.card_catalogue_cards(id) ON DELETE SET NULL;


--
-- Name: watchlist_rules watchlist_rules_catalogue_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlist_rules
    ADD CONSTRAINT watchlist_rules_catalogue_variant_id_fkey FOREIGN KEY (catalogue_variant_id) REFERENCES public.card_catalogue_variants(id) ON DELETE SET NULL;


--
-- Name: watchlist_rules watchlist_rules_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlist_rules
    ADD CONSTRAINT watchlist_rules_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE SET NULL;


--
-- Name: watchlist_rules watchlist_rules_set_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlist_rules
    ADD CONSTRAINT watchlist_rules_set_id_fkey FOREIGN KEY (set_id) REFERENCES public.card_catalogue_sets(id) ON DELETE SET NULL;


--
-- Name: watchlist_rules watchlist_rules_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlist_rules
    ADD CONSTRAINT watchlist_rules_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE SET NULL;


--
-- Name: watchlist_rules watchlist_rules_watchlist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlist_rules
    ADD CONSTRAINT watchlist_rules_watchlist_id_fkey FOREIGN KEY (watchlist_id) REFERENCES public.watchlists(id) ON DELETE CASCADE;


--
-- Name: watchlists watchlists_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchlists
    ADD CONSTRAINT watchlists_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: admin_audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admin_audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: admin_audit_log admin_read_admin_audit_log; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_read_admin_audit_log ON public.admin_audit_log FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles p
  WHERE ((p.user_id = ( SELECT auth.uid() AS uid)) AND (p.role = 'admin'::text)))));


--
-- Name: watchlist admin_read_legacy_watchlist; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_read_legacy_watchlist ON public.watchlist FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles p
  WHERE ((p.user_id = ( SELECT auth.uid() AS uid)) AND (p.role = 'admin'::text)))));


--
-- Name: product_snapshots admin_read_product_snapshots; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_read_product_snapshots ON public.product_snapshots FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles p
  WHERE ((p.user_id = ( SELECT auth.uid() AS uid)) AND (p.role = 'admin'::text)))));


--
-- Name: scan_runs admin_read_scan_runs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_read_scan_runs ON public.scan_runs FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles p
  WHERE ((p.user_id = ( SELECT auth.uid() AS uid)) AND (p.role = 'admin'::text)))));


--
-- Name: source_products admin_read_source_products; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_read_source_products ON public.source_products FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles p
  WHERE ((p.user_id = ( SELECT auth.uid() AS uid)) AND (p.role = 'admin'::text)))));


--
-- Name: store_scan_runs admin_read_stores; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_read_stores ON public.store_scan_runs FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles p
  WHERE ((p.user_id = ( SELECT auth.uid() AS uid)) AND (p.role = 'admin'::text)))));


--
-- Name: alerts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.alerts ENABLE ROW LEVEL SECURITY;

--
-- Name: alerts alerts_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY alerts_select_own ON public.alerts FOR SELECT TO authenticated USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: card_catalogue_cards; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.card_catalogue_cards ENABLE ROW LEVEL SECURITY;

--
-- Name: card_catalogue_cards card_catalogue_cards_select_authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY card_catalogue_cards_select_authenticated ON public.card_catalogue_cards FOR SELECT TO authenticated USING (true);


--
-- Name: card_catalogue_sets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.card_catalogue_sets ENABLE ROW LEVEL SECURITY;

--
-- Name: card_catalogue_sets card_catalogue_sets_select_authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY card_catalogue_sets_select_authenticated ON public.card_catalogue_sets FOR SELECT TO authenticated USING (true);


--
-- Name: card_catalogue_variants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.card_catalogue_variants ENABLE ROW LEVEL SECURITY;

--
-- Name: card_catalogue_variants card_catalogue_variants_select_authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY card_catalogue_variants_select_authenticated ON public.card_catalogue_variants FOR SELECT TO authenticated USING (true);


--
-- Name: listings_feed; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.listings_feed ENABLE ROW LEVEL SECURITY;

--
-- Name: listings_feed listings_feed_select_authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY listings_feed_select_authenticated ON public.listings_feed FOR SELECT TO authenticated USING (true);


--
-- Name: match_feedback; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.match_feedback ENABLE ROW LEVEL SECURITY;

--
-- Name: match_feedback match_feedback_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY match_feedback_insert_own ON public.match_feedback FOR INSERT TO authenticated WITH CHECK ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: match_feedback match_feedback_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY match_feedback_select_own ON public.match_feedback FOR SELECT TO authenticated USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: player_aliases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.player_aliases ENABLE ROW LEVEL SECURITY;

--
-- Name: player_aliases player_aliases_select_authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY player_aliases_select_authenticated ON public.player_aliases FOR SELECT TO authenticated USING (true);


--
-- Name: players; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.players ENABLE ROW LEVEL SECURITY;

--
-- Name: players players_select_authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY players_select_authenticated ON public.players FOR SELECT TO authenticated USING (true);


--
-- Name: product_availability_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.product_availability_events ENABLE ROW LEVEL SECURITY;

--
-- Name: product_availability_events product_availability_events_select_authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY product_availability_events_select_authenticated ON public.product_availability_events FOR SELECT TO authenticated USING (true);


--
-- Name: product_card_matches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.product_card_matches ENABLE ROW LEVEL SECURITY;

--
-- Name: product_card_matches product_card_matches_select_authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY product_card_matches_select_authenticated ON public.product_card_matches FOR SELECT TO authenticated USING (true);


--
-- Name: product_snapshots; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.product_snapshots ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles profiles_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_insert_own ON public.profiles FOR INSERT TO authenticated WITH CHECK (((( SELECT auth.uid() AS uid) = user_id) AND (role = 'user'::text)));


--
-- Name: profiles profiles_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_select_own ON public.profiles FOR SELECT TO authenticated USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: profiles profiles_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_update_own ON public.profiles FOR UPDATE TO authenticated USING ((( SELECT auth.uid() AS uid) = user_id)) WITH CHECK ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: reference_checklists; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.reference_checklists ENABLE ROW LEVEL SECURITY;

--
-- Name: reference_checklists reference_checklists_select_authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY reference_checklists_select_authenticated ON public.reference_checklists FOR SELECT TO authenticated USING (true);


--
-- Name: scan_jobs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.scan_jobs ENABLE ROW LEVEL SECURITY;

--
-- Name: scan_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.scan_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: source_products; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.source_products ENABLE ROW LEVEL SECURITY;

--
-- Name: store_products; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.store_products ENABLE ROW LEVEL SECURITY;

--
-- Name: store_products store_products_select_authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_products_select_authenticated ON public.store_products FOR SELECT TO authenticated USING (true);


--
-- Name: store_scan_jobs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.store_scan_jobs ENABLE ROW LEVEL SECURITY;

--
-- Name: store_scan_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.store_scan_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: stores; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stores ENABLE ROW LEVEL SECURITY;

--
-- Name: stores stores_select_authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY stores_select_authenticated ON public.stores FOR SELECT TO authenticated USING (true);


--
-- Name: teams; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.teams ENABLE ROW LEVEL SECURITY;

--
-- Name: teams teams_select_authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY teams_select_authenticated ON public.teams FOR SELECT TO authenticated USING (true);


--
-- Name: watchlist; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.watchlist ENABLE ROW LEVEL SECURITY;

--
-- Name: watchlist_matches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.watchlist_matches ENABLE ROW LEVEL SECURITY;

--
-- Name: watchlist_matches watchlist_matches_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY watchlist_matches_delete_own ON public.watchlist_matches FOR DELETE TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.watchlists w
  WHERE ((w.id = watchlist_matches.watchlist_id) AND (w.user_id = ( SELECT auth.uid() AS uid))))));


--
-- Name: watchlist_matches watchlist_matches_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY watchlist_matches_insert_own ON public.watchlist_matches FOR INSERT TO authenticated WITH CHECK ((EXISTS ( SELECT 1
   FROM public.watchlists w
  WHERE ((w.id = watchlist_matches.watchlist_id) AND (w.user_id = ( SELECT auth.uid() AS uid))))));


--
-- Name: watchlist_matches watchlist_matches_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY watchlist_matches_select_own ON public.watchlist_matches FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.watchlists w
  WHERE ((w.id = watchlist_matches.watchlist_id) AND (w.user_id = ( SELECT auth.uid() AS uid))))));


--
-- Name: watchlist_matches watchlist_matches_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY watchlist_matches_update_own ON public.watchlist_matches FOR UPDATE TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.watchlists w
  WHERE ((w.id = watchlist_matches.watchlist_id) AND (w.user_id = ( SELECT auth.uid() AS uid)))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.watchlists w
  WHERE ((w.id = watchlist_matches.watchlist_id) AND (w.user_id = ( SELECT auth.uid() AS uid))))));


--
-- Name: watchlist_rules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.watchlist_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: watchlist_rules watchlist_rules_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY watchlist_rules_delete_own ON public.watchlist_rules FOR DELETE TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.watchlists w
  WHERE ((w.id = watchlist_rules.watchlist_id) AND (w.user_id = ( SELECT auth.uid() AS uid))))));


--
-- Name: watchlist_rules watchlist_rules_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY watchlist_rules_insert_own ON public.watchlist_rules FOR INSERT TO authenticated WITH CHECK ((EXISTS ( SELECT 1
   FROM public.watchlists w
  WHERE ((w.id = watchlist_rules.watchlist_id) AND (w.user_id = ( SELECT auth.uid() AS uid))))));


--
-- Name: watchlist_rules watchlist_rules_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY watchlist_rules_select_own ON public.watchlist_rules FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.watchlists w
  WHERE ((w.id = watchlist_rules.watchlist_id) AND (w.user_id = ( SELECT auth.uid() AS uid))))));


--
-- Name: watchlist_rules watchlist_rules_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY watchlist_rules_update_own ON public.watchlist_rules FOR UPDATE TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.watchlists w
  WHERE ((w.id = watchlist_rules.watchlist_id) AND (w.user_id = ( SELECT auth.uid() AS uid)))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.watchlists w
  WHERE ((w.id = watchlist_rules.watchlist_id) AND (w.user_id = ( SELECT auth.uid() AS uid))))));


--
-- Name: watchlists; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.watchlists ENABLE ROW LEVEL SECURITY;

--
-- Name: watchlists watchlists_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY watchlists_delete_own ON public.watchlists FOR DELETE TO authenticated USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: watchlists watchlists_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY watchlists_insert_own ON public.watchlists FOR INSERT TO authenticated WITH CHECK ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: watchlists watchlists_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY watchlists_select_own ON public.watchlists FOR SELECT TO authenticated USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: watchlists watchlists_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY watchlists_update_own ON public.watchlists FOR UPDATE TO authenticated USING ((( SELECT auth.uid() AS uid) = user_id)) WITH CHECK ((( SELECT auth.uid() AS uid) = user_id));


--
-- PostgreSQL database dump complete
--

\unrestrict GLefNrDEFNj6MPLnsnTjBxMtB4oajsUR8e8FiGjEW22akaplMoElVVX9n9b2HCy

